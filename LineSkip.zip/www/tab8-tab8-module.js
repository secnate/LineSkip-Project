(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab8-tab8-module"],{

/***/ "./src/app/tab8/tab8.module.ts":
/*!*************************************!*\
  !*** ./src/app/tab8/tab8.module.ts ***!
  \*************************************/
/*! exports provided: Tab8PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab8PageModule", function() { return Tab8PageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _tab8_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tab8.page */ "./src/app/tab8/tab8.page.ts");







var routes = [
    {
        path: '',
        component: _tab8_page__WEBPACK_IMPORTED_MODULE_6__["Tab8Page"]
    }
];
var Tab8PageModule = /** @class */ (function () {
    function Tab8PageModule() {
    }
    Tab8PageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_tab8_page__WEBPACK_IMPORTED_MODULE_6__["Tab8Page"]]
        })
    ], Tab8PageModule);
    return Tab8PageModule;
}());



/***/ }),

/***/ "./src/app/tab8/tab8.page.html":
/*!*************************************!*\
  !*** ./src/app/tab8/tab8.page.html ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"goBack()\"\n        class=\"backButton\">\n        <ion-icon slot=\"icon-only\" name=\"arrow-back\">\n        </ion-icon>\n          Back\n        </ion-button>\n    </ion-buttons>\n    <ion-title>Cart Details</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n  <ion-item *ngFor=\"let orderItem of currOrderShortened; let num = index\">\n    <ion-title text-left>{{orderItem.name}}</ion-title>\n    <ion-title text-right>{{numOfItems[num]}} x  $ {{orderItem.price}}</ion-title>\n  </ion-item>\n  <ion-item>\n    <ion-title text-left>\n      Total Venues: {{currOrder.totalItems}}\n    </ion-title>\n    </ion-item>\n    <ion-item>\n    <ion-title text-left>\n      Total Price: $ {{currOrder.totalPrice}}\n    </ion-title>\n  </ion-item>\n  <ion-row>\n    <ion-col text-center>\n      <ion-button size=\"medium\" (click)=\"newOrder()\">Checkout</ion-button>\n    </ion-col>\n  </ion-row>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/tab8/tab8.page.scss":
/*!*************************************!*\
  !*** ./src/app/tab8/tab8.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header, ion-toolbar, ion-content {\n  --background: black;\n  color: white; }\n\n.backButton {\n  color: white; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGFiOC9FOlxcVXNlcnNcXFNhZGVnaGlUYWJhc1xcRGVza3RvcFxcTGluZVNraXAvc3JjXFxhcHBcXHRhYjhcXHRhYjgucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBR2Q7RUFDRSxZQUFZLEVBQUEiLCJmaWxlIjoic3JjL2FwcC90YWI4L3RhYjgucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciwgaW9uLXRvb2xiYXIsIGlvbi1jb250ZW50IHtcclxuICAgIC0tYmFja2dyb3VuZDogYmxhY2s7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgfVxyXG4gIFxyXG4gIC5iYWNrQnV0dG9uIHtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/tab8/tab8.page.ts":
/*!***********************************!*\
  !*** ./src/app/tab8/tab8.page.ts ***!
  \***********************************/
/*! exports provided: Tab8Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab8Page", function() { return Tab8Page; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var Tab8Page = /** @class */ (function () {
    function Tab8Page() {
    }
    //   currOrder: order;
    //   static Orders: cart;
    //   currOrderShortened: tempVenueItems[];
    //   numOfItems: number[];
    //   constructor(private route: Router, private r: ActivatedRoute) {
    //     this.r.params.subscribe(params => {this.currOrder = JSON.parse(params['selectedOrder']);});
    //     this.currOrderShortened = [];
    //     this.numOfItems = [];
    //     this.currOrderShortened.push(this.currOrder.items[0]);
    //     this.numOfItems.push(1);
    //     for(var i:number=1; i<this.currOrder.items.length; i++) {
    //       var ind: number = -1;
    //       for(var j:number=0; j<this.currOrderShortened.length; j++) {
    //         if(this.currOrder.items[i].name == this.currOrderShortened[j].name) {
    //           ind = j;
    //         }
    //       }
    //       if(ind != -1) {
    //         this.numOfItems[ind]++;
    //       } else {
    //         this.currOrderShortened.push(this.currOrder.items[i]);
    //         this.numOfItems.push(1);
    //       }
    //     }
    //   }
    Tab8Page.prototype.ngOnInit = function () {
    };
    Tab8Page = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-tab8',
            template: __webpack_require__(/*! ./tab8.page.html */ "./src/app/tab8/tab8.page.html"),
            styles: [__webpack_require__(/*! ./tab8.page.scss */ "./src/app/tab8/tab8.page.scss")]
        })
    ], Tab8Page);
    return Tab8Page;
}());



/***/ })

}]);
//# sourceMappingURL=tab8-tab8-module.js.map