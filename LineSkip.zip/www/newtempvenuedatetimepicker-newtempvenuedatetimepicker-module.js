(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["newtempvenuedatetimepicker-newtempvenuedatetimepicker-module"],{

/***/ "./src/app/newtempvenuedatetimepicker/newtempvenuedatetimepicker.module.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/newtempvenuedatetimepicker/newtempvenuedatetimepicker.module.ts ***!
  \*********************************************************************************/
/*! exports provided: NewtempvenuedatetimepickerPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewtempvenuedatetimepickerPageModule", function() { return NewtempvenuedatetimepickerPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _newtempvenuedatetimepicker_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./newtempvenuedatetimepicker.page */ "./src/app/newtempvenuedatetimepicker/newtempvenuedatetimepicker.page.ts");
/* harmony import */ var ionic4_date_picker__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ionic4-date-picker */ "./node_modules/ionic4-date-picker/dist/index.js");








var routes = [
    {
        path: '',
        component: _newtempvenuedatetimepicker_page__WEBPACK_IMPORTED_MODULE_6__["NewtempvenuedatetimepickerPage"]
    }
];
var NewtempvenuedatetimepickerPageModule = /** @class */ (function () {
    function NewtempvenuedatetimepickerPageModule() {
    }
    NewtempvenuedatetimepickerPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                ionic4_date_picker__WEBPACK_IMPORTED_MODULE_7__["DatePickerModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_newtempvenuedatetimepicker_page__WEBPACK_IMPORTED_MODULE_6__["NewtempvenuedatetimepickerPage"]]
        })
    ], NewtempvenuedatetimepickerPageModule);
    return NewtempvenuedatetimepickerPageModule;
}());



/***/ }),

/***/ "./src/app/newtempvenuedatetimepicker/newtempvenuedatetimepicker.page.html":
/*!*********************************************************************************!*\
  !*** ./src/app/newtempvenuedatetimepicker/newtempvenuedatetimepicker.page.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar class=\"toolbar_header\">\n      <ion-title></ion-title>\n      <ion-buttons slot=\"start\">\n          <ion-button (click)=\"cancel()\"\n            style=\"color: white;\">\n            Cancel\n          </ion-button>\n      </ion-buttons>\n    </ion-toolbar>\n\n\n  </ion-header>\n\n<ion-content>\n\n  <!-- Start Date Calendar -->\n  <ion-item lines=\"none\" (click)=\"toggleViewingStartDateCalendar()\">\n    <ion-label class=\"selectlabel\">\n      <b>{{ getChoseOrSelectedStartDate() }} Start Date:</b> {{ getStartDateOutput() }}\n    </ion-label>\n    <ion-icon name=\"arrow-dropdown\" \n              *ngIf=\"!canShowStartDateCalendar()\">\n    </ion-icon>\n\n    <ion-icon name=\"arrow-dropup\" \n              *ngIf=\"showStartPullUpArrow()\">\n    </ion-icon>\n  </ion-item>\n\n  <ion-item *ngIf=\"canShowStartDateCalendar()\"> \n      <ionic-calendar-date-picker \n        [fromDate]=\"getTodayDate()\"\n        [date]=\"getTomorrow()\"\n        [toDate]=\"getEndOfYear()\"\n        (onSelect)=\"initialDateSelected($event)\">\n      </ionic-calendar-date-picker>\t\n  </ion-item>\n\n  <!-- End Date Calendar -->\n  <ion-item lines=\"none\" \n            *ngIf=\"selectedStartDate\"\n            (click)=\"toggleViewingEndDateCalendar()\">\n    <ion-label class=\"selectlabel\">\n      <b>{{ getChoseOrSelectedEndDate() }} End Date:</b> {{ getEndDateOutput() }}\n    </ion-label>\n    <ion-icon name=\"arrow-dropdown\" \n              *ngIf=\"!canShowEndDateCalendar()\">\n    </ion-icon>\n    <ion-icon name=\"arrow-dropup\" \n              *ngIf=\"showEndPullUpArrow()\">\n    </ion-icon>\n  </ion-item>\n\n  <ion-item *ngIf=\"canShowEndDateCalendar()\"> \n    <ionic-calendar-date-picker \n      [fromDate]= \"getDateAfterSelectedStartDate()\"\n      [date]= \"getDateAfterSelectedStartDate()\" \n      [toDate]=\"getEndOfYear()\"\n      (onSelect)=\"endDateSelected($event)\">\n    </ionic-calendar-date-picker>\t\n  </ion-item>\n\n  <!-- Select Start Time -->\n  <ion-item *ngIf=\"selectedEndDate\">\n    <ion-label><b>Start Time (PM): </b></ion-label>\n    <ion-label class=\"promptLabel\"\n               *ngIf=\"!hasSelectedStartTime()\">\n      <b>Click to Choose</b>\n    </ion-label>\n    <ion-datetime displayFormat=\"h:mm\" \n                  minuteValues=\"0\"\n                  hourValues=\"8,9,10,11\"\n                  [(ngModel)]=\"startTime\"\n                  (ngModelChange)=\"changedStartTime($event)\"\n                  name=\"startTime\">\n    </ion-datetime>\n  </ion-item>\n\n  <!-- Select End Time  -->\n    <ion-item *ngIf=\"selectedInitialTime && selectedEndDate\">\n        <ion-label><b>End Time (AM): </b></ion-label>\n        <ion-label class=\"promptLabel\"\n               *ngIf=\"!hasSelectedEndTime()\">\n          <b>Click to Choose</b>\n        </ion-label>\n        <ion-datetime displayFormat=\"h:mm\" \n                      minuteValues=\"0\"\n                      hourValues=\"12,1,2\"\n                      name=\"endTime\"\n                      [(ngModel)]=\"endTime\"\n                      (ngModelChange)=\"changedEndTime($event)\">\n        </ion-datetime>\n    </ion-item>\n\n  <ion-item *ngIf=\"selectedEndTime && selectedEndDate\"\n            (clicked)=\"moveToTicketsInfo()\">\n    <ion-button class=\"submitbutton\"\n                (click)=\"moveToTicketsInfo()\">\n      Next\n    </ion-button>\n  </ion-item>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/newtempvenuedatetimepicker/newtempvenuedatetimepicker.page.scss":
/*!*********************************************************************************!*\
  !*** ./src/app/newtempvenuedatetimepicker/newtempvenuedatetimepicker.page.scss ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar_header {\n  --background: black;\n  color: white; }\n\nion-content {\n  --background: black;\n  color: white; }\n\n.selectlabel {\n  font-style: bold;\n  font-size: 13pt; }\n\n.submitbutton {\n  margin: 0 auto;\n  width: 200pt;\n  height: 25pt;\n  font-style: bold;\n  --background: darkgrey;\n  color: white;\n  font-size: 15pt;\n  margin-top: 10px;\n  margin-bottom: 10px; }\n\n.promptLabel {\n  color: darkgrey;\n  font-style: bold;\n  text-align: right;\n  margin-right: -5px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbmV3dGVtcHZlbnVlZGF0ZXRpbWVwaWNrZXIvRTpcXFVzZXJzXFxTYWRlZ2hpVGFiYXNcXERlc2t0b3BcXExpbmVTa2lwL3NyY1xcYXBwXFxuZXd0ZW1wdmVudWVkYXRldGltZXBpY2tlclxcbmV3dGVtcHZlbnVlZGF0ZXRpbWVwaWNrZXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksZ0JBQWdCO0VBQ2hCLGVBQWUsRUFBQTs7QUFHbkI7RUFDSSxjQUFjO0VBQ2QsWUFBWTtFQUNaLFlBQVk7RUFDWixnQkFBZ0I7RUFDaEIsc0JBQWE7RUFDYixZQUFZO0VBQ1osZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixtQkFBbUIsRUFBQTs7QUFHdkI7RUFDSSxlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLGlCQUFpQjtFQUNqQixrQkFBa0IsRUFBQSIsImZpbGUiOiJzcmMvYXBwL25ld3RlbXB2ZW51ZWRhdGV0aW1lcGlja2VyL25ld3RlbXB2ZW51ZWRhdGV0aW1lcGlja2VyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50b29sYmFyX2hlYWRlciB7XG4gICAgLS1iYWNrZ3JvdW5kOiBibGFjaztcbiAgICBjb2xvcjogd2hpdGU7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgICAtLWJhY2tncm91bmQ6IGJsYWNrO1xuICAgIGNvbG9yOiB3aGl0ZTtcbn1cblxuLnNlbGVjdGxhYmVsIHtcbiAgICBmb250LXN0eWxlOiBib2xkO1xuICAgIGZvbnQtc2l6ZTogMTNwdDtcbn1cblxuLnN1Ym1pdGJ1dHRvbiB7XG4gICAgbWFyZ2luOiAwIGF1dG87XG4gICAgd2lkdGg6IDIwMHB0O1xuICAgIGhlaWdodDogMjVwdDtcbiAgICBmb250LXN0eWxlOiBib2xkO1xuICAgIC0tYmFja2dyb3VuZDogZGFya2dyZXk7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIGZvbnQtc2l6ZTogMTVwdDtcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG59XG5cbi5wcm9tcHRMYWJlbCB7XG4gICAgY29sb3I6IGRhcmtncmV5O1xuICAgIGZvbnQtc3R5bGU6IGJvbGQ7XG4gICAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gICAgbWFyZ2luLXJpZ2h0OiAtNXB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/newtempvenuedatetimepicker/newtempvenuedatetimepicker.page.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/newtempvenuedatetimepicker/newtempvenuedatetimepicker.page.ts ***!
  \*******************************************************************************/
/*! exports provided: NewtempvenuedatetimepickerPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewtempvenuedatetimepickerPage", function() { return NewtempvenuedatetimepickerPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);




var NewtempvenuedatetimepickerPage = /** @class */ (function () {
    function NewtempvenuedatetimepickerPage(router, route) {
        this.router = router;
        this.route = route;
        // this page allows us to select a temporary venue's
        // start date, end date, start time, and end time
        this.selectedStartDate = false;
        this.selectedEndDate = false;
        this.selectedInitialTime = false;
        this.selectedEndTime = false;
        // we have the minimum date for the starting of the date
        // picker
        this.minStartDate = new Date().toISOString();
        // The results of the date pickers
        this.startDate = null;
        this.endDate = null;
        this.startTime = null;
        this.endTime = null;
        // variables that control the collapsing of the calendars
        // for easier visual viewing by saving space
        this.collapseStartDateCalendar = false;
        this.collapseEndDateCalendar = false;
    }
    NewtempvenuedatetimepickerPage.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.subscribe(function (param) {
            _this.basicNewTempVenueInfo = param;
        });
    };
    NewtempvenuedatetimepickerPage.prototype.ionViewDidLeave = function () {
        // we leave the view so we reset all the variables
        // so that when we re-enter the view will be good as new!
        this.selectedStartDate = false;
        this.selectedEndDate = false;
        this.selectedInitialTime = false;
        this.selectedEndTime = false;
        this.startDate = null;
        this.endDate = null;
        this.startTime = null;
        this.endTime = null;
        this.collapseStartDateCalendar = false;
        this.collapseEndDateCalendar = false;
    };
    NewtempvenuedatetimepickerPage.prototype.getTodayDate = function () {
        return new Date();
    };
    NewtempvenuedatetimepickerPage.prototype.getTomorrow = function () {
        // we get tomorrow's date
        return new Date(this.getTodayDate().getTime() +
            (24 * 60 * 60 * 1000));
    };
    NewtempvenuedatetimepickerPage.prototype.getEndOfYear = function () {
        // get the beginning of the year
        var beginningOfNextYear = new Date(new Date().getFullYear() + 1, 0, 1);
        // subtract a day from it and return that
        return new Date(beginningOfNextYear.getTime() -
            (24 * 60 * 60 * 1000));
    };
    NewtempvenuedatetimepickerPage.prototype.cancel = function () {
        this.router.navigate(["/signupvenue"]);
    };
    NewtempvenuedatetimepickerPage.prototype.changedStartTime = function (newTime) {
        this.selectedInitialTime = true;
        console.log("DEBUG: the new start time is: " + this.startTime);
    };
    NewtempvenuedatetimepickerPage.prototype.changedEndTime = function (newTime) {
        this.selectedEndTime = true;
        console.log("DEBUG: the new end time is: " + this.endTime);
    };
    NewtempvenuedatetimepickerPage.prototype.getChoseOrSelectedStartTime = function () {
        if (this.selectedInitialTime) {
            return "Selected ";
        }
        else {
            return "Choose ";
        }
    };
    NewtempvenuedatetimepickerPage.prototype.getChoseOrSelectedEndTime = function () {
        if (this.selectedEndTime) {
            return "Selected ";
        }
        else {
            return "Choose ";
        }
    };
    NewtempvenuedatetimepickerPage.prototype.hasSelectedStartTime = function () {
        // IF the start time is selected
        return this.selectedInitialTime;
    };
    NewtempvenuedatetimepickerPage.prototype.hasSelectedEndTime = function () {
        return this.selectedEndTime;
    };
    NewtempvenuedatetimepickerPage.prototype.initialDateSelected = function (newDate) {
        console.log("DEBUG: SELECTED INITIAL DATE: " + newDate);
        this.selectedStartDate = true;
        this.startDate = newDate;
        // Now we check the case if 
        // the second date has already been selected
        if (this.endDate != null && this.selectedEndDate == true) {
            // We need to reset the whole thing in order to 
            // select a proper end date
            // And have the end date calendar open
            this.endDate = null;
            this.selectedEndDate = false;
            // collapse the first calendar
            this.toggleViewingStartDateCalendar();
        }
    };
    NewtempvenuedatetimepickerPage.prototype.endDateSelected = function (newEndDate) {
        console.log("DEBUG: SELECTED END DATE: " + newEndDate);
        this.selectedEndDate = true;
        this.endDate = newEndDate;
    };
    NewtempvenuedatetimepickerPage.prototype.getDateAfterSelectedStartDate = function () {
        if (this.startDate == null) {
            return null;
        }
        // otherwise, take the startDate and add 24 hours to it
        return new Date(this.startDate.getTime() +
            (24 * 60 * 60 * 1000));
    };
    NewtempvenuedatetimepickerPage.prototype.toggleViewingStartDateCalendar = function () {
        if (this.startDate != null &&
            this.selectedStartDate == true) {
            //we selected a start date
            // and toggle the start date calendar's viewing
            this.collapseStartDateCalendar = !this.collapseStartDateCalendar;
        }
    };
    NewtempvenuedatetimepickerPage.prototype.toggleViewingEndDateCalendar = function () {
        if (this.endDate != null && this.selectedEndDate == true) {
            // we selected the end date and toggle the
            // end date calendar's viewing
            this.collapseEndDateCalendar = !this.collapseEndDateCalendar;
        }
    };
    NewtempvenuedatetimepickerPage.prototype.getStartDateOutput = function () {
        // we get the string representation of the date
        // if one is selected
        if (this.startDate == null) {
            return "";
        }
        else {
            return moment__WEBPACK_IMPORTED_MODULE_3__(this.startDate).format("MM/DD/YYYY");
        }
    };
    NewtempvenuedatetimepickerPage.prototype.getEndDateOutput = function () {
        // we get the string representation of the date
        // if one is selected
        if (this.endDate == null) {
            return "";
        }
        else {
            return moment__WEBPACK_IMPORTED_MODULE_3__(this.endDate).format("MM/DD/YYYY");
        }
    };
    NewtempvenuedatetimepickerPage.prototype.getChoseOrSelectedStartDate = function () {
        // if we selected a start date,
        // then we return the string "Selected"
        // for display in the html file
        // if we did not select, then we return the
        // string "Choose" - to prompt users to select a start date
        if (this.startDate == null) {
            return "Choose ";
        }
        else {
            return "Selected ";
        }
    };
    NewtempvenuedatetimepickerPage.prototype.getChoseOrSelectedEndDate = function () {
        // if we selected a end date,
        // then we return the string "Selected"
        // for display in the html file
        // if we did not select, then we return the
        // string "Choose" - to prompt users to select a start date
        if (this.endDate == null) {
            return "Choose ";
        }
        else {
            return "Selected ";
        }
    };
    NewtempvenuedatetimepickerPage.prototype.canShowStartDateCalendar = function () {
        // we display the calendar only if
        // the initial date wasn't selected
        // or if the initial date was selected
        // and we deliberately want to see it
        var toReturn = (!this.selectedStartDate ||
            (this.selectedStartDate &&
                this.collapseStartDateCalendar));
        return toReturn;
    };
    NewtempvenuedatetimepickerPage.prototype.canShowEndDateCalendar = function () {
        // we display the calendar only if
        // the initial date wasn't selected
        // or if the initial date was selected
        // and we deliberately want to see it
        var toReturn = ((!this.selectedEndDate &&
            this.selectedStartDate)
            ||
                (this.selectedEndDate &&
                    this.collapseEndDateCalendar));
        return toReturn;
    };
    NewtempvenuedatetimepickerPage.prototype.showStartPullUpArrow = function () {
        return this.canShowStartDateCalendar() && this.selectedStartDate != false;
    };
    NewtempvenuedatetimepickerPage.prototype.showEndPullUpArrow = function () {
        return this.canShowEndDateCalendar() && this.selectedEndDate != false;
    };
    // moveToTicketsInfo packages the information collected
    // so far about the new temporary venue and passes it on
    // to the next view controller.
    // We add extra information to basicNewTempVenueInfo
    NewtempvenuedatetimepickerPage.prototype.moveToTicketsInfo = function () {
        console.log("CLICKED MOVE TO TICKETS INFO");
        var toPassOn = {
            //original information received from previous slide
            name: this.basicNewTempVenueInfo.name,
            address: this.basicNewTempVenueInfo.address,
            venueDescription: this.basicNewTempVenueInfo.venueDescription,
            phoneNumber: this.basicNewTempVenueInfo.phoneNumber,
            // now we add in the new information
            //    the start and end dates of the event
            startDate: this.startDate,
            endDate: this.endDate,
            //    the start times and end times of the event
            //    note the CRITICAL ASSUMPTION that the start 
            //    time is PM and the end time is AM.
            startTime: this.startTime,
            endTime: this.endTime
        };
        this.router.navigate(["tempvenuehourtickinfosetter", toPassOn]);
    };
    NewtempvenuedatetimepickerPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-newtempvenuedatetimepicker',
            template: __webpack_require__(/*! ./newtempvenuedatetimepicker.page.html */ "./src/app/newtempvenuedatetimepicker/newtempvenuedatetimepicker.page.html"),
            styles: [__webpack_require__(/*! ./newtempvenuedatetimepicker.page.scss */ "./src/app/newtempvenuedatetimepicker/newtempvenuedatetimepicker.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])
    ], NewtempvenuedatetimepickerPage);
    return NewtempvenuedatetimepickerPage;
}());



/***/ })

}]);
//# sourceMappingURL=newtempvenuedatetimepicker-newtempvenuedatetimepicker-module.js.map