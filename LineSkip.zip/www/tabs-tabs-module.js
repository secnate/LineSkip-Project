(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tabs-tabs-module"],{

/***/ "./src/app/tabs/tabs.module.ts":
/*!*************************************!*\
  !*** ./src/app/tabs/tabs.module.ts ***!
  \*************************************/
/*! exports provided: TabsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPageModule", function() { return TabsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _tabs_router_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./tabs.router.module */ "./src/app/tabs/tabs.router.module.ts");
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tabs.page */ "./src/app/tabs/tabs.page.ts");







var TabsPageModule = /** @class */ (function () {
    function TabsPageModule() {
    }
    TabsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [
                _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _tabs_router_module__WEBPACK_IMPORTED_MODULE_5__["TabsPageRoutingModule"]
            ],
            declarations: [_tabs_page__WEBPACK_IMPORTED_MODULE_6__["TabsPage"]]
        })
    ], TabsPageModule);
    return TabsPageModule;
}());



/***/ }),

/***/ "./src/app/tabs/tabs.page.html":
/*!*************************************!*\
  !*** ./src/app/tabs/tabs.page.html ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<ion-tabs>\n\n  <!-- Sadegh working changed slot=\"bottom\" to class=\"bottom\"-->\n  <ion-tab-bar slot=\"bottom\">\n\n    <!-- These tabs are for the patron -->\n    <ion-tab-button tab=\"tab1\" *ngIf=\"getUserType()=='PATRON'\">\n      <ion-icon name=\"add-circle-outline\"></ion-icon>\n      <ion-label>Temporary Venues</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"tab2\" *ngIf=\"getUserType()=='xxx'\">\n      <ion-icon name=\"add-circle-outline\"></ion-icon>\n      <ion-label>Permanent Venues</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"tab3\" *ngIf=\"getUserType()=='PATRON'\">\n      <ion-icon name=\"reorder\"></ion-icon>\n      <ion-label>Cart</ion-label>\n    </ion-tab-button>\n    <!-- These tabs are for Temporary Venues -->\n\n    <ion-tab-button tab=\"tab4\" *ngIf=\"getUserType()=='TEMP_VENUE'\">\n      <ion-icon name=\"time\"></ion-icon>\n      <ion-label>Hourly Information</ion-label>\n    </ion-tab-button>\n\n  <ion-tab-button tab=\"tab5\" *ngIf=\"getUserType()=='TEMP_VENUE'\">\n    <ion-icon name=\"settings\"></ion-icon>\n    <ion-label>Settings</ion-label>\n  </ion-tab-button>\n\n        <!-- These tabs are for Permanent Venues -->\n\n    <ion-tab-button tab=\"tab6\" *ngIf=\"getUserType()=='PERM_VENUE'\">\n      <ion-icon name=\"send\"></ion-icon>\n      <ion-label>Tab Six</ion-label>\n    </ion-tab-button>\n\n      <ion-tab-button tab=\"tab7\" *ngIf=\"getUserType()=='PERM_VENUE'\">\n        <ion-icon name=\"send\"></ion-icon>\n        <ion-label>Tab Seven</ion-label>\n      </ion-tab-button>\n\n</ion-tab-bar>\n\n</ion-tabs>\n"

/***/ }),

/***/ "./src/app/tabs/tabs.page.scss":
/*!*************************************!*\
  !*** ./src/app/tabs/tabs.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-tab-button[aria-selected=true] {\n  color: black !important;\n  --background: white;\n  border: 2px black solid; }\n\nion-tab-button {\n  --background: black;\n  --color: white; }\n\nion-tabs {\n  --background: black; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGFicy9FOlxcVXNlcnNcXFNhZGVnaGlUYWJhc1xcRGVza3RvcFxcTGluZVNraXAvc3JjXFxhcHBcXHRhYnNcXHRhYnMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdBO0VBQ0ksdUJBQXVCO0VBQ3ZCLG1CQUFhO0VBQ2IsdUJBQXVCLEVBQUE7O0FBSTNCO0VBQ0ksbUJBQWE7RUFDYixjQUFRLEVBQUE7O0FBR1o7RUFDSSxtQkFBYSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvdGFicy90YWJzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIFRoaXMgZGVmaW5lcyB0aGUgY3NzIGZvciB0aGUgXG4vLyB0YWIgY29udHJvbGxlclxuICBcbmlvbi10YWItYnV0dG9uW2FyaWEtc2VsZWN0ZWQ9dHJ1ZV0ge1xuICAgIGNvbG9yOiBibGFjayAhaW1wb3J0YW50O1xuICAgIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gICAgYm9yZGVyOiAycHggYmxhY2sgc29saWQ7XG59XG5cblxuaW9uLXRhYi1idXR0b24ge1xuICAgIC0tYmFja2dyb3VuZDogYmxhY2s7XG4gICAgLS1jb2xvcjogd2hpdGU7XG59XG5cbmlvbi10YWJzIHtcbiAgICAtLWJhY2tncm91bmQ6IGJsYWNrO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/tabs/tabs.page.ts":
/*!***********************************!*\
  !*** ./src/app/tabs/tabs.page.ts ***!
  \***********************************/
/*! exports provided: TabsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPage", function() { return TabsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals */ "./src/globals.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");





var TabsPage = /** @class */ (function () {
    function TabsPage(events, router, globals) {
        var _this = this;
        this.events = events;
        this.router = router;
        this.globals = globals;
        this.events.subscribe('changedLogInType', function (time) {
            console.log("DEBUG: changedLogType: " + _this.globals.GET_CURRENT_LOGGED_IN_TYPE());
            _this.userType = _this.globals.CURRENT_USER_TYPE();
        });
        this.userType = this.globals.CURRENT_USER_TYPE();
    }
    TabsPage.prototype.ionViewWillAppear = function () {
        var _this = this;
        this.userType = this.globals.CURRENT_USER_TYPE();
        this.events.subscribe('changedLogInType', function (time) {
            console.log("DEBUG: changedLogType: " + _this.globals.GET_CURRENT_LOGGED_IN_TYPE());
            _this.userType = _this.globals.CURRENT_USER_TYPE();
        });
    };
    TabsPage.prototype.getUserType = function () {
        return this.globals.CURRENT_USER_TYPE();
    };
    TabsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-tabs',
            template: __webpack_require__(/*! ./tabs.page.html */ "./src/app/tabs/tabs.page.html"),
            styles: [__webpack_require__(/*! ./tabs.page.scss */ "./src/app/tabs/tabs.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Events"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _globals__WEBPACK_IMPORTED_MODULE_3__["Globals"]])
    ], TabsPage);
    return TabsPage;
}());



/***/ }),

/***/ "./src/app/tabs/tabs.router.module.ts":
/*!********************************************!*\
  !*** ./src/app/tabs/tabs.router.module.ts ***!
  \********************************************/
/*! exports provided: TabsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPageRoutingModule", function() { return TabsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./tabs.page */ "./src/app/tabs/tabs.page.ts");
// BOTH NATHAN AND SADEGH CAN MODIFY THIS FILE




var routes = [
    {
        path: 'tabs',
        component: _tabs_page__WEBPACK_IMPORTED_MODULE_3__["TabsPage"],
        children: [
            {
                path: 'tab1',
                children: [
                    {
                        path: '',
                        loadChildren: '../tab1/tab1.module#Tab1PageModule'
                    }
                ]
            },
            {
                path: 'tab2',
                children: [
                    {
                        path: '',
                        loadChildren: '../tab2/tab2.module#Tab2PageModule'
                    }
                ]
            },
            {
                path: 'tab3',
                children: [
                    {
                        path: '',
                        loadChildren: '../tab3/tab3.module#Tab3PageModule'
                    }
                ]
            },
            {
                path: 'tab4',
                children: [
                    {
                        path: '',
                        loadChildren: '../tab4/tab4.module#Tab4PageModule'
                    }
                ]
            },
            {
                path: 'tab5',
                children: [
                    {
                        path: '',
                        loadChildren: '../tab5/tab5.module#Tab5PageModule'
                    }
                ]
            },
            {
                path: 'tab6',
                children: [
                    {
                        path: '',
                        loadChildren: '../tab6/tab6.module#Tab6PageModule'
                    }
                ]
            },
            {
                path: 'tab7',
                children: [
                    {
                        path: '',
                        loadChildren: '../tab7/tab7.module#Tab7PageModule'
                    }
                ]
            },
            {
                path: '',
                redirectTo: '/tabs/tab1',
                pathMatch: 'full'
            }
        ]
    },
    {
        path: '',
        redirectTo: '/tabs/tab1',
        pathMatch: 'full'
    }
];
var TabsPageRoutingModule = /** @class */ (function () {
    function TabsPageRoutingModule() {
    }
    TabsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)
            ],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], TabsPageRoutingModule);
    return TabsPageRoutingModule;
}());



/***/ })

}]);
//# sourceMappingURL=tabs-tabs-module.js.map