(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["signuppatron-signuppatron-module"],{

/***/ "./src/app/signuppatron/signuppatron.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/signuppatron/signuppatron.module.ts ***!
  \*****************************************************/
/*! exports provided: SignuppatronPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignuppatronPageModule", function() { return SignuppatronPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _signuppatron_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./signuppatron.page */ "./src/app/signuppatron/signuppatron.page.ts");







var routes = [
    {
        path: '',
        component: _signuppatron_page__WEBPACK_IMPORTED_MODULE_6__["SignuppatronPage"]
    }
];
var SignuppatronPageModule = /** @class */ (function () {
    function SignuppatronPageModule() {
    }
    SignuppatronPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_signuppatron_page__WEBPACK_IMPORTED_MODULE_6__["SignuppatronPage"]]
        })
    ], SignuppatronPageModule);
    return SignuppatronPageModule;
}());



/***/ }),

/***/ "./src/app/signuppatron/signuppatron.page.html":
/*!*****************************************************!*\
  !*** ./src/app/signuppatron/signuppatron.page.html ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar class=\"toolbar_header\">\n    <ion-title></ion-title>\n    <ion-buttons slot=\"start\">\n        <ion-button (click)=\"goBack()\"\n          style=\"color: white;\">\n          <ion-icon slot=\"icon-only\" name=\"arrow-back\">\n          </ion-icon>\n          Back\n        </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<!-- The signup information -->\n\n<ion-content padding>\n  <form [formGroup]=\"new_patron_form\" \n        (submit)=\"signup(new_patron_form.value)\">\n\n    <ion-item class=\"skippinglabel\">\n      <ion-label class=\"skippinglabel\">\n         Let's get skipping.\n      </ion-label>\n    </ion-item>\n\n    <ion-item>\n      <ion-label color=\"black\" position=\"floating\">\n        First Name\n      </ion-label>\n      <ion-icon slot=\"start\" name=\"person-add\"></ion-icon>\n      <ion-input type=\"text\" formControlName=\"firstName\" required>\n      </ion-input>\n    </ion-item>\n\n    <ion-item>\n        <ion-label color=\"black\" position=\"floating\">\n          Last Name\n        </ion-label>\n        <ion-icon slot=\"start\" name=\"person-add\"></ion-icon>\n        <ion-input type=\"text\" formControlName=\"lastName\" required>\n        </ion-input>\n      </ion-item>\n\n    <ion-item>\n        <ion-label color=\"black\" position=\"floating\">\n          Phone Number\n        </ion-label>\n        <ion-icon slot=\"start\" name=\"call\"></ion-icon>\n        <ion-input type=\"number\" formControlName=\"phoneNumber\" required>\n        </ion-input>\n    </ion-item>\n\n    <ion-item>\n      <ion-label color=\"black\" position=\"floating\">\n        Email\n      </ion-label>\n      <ion-icon slot=\"start\" name=\"mail\"></ion-icon>\n      <ion-input type=\"email\" formControlName=\"email\" required>\n\n      </ion-input>\n    </ion-item>\n\n    <ion-item>\n        <ion-label color=\"black\" position=\"floating\">\n          Password\n        </ion-label>\n        <ion-icon slot=\"start\" name=\"key\"></ion-icon>\n        <ion-input type=\"password\" formControlName=\"password\" required>\n        </ion-input>\n    </ion-item>\n\n    <ion-item>\n      <ion-label color=\"black\" position=\"floating\">\n        Confirm Password\n      </ion-label>\n      <ion-icon slot=\"start\" name=\"key\"></ion-icon>\n      <ion-input type=\"password\" formControlName=\"confirmPassword\" required>\n      </ion-input>\n  </ion-item>\n\n    <ion-item>\n        <ion-checkbox color=\"primary\" checked=\"false\" \n          (ionChange)=\"toggleNewHasIDValue()\">\n        </ion-checkbox>\n        <ion-label class=\"photoIDText\" text-wrap>\n          I certify that I will present valid and \n          legal photo identification to any venue to\n           meet admissions and legal drinking age requirements\n        </ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n        <ion-checkbox color=\"primary\" checked=\"false\" \n          (ionChange)=\"toggleHasReadTermsAndConditions()\">\n        </ion-checkbox>\n        <ion-label class=\"photoIDText\" text-wrap>\n          I have read the Terms and Conditions\n        </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label (click) = \"openTermsAndConditions()\" text-wrap>\n        <u>Click</u> to read the Terms and Conditions\n      </ion-label>\n    </ion-item>\n    \n\n  </form>\n\n  <ion-button class=\"submitbutton\" expand=\"block\" type=\"submit\"\n              (click)=\"signup(new_patron_form.value)\"\n                [disabled]=\"(!new_patron_form.valid || !canPresentID || !hasReadTermsAndConditions)\">\n      Sign Up\n  </ion-button>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/signuppatron/signuppatron.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/signuppatron/signuppatron.page.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar_header {\n  --background: black;\n  color: white; }\n\nion-content {\n  --background: black; }\n\n.skippinglabel {\n  text-align: center;\n  font-style: bold;\n  font-size: 20pt;\n  font-family: \"Arial Rounded MT Bold\"; }\n\nform {\n  --background: black;\n  border-radius: 10px; }\n\n.submitbutton {\n  margin-top: 10px;\n  --background: darkgrey; }\n\n.photoIDText {\n  margin-left: 7px; }\n\n.TermsAndConditions {\n  color: blue; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2lnbnVwcGF0cm9uL0U6XFxVc2Vyc1xcU2FkZWdoaVRhYmFzXFxEZXNrdG9wXFxMaW5lU2tpcC9zcmNcXGFwcFxcc2lnbnVwcGF0cm9uXFxzaWdudXBwYXRyb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksbUJBQWEsRUFBQTs7QUFHakI7RUFDRyxrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLGVBQWU7RUFDZixvQ0FBb0MsRUFBQTs7QUFHdkM7RUFDSSxtQkFBYTtFQUNiLG1CQUFtQixFQUFBOztBQUd2QjtFQUNJLGdCQUFnQjtFQUNoQixzQkFBYSxFQUFBOztBQUdqQjtFQUNJLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLFdBQVcsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3NpZ251cHBhdHJvbi9zaWdudXBwYXRyb24ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRvb2xiYXJfaGVhZGVyIHtcbiAgICAtLWJhY2tncm91bmQ6IGJsYWNrO1xuICAgIGNvbG9yOiB3aGl0ZTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAgIC0tYmFja2dyb3VuZDogYmxhY2s7IFxufVxuXG4uc2tpcHBpbmdsYWJlbCB7XG4gICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICBmb250LXN0eWxlOiBib2xkO1xuICAgZm9udC1zaXplOiAyMHB0OyBcbiAgIGZvbnQtZmFtaWx5OiBcIkFyaWFsIFJvdW5kZWQgTVQgQm9sZFwiO1xufVxuXG5mb3JtIHtcbiAgICAtLWJhY2tncm91bmQ6IGJsYWNrO1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG5cbi5zdWJtaXRidXR0b24ge1xuICAgIG1hcmdpbi10b3A6IDEwcHg7XG4gICAgLS1iYWNrZ3JvdW5kOiBkYXJrZ3JleTtcbn1cblxuLnBob3RvSURUZXh0IHtcbiAgICBtYXJnaW4tbGVmdDogN3B4O1xufVxuXG4uVGVybXNBbmRDb25kaXRpb25zIHtcbiAgICBjb2xvcjogYmx1ZTtcbn1cblxuIl19 */"

/***/ }),

/***/ "./src/app/signuppatron/signuppatron.page.ts":
/*!***************************************************!*\
  !*** ./src/app/signuppatron/signuppatron.page.ts ***!
  \***************************************************/
/*! exports provided: SignuppatronPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignuppatronPage", function() { return SignuppatronPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals */ "./src/globals.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_5__);






var SignuppatronPage = /** @class */ (function () {
    function SignuppatronPage(router, globals, formBuilder) {
        this.router = router;
        this.globals = globals;
        this.formBuilder = formBuilder;
        this.canPresentID = false;
        this.hasReadTermsAndConditions = false;
    }
    SignuppatronPage.prototype.ngOnInit = function () {
        this.new_patron_form = this.formBuilder.group({
            firstName: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required),
            lastName: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required),
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required),
            phoneNumber: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required),
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required),
            confirmPassword: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required)
        });
        this.canPresentID = false;
        this.hasReadTermsAndConditions = false;
    };
    SignuppatronPage.prototype.ionViewWillAppear = function () {
        console.log("DEBUG: signupPatronPage will appear.");
        this.canPresentID = false;
        this.hasReadTermsAndConditions = false;
    };
    SignuppatronPage.prototype.ionViewWillLeave = function () {
        // we clear up the form by re-initializing it
        this.ngOnInit();
    };
    SignuppatronPage.prototype.goBack = function () {
        this.router.navigate(["splashscreen"]);
    };
    SignuppatronPage.prototype.signup = function (new_patron) {
        // we register the new user
        // and save all his information to firebase
        console.log("DEBUG: in signup.");
        console.log("\tnew_patron is: " + JSON.stringify(new_patron));
        var self = this;
        var firstName = new_patron.firstName;
        var lastName = new_patron.lastName;
        var email = new_patron.email;
        var phoneNumber = new_patron.phoneNumber;
        var password = new_patron.password;
        var confirmPassword = new_patron.confirmPassword;
        var successful = true;
        // create separate boolean value 
        // like var comfirmedPasswordSuccesfully = ....
        // set it to false if the 
        // password does not match confirmation password
        console.log("DEBUG: we are going to create a user with this information");
        if (password != confirmPassword) {
            alert("The passwords don't match.");
        }
        else {
            firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().createUserWithEmailAndPassword(email, password).catch(function (error) {
                // Handle Errors here.
                console.log(error);
                var errorCode = error.code;
                var errorMessage = error.message;
                console.log(error.message);
                if (errorCode.length > 0) {
                    alert('Failed to Sign Up.\n' + errorMessage);
                    successful = false;
                }
                else {
                    console.log("signup ok");
                    successful = true;
                }
                // ...
            }).then(function (user) {
                // if did not confirm password successfully && successful
                // throw an alert
                //if (did not confirm password successfully) --> alert
                // else if (successful)
                if (successful) {
                    var userID = firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser.uid;
                    var newPatron = {
                        firstName: firstName, lastName: lastName,
                        phoneNum: phoneNumber, uid: userID,
                        // array of purchased ticket information in string form
                        // It will eventually have the format for each contained object:
                        // (1) uid of venue @ which I purchased at
                        // (2) number of tickets purchased
                        // (3) price per ticket
                        // (4) starting hour per ticket
                        purchasedTickets: JSON.stringify([]),
                        // Temporary venue cart tickets
                        // It will have the format for each contained object in  {}:
                        // 1) venueUID: temp venue uid - for the venue that I want to order from
                        // 2) priceToBuy: Price at which I want to purchase the ticket
                        // 3) numToOrder: Number of tickets to order
                        // 4) startHour: Start hour for the one-hour time slot in which we buy tickets
                        //    represented as integers from 8 = 8 PM to 13 = 1 AM
                        // 5) venueType: String representation of the type of venue I am purchasing from 
                        //    either temporary or permanent
                        cart: JSON.stringify([])
                    };
                    var newPatronFirebase = firebase__WEBPACK_IMPORTED_MODULE_5__["database"]().ref('patronInfo/').push();
                    newPatronFirebase.set(JSON.parse(JSON.stringify(newPatron)));
                    // we also add the user type to the user types
                    var newPatronType = firebase__WEBPACK_IMPORTED_MODULE_5__["database"]().ref('userType/').push();
                    newPatronType.set({
                        uid: userID, type: _globals__WEBPACK_IMPORTED_MODULE_3__["USER_TYPES"].PATRON
                    });
                    self.globals.SET_CURRENT_LOGGED_IN_TYPE(_globals__WEBPACK_IMPORTED_MODULE_3__["USER_TYPES"].PATRON);
                    _globals__WEBPACK_IMPORTED_MODULE_3__["Globals"].CURRENT_PATRON_OBJ = newPatron;
                    // Move to the core of the app itself after logging in
                    self.router.navigate([_globals__WEBPACK_IMPORTED_MODULE_3__["PATRON_DEFAULT_TAB"]]);
                }
                else {
                    alert('Failed to Sign Up due to Invalid Information.\nPlease Try Again.');
                }
            });
        }
    };
    SignuppatronPage.prototype.toggleNewHasIDValue = function () {
        this.canPresentID = !this.canPresentID;
    };
    SignuppatronPage.prototype.toggleHasReadTermsAndConditions = function () {
        this.hasReadTermsAndConditions = !this.hasReadTermsAndConditions;
    };
    SignuppatronPage.prototype.openTermsAndConditions = function () {
        var parmaeterOBJ = { returnURL: "/signuppatron" };
        this.router.navigate(['/terms-and-conditions-page', parmaeterOBJ]);
    };
    SignuppatronPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-signuppatron',
            template: __webpack_require__(/*! ./signuppatron.page.html */ "./src/app/signuppatron/signuppatron.page.html"),
            styles: [__webpack_require__(/*! ./signuppatron.page.scss */ "./src/app/signuppatron/signuppatron.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _globals__WEBPACK_IMPORTED_MODULE_3__["Globals"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]])
    ], SignuppatronPage);
    return SignuppatronPage;
}());



/***/ })

}]);
//# sourceMappingURL=signuppatron-signuppatron-module.js.map