(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["signupvenue-signupvenue-module"],{

/***/ "./src/app/signupvenue/signupvenue.module.ts":
/*!***************************************************!*\
  !*** ./src/app/signupvenue/signupvenue.module.ts ***!
  \***************************************************/
/*! exports provided: SignupvenuePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignupvenuePageModule", function() { return SignupvenuePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _signupvenue_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./signupvenue.page */ "./src/app/signupvenue/signupvenue.page.ts");







var routes = [
    {
        path: '',
        component: _signupvenue_page__WEBPACK_IMPORTED_MODULE_6__["SignupvenuePage"]
    }
];
var SignupvenuePageModule = /** @class */ (function () {
    function SignupvenuePageModule() {
    }
    SignupvenuePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_signupvenue_page__WEBPACK_IMPORTED_MODULE_6__["SignupvenuePage"]]
        })
    ], SignupvenuePageModule);
    return SignupvenuePageModule;
}());



/***/ }),

/***/ "./src/app/signupvenue/signupvenue.page.html":
/*!***************************************************!*\
  !*** ./src/app/signupvenue/signupvenue.page.html ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar class=\"toolbar_header\">\n      <ion-title></ion-title>\n      <ion-buttons slot=\"start\">\n          <ion-button (click)=\"goBack()\"\n            style=\"color: white;\">\n            <ion-icon slot=\"icon-only\" name=\"arrow-back\">\n            </ion-icon>\n            Back\n          </ion-button>\n      </ion-buttons>\n    </ion-toolbar>\n  </ion-header>\n\n<ion-content>\n\n    <ion-item class=\"titleitem\" lines=\"none\">\n        <ion-img class=\"logoimage\"\n         [src]=\"logourl\"></ion-img>\n    </ion-item>\n\n    <ion-item class=\"titleitem\" lines=\"none\">\n      <ion-label class=\"textlabel\">\n        Register As \n      </ion-label>\n    </ion-item>\n\n\n    <ion-item class=\"titleitem\" lines=\"none\">\n        <ion-button class=\"usertypebutton\"\n          (click)=\"registerTemporaryVenue()\">\n          Temporary Venue\n        </ion-button>\n      </ion-item>\n      <!---\n      <ion-item class=\"titleitem\" lines=\"none\"\n              style=\"margin-top: 10px;\">\n        <ion-button class=\"usertypebutton\"\n          (click)=\"registerPermanentVenue()\">\n          Permanent Venue\n        </ion-button>\n      </ion-item>-->\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/signupvenue/signupvenue.page.scss":
/*!***************************************************!*\
  !*** ./src/app/signupvenue/signupvenue.page.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar_header, ion-header, ion-content {\n  --background: black; }\n\n.titleitem {\n  --background: black;\n  align-content: center; }\n\n.usertypebutton {\n  margin: 0 auto;\n  width: 300px;\n  height: 40px;\n  font-size: 15pt;\n  color: black;\n  background-color: lightgrey;\n  --background: lightgrey;\n  text-align: center;\n  font-style: bold;\n  font-family: \"Arial Rounded MT Bold\";\n  border-radius: 10px; }\n\n.logoimage {\n  display: block;\n  width: 200px;\n  height: 200px;\n  background-color: transparent;\n  text-align: center;\n  margin: 0 auto; }\n\n.titleitem {\n  --background: black;\n  align-content: center; }\n\n.textlabel {\n  color: white;\n  font-size: 30pt;\n  text-align: center;\n  font-style: bold; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2lnbnVwdmVudWUvRTpcXFVzZXJzXFxTYWRlZ2hpVGFiYXNcXERlc2t0b3BcXExpbmVTa2lwL3NyY1xcYXBwXFxzaWdudXB2ZW51ZVxcc2lnbnVwdmVudWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQWEsRUFBQTs7QUFHakI7RUFDSSxtQkFBYTtFQUNiLHFCQUFxQixFQUFBOztBQUd6QjtFQUNJLGNBQWM7RUFDZCxZQUFZO0VBQ1osWUFBWTtFQUNaLGVBQWU7RUFDZixZQUFZO0VBQ1osMkJBQTJCO0VBQzNCLHVCQUFhO0VBQ2Isa0JBQWtCO0VBQ2xCLGdCQUFnQjtFQUNoQixvQ0FBb0M7RUFDcEMsbUJBQW1CLEVBQUE7O0FBR3ZCO0VBQ0ksY0FBYztFQUNkLFlBQVk7RUFDWixhQUFhO0VBQ2IsNkJBQTZCO0VBQzdCLGtCQUFrQjtFQUNsQixjQUFjLEVBQUE7O0FBR2xCO0VBQ0ksbUJBQWE7RUFDYixxQkFBcUIsRUFBQTs7QUFHekI7RUFDSSxZQUFZO0VBQ1osZUFBZTtFQUNmLGtCQUFrQjtFQUNsQixnQkFBZ0IsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3NpZ251cHZlbnVlL3NpZ251cHZlbnVlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50b29sYmFyX2hlYWRlciwgaW9uLWhlYWRlciwgaW9uLWNvbnRlbnQge1xuICAgIC0tYmFja2dyb3VuZDogYmxhY2s7XG59XG5cbi50aXRsZWl0ZW0ge1xuICAgIC0tYmFja2dyb3VuZDogYmxhY2s7IFxuICAgIGFsaWduLWNvbnRlbnQ6IGNlbnRlcjtcbn1cblxuLnVzZXJ0eXBlYnV0dG9uIHtcbiAgICBtYXJnaW46IDAgYXV0bztcbiAgICB3aWR0aDogMzAwcHg7XG4gICAgaGVpZ2h0OiA0MHB4O1xuICAgIGZvbnQtc2l6ZTogMTVwdDtcbiAgICBjb2xvcjogYmxhY2s7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogbGlnaHRncmV5O1xuICAgIC0tYmFja2dyb3VuZDogbGlnaHRncmV5O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXN0eWxlOiBib2xkO1xuICAgIGZvbnQtZmFtaWx5OiBcIkFyaWFsIFJvdW5kZWQgTVQgQm9sZFwiO1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG5cbi5sb2dvaW1hZ2Uge1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIHdpZHRoOiAyMDBweDtcbiAgICBoZWlnaHQ6IDIwMHB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBtYXJnaW46IDAgYXV0bztcbn1cblxuLnRpdGxlaXRlbSB7XG4gICAgLS1iYWNrZ3JvdW5kOiBibGFjazsgXG4gICAgYWxpZ24tY29udGVudDogY2VudGVyO1xufVxuXG4udGV4dGxhYmVsIHtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgZm9udC1zaXplOiAzMHB0O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXN0eWxlOiBib2xkO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/signupvenue/signupvenue.page.ts":
/*!*************************************************!*\
  !*** ./src/app/signupvenue/signupvenue.page.ts ***!
  \*************************************************/
/*! exports provided: SignupvenuePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignupvenuePage", function() { return SignupvenuePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var SignupvenuePage = /** @class */ (function () {
    function SignupvenuePage(router) {
        this.router = router;
        this.logourl = "../assets/lineuplogo.png";
    }
    SignupvenuePage.prototype.ngOnInit = function () {
    };
    SignupvenuePage.prototype.goBack = function () {
        this.router.navigate(["splashscreen"]);
    };
    SignupvenuePage.prototype.registerTemporaryVenue = function () {
        console.log("Registering as temporary venue");
        this.router.navigate(["/registertemporaryvenue"]);
    };
    SignupvenuePage.prototype.registerPermanentVenue = function () {
        console.log("Registering as permanent venue");
        this.router.navigate(["/registerpermanentvenue"]);
    };
    SignupvenuePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-signupvenue',
            template: __webpack_require__(/*! ./signupvenue.page.html */ "./src/app/signupvenue/signupvenue.page.html"),
            styles: [__webpack_require__(/*! ./signupvenue.page.scss */ "./src/app/signupvenue/signupvenue.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], SignupvenuePage);
    return SignupvenuePage;
}());



/***/ })

}]);
//# sourceMappingURL=signupvenue-signupvenue-module.js.map