(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["splashscreen-splashscreen-module"],{

/***/ "./src/app/splashscreen/splashscreen.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/splashscreen/splashscreen.module.ts ***!
  \*****************************************************/
/*! exports provided: SplashscreenPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SplashscreenPageModule", function() { return SplashscreenPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _splashscreen_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./splashscreen.page */ "./src/app/splashscreen/splashscreen.page.ts");







var routes = [
    {
        path: '',
        component: _splashscreen_page__WEBPACK_IMPORTED_MODULE_6__["SplashscreenPage"]
    }
];
var SplashscreenPageModule = /** @class */ (function () {
    function SplashscreenPageModule() {
    }
    SplashscreenPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_splashscreen_page__WEBPACK_IMPORTED_MODULE_6__["SplashscreenPage"]]
        })
    ], SplashscreenPageModule);
    return SplashscreenPageModule;
}());



/***/ }),

/***/ "./src/app/splashscreen/splashscreen.page.html":
/*!*****************************************************!*\
  !*** ./src/app/splashscreen/splashscreen.page.html ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- This is the first screen that users see -->\n<!-- After opening the app. They have an option\n     to either log in or sign up as patrons or venues\n-->\n\n<ion-content class=\"splashbackground\">\n\n  <ion-item class=\"titleitem\" lines=\"none\">\n    <ion-label class=\"title\">\n     <br>LineSkip\n    </ion-label>\n  </ion-item>\n\n <ion-item class=\"titleitem\" lines=\"none\">\n    <ion-img class=\"logoimage\"\n     [src]=\"logourl\"></ion-img>\n  </ion-item>\n\n  <ion-item class=\"titleitem\" lines=\"none\">\n    <ion-label class=\"textlabel\">\n      Sign Up As\n    </ion-label>\n  </ion-item>\n\n  <ion-item class=\"titleitem\" lines=\"none\">\n    <ion-button class=\"usertypebutton\"\n      (click)=\"signUpPatron()\">\n      Patrons\n    </ion-button>\n  </ion-item>\n\n  <ion-item class=\"titleitem\" lines=\"none\"\n          style=\"margin-top: 10px;\">\n    <ion-button class=\"usertypebutton\"\n      (click)=\"signUpVenue()\">\n      Venues\n    </ion-button>\n  </ion-item>\n\n  <ion-item class=\"titleitem\" lines=\"none\"\n          style=\"margin-top: 10px;\">\n    <ion-label class=\"loginbutton\"\n      (click)=\"logInUser()\">\n      Or <u>Login</u>\n    </ion-label>\n  </ion-item>\n  \n</ion-content>\n"

/***/ }),

/***/ "./src/app/splashscreen/splashscreen.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/splashscreen/splashscreen.page.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".splashbackground {\n  --background: black; }\n\n.titleitem {\n  --background: black;\n  align-content: center; }\n\n.title {\n  color: white;\n  font-size: 30pt;\n  text-align: center;\n  font-style: bold;\n  width: 100%;\n  background-color: transparent;\n  font-family: \"Arial Rounded MT Bold\"; }\n\nion-item {\n  margin-left: 0px;\n  margin-right: 0px;\n  width: 100% !important;\n  background-color: black; }\n\n.logoimage {\n  display: block;\n  width: 200px;\n  height: 200px;\n  background-color: transparent;\n  text-align: center;\n  margin: 0 auto; }\n\n.textlabel {\n  color: white;\n  font-size: 20pt;\n  text-align: center;\n  font-style: bold; }\n\n.usertypebutton {\n  margin: 0 auto;\n  width: 200px;\n  height: 40px;\n  font-size: 18pt;\n  color: black;\n  background-color: lightgrey;\n  --background: lightgrey;\n  text-align: center;\n  font-style: bold;\n  font-family: \"Arial Rounded MT Bold\";\n  border-radius: 10px; }\n\n.loginbutton {\n  margin: 0 auto;\n  font-size: 17pt;\n  color: white;\n  font-style: bold;\n  text-align: center;\n  --background: transparent;\n  border-color: transparent; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc3BsYXNoc2NyZWVuL0U6XFxVc2Vyc1xcU2FkZWdoaVRhYmFzXFxEZXNrdG9wXFxMaW5lU2tpcC9zcmNcXGFwcFxcc3BsYXNoc2NyZWVuXFxzcGxhc2hzY3JlZW4ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQWEsRUFBQTs7QUFHakI7RUFDSSxtQkFBYTtFQUNiLHFCQUFxQixFQUFBOztBQUd6QjtFQUNJLFlBQVk7RUFDWixlQUFlO0VBQ2Ysa0JBQWtCO0VBQ2xCLGdCQUFnQjtFQUNoQixXQUFXO0VBQ1gsNkJBQTZCO0VBQzdCLG9DQUFvQyxFQUFBOztBQUd4QztFQUNJLGdCQUFnQjtFQUNoQixpQkFBaUI7RUFDakIsc0JBQXNCO0VBQ3RCLHVCQUF1QixFQUFBOztBQUczQjtFQUNJLGNBQWM7RUFDZCxZQUFZO0VBQ1osYUFBYTtFQUNiLDZCQUE2QjtFQUM3QixrQkFBa0I7RUFDbEIsY0FBYyxFQUFBOztBQUdsQjtFQUNJLFlBQVk7RUFDWixlQUFlO0VBQ2Ysa0JBQWtCO0VBQ2xCLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLGNBQWM7RUFDZCxZQUFZO0VBQ1osWUFBWTtFQUNaLGVBQWU7RUFDZixZQUFZO0VBQ1osMkJBQTJCO0VBQzNCLHVCQUFhO0VBQ2Isa0JBQWtCO0VBQ2xCLGdCQUFnQjtFQUNoQixvQ0FBb0M7RUFDcEMsbUJBQW1CLEVBQUE7O0FBSXZCO0VBQ0ksY0FBYztFQUNkLGVBQWU7RUFDZixZQUFZO0VBQ1osZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQix5QkFBYTtFQUNiLHlCQUF5QixFQUFBIiwiZmlsZSI6InNyYy9hcHAvc3BsYXNoc2NyZWVuL3NwbGFzaHNjcmVlbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc3BsYXNoYmFja2dyb3VuZCB7XG4gICAgLS1iYWNrZ3JvdW5kOiBibGFjaztcbn1cblxuLnRpdGxlaXRlbSB7XG4gICAgLS1iYWNrZ3JvdW5kOiBibGFjazsgXG4gICAgYWxpZ24tY29udGVudDogY2VudGVyO1xufVxuXG4udGl0bGUge1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBmb250LXNpemU6IDMwcHQ7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtc3R5bGU6IGJvbGQ7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gICAgZm9udC1mYW1pbHk6IFwiQXJpYWwgUm91bmRlZCBNVCBCb2xkXCI7XG59XG5cbmlvbi1pdGVtIHtcbiAgICBtYXJnaW4tbGVmdDogMHB4O1xuICAgIG1hcmdpbi1yaWdodDogMHB4O1xuICAgIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XG59XG5cbi5sb2dvaW1hZ2Uge1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIHdpZHRoOiAyMDBweDtcbiAgICBoZWlnaHQ6IDIwMHB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBtYXJnaW46IDAgYXV0bztcbn1cblxuLnRleHRsYWJlbCB7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIGZvbnQtc2l6ZTogMjBwdDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1zdHlsZTogYm9sZDtcbn1cblxuLnVzZXJ0eXBlYnV0dG9uIHtcbiAgICBtYXJnaW46IDAgYXV0bztcbiAgICB3aWR0aDogMjAwcHg7XG4gICAgaGVpZ2h0OiA0MHB4O1xuICAgIGZvbnQtc2l6ZTogMThwdDtcbiAgICBjb2xvcjogYmxhY2s7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogbGlnaHRncmV5O1xuICAgIC0tYmFja2dyb3VuZDogbGlnaHRncmV5O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXN0eWxlOiBib2xkO1xuICAgIGZvbnQtZmFtaWx5OiBcIkFyaWFsIFJvdW5kZWQgTVQgQm9sZFwiO1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG5cbn1cblxuLmxvZ2luYnV0dG9uIHtcbiAgICBtYXJnaW46IDAgYXV0bztcbiAgICBmb250LXNpemU6IDE3cHQ7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIGZvbnQtc3R5bGU6IGJvbGQ7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gICAgYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/splashscreen/splashscreen.page.ts":
/*!***************************************************!*\
  !*** ./src/app/splashscreen/splashscreen.page.ts ***!
  \***************************************************/
/*! exports provided: SplashscreenPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SplashscreenPage", function() { return SplashscreenPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var SplashscreenPage = /** @class */ (function () {
    function SplashscreenPage(router) {
        this.router = router;
        this.logourl = "../assets/lineuplogo.png";
    }
    SplashscreenPage.prototype.ngOnInit = function () {
    };
    SplashscreenPage.prototype.signUpPatron = function () {
        console.log("WE SIGN UP AS PATRON");
        this.router.navigate(["/signuppatron"]);
    };
    SplashscreenPage.prototype.signUpVenue = function () {
        console.log("WE SIGN UP AS VENUE");
        this.router.navigate(["signupvenue"]);
    };
    SplashscreenPage.prototype.logInUser = function () {
        console.log("WE LOG IN USER");
        this.router.navigate(["login"]);
    };
    SplashscreenPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-splashscreen',
            template: __webpack_require__(/*! ./splashscreen.page.html */ "./src/app/splashscreen/splashscreen.page.html"),
            styles: [__webpack_require__(/*! ./splashscreen.page.scss */ "./src/app/splashscreen/splashscreen.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], SplashscreenPage);
    return SplashscreenPage;
}());



/***/ })

}]);
//# sourceMappingURL=splashscreen-splashscreen-module.js.map