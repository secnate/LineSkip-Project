(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["add-temp-venue-to-cart-add-temp-venue-to-cart-module"],{

/***/ "./src/app/add-temp-venue-to-cart/add-temp-venue-to-cart.module.ts":
/*!*************************************************************************!*\
  !*** ./src/app/add-temp-venue-to-cart/add-temp-venue-to-cart.module.ts ***!
  \*************************************************************************/
/*! exports provided: AddTempVenueToCartPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddTempVenueToCartPageModule", function() { return AddTempVenueToCartPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _add_temp_venue_to_cart_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./add-temp-venue-to-cart.page */ "./src/app/add-temp-venue-to-cart/add-temp-venue-to-cart.page.ts");







var routes = [
    {
        path: '',
        component: _add_temp_venue_to_cart_page__WEBPACK_IMPORTED_MODULE_6__["AddTempVenueToCartPage"]
    }
];
var AddTempVenueToCartPageModule = /** @class */ (function () {
    function AddTempVenueToCartPageModule() {
    }
    AddTempVenueToCartPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_add_temp_venue_to_cart_page__WEBPACK_IMPORTED_MODULE_6__["AddTempVenueToCartPage"]]
        })
    ], AddTempVenueToCartPageModule);
    return AddTempVenueToCartPageModule;
}());



/***/ }),

/***/ "./src/app/add-temp-venue-to-cart/add-temp-venue-to-cart.page.html":
/*!*************************************************************************!*\
  !*** ./src/app/add-temp-venue-to-cart/add-temp-venue-to-cart.page.html ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar class=\"toolbar_header\">\n    <ion-title></ion-title>\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"goBack()\"\n        class=\"backButton\">\n        <ion-icon slot=\"icon-only\" name=\"arrow-back\">\n        </ion-icon>\n          Back\n        </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-item>\n    <ion-label class=\"rangeLabel\">\n      {{ getTimeRange() }}\n    </ion-label>\n  </ion-item>\n\n  <ion-item>\n    <ion-label class=\"informationLabel\">\n      Information:\n    </ion-label>\n  </ion-item>\n\n  <ion-item>\n    <ion-label>\n        Ticket Price: {{ currentHourObject.ticketPrice }} \n    </ion-label>\n  </ion-item>\n    <ion-item *ngIf=\"currentHourObject.numTickets==0\">\n    <ion-text><pre>No Tickets Available For Purchase</pre></ion-text>\n    </ion-item>\n  <ion-item *ngIf=\"currentHourObject.numTickets!=0\">\n    <ion-label>\n        Number of Available Tickets: {{ currentHourObject.numTickets }} \n    </ion-label>\n  </ion-item>\n\n  <ion-item *ngIf=\"currentHourObject.numTickets!=0\">\n    <ion-text><pre>Number to Order: </pre></ion-text>\n    <ion-input type=\"number\" [(ngModel)]=\"quantity\" min=\"1\" max= \"currentHourObject.numTickets\" step=\"1\"></ion-input>\n  </ion-item>\n  <ion-item *ngIf=\"currentHourObject.numTickets!=0\" lines=\"none\">\n      <ion-button expand=\"block\" class=\"orderButton\" \n                  size=\"medium\" (click)=\"addToCart()\">\n        Add to Cart\n      </ion-button>\n  </ion-item>\n\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/add-temp-venue-to-cart/add-temp-venue-to-cart.page.scss":
/*!*************************************************************************!*\
  !*** ./src/app/add-temp-venue-to-cart/add-temp-venue-to-cart.page.scss ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar_header {\n  --background: black;\n  color: white; }\n\n.backButton {\n  color: white; }\n\nion-header, ion-toolbar, ion-content {\n  --background: black;\n  color: white; }\n\n.rangeLabel {\n  color: black;\n  width: 100%;\n  font-style: bold;\n  font-size: 20pt;\n  text-align: center;\n  font-family: \"Arial Rounded MT Bold\"; }\n\n.informationLabel {\n  color: black;\n  font-size: 20pt;\n  font-family: \"Arial Rounded MT Bold\";\n  font-style: bold; }\n\n.orderButton {\n  color: white;\n  background-color: darkgrey;\n  --background: darkgrey;\n  width: 95%;\n  border-radius: 10px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWRkLXRlbXAtdmVudWUtdG8tY2FydC9FOlxcVXNlcnNcXFNhZGVnaGlUYWJhc1xcRGVza3RvcFxcTGluZVNraXAvc3JjXFxhcHBcXGFkZC10ZW1wLXZlbnVlLXRvLWNhcnRcXGFkZC10ZW1wLXZlbnVlLXRvLWNhcnQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksWUFBWSxFQUFBOztBQUVoQjtFQUNJLG1CQUFhO0VBQ2IsWUFBWSxFQUFBOztBQUVoQjtFQUNJLFlBQVk7RUFDWixXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLGVBQWU7RUFDZixrQkFBa0I7RUFDbEIsb0NBQW9DLEVBQUE7O0FBR3hDO0VBQ0ksWUFBWTtFQUNaLGVBQWU7RUFDZixvQ0FBb0M7RUFDcEMsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksWUFBWTtFQUNaLDBCQUEwQjtFQUMxQixzQkFBYTtFQUNiLFVBQVU7RUFDVixtQkFBbUIsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2FkZC10ZW1wLXZlbnVlLXRvLWNhcnQvYWRkLXRlbXAtdmVudWUtdG8tY2FydC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudG9vbGJhcl9oZWFkZXIge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiBibGFjaztcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufVxyXG5cclxuLmJhY2tCdXR0b24ge1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG59XHJcbmlvbi1oZWFkZXIsIGlvbi10b29sYmFyLCBpb24tY29udGVudCB7XHJcbiAgICAtLWJhY2tncm91bmQ6IGJsYWNrO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gIH1cclxuLnJhbmdlTGFiZWwge1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBmb250LXN0eWxlOiBib2xkO1xyXG4gICAgZm9udC1zaXplOiAyMHB0O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgZm9udC1mYW1pbHk6IFwiQXJpYWwgUm91bmRlZCBNVCBCb2xkXCI7XHJcbn1cclxuXHJcbi5pbmZvcm1hdGlvbkxhYmVsIHtcclxuICAgIGNvbG9yOiBibGFjaztcclxuICAgIGZvbnQtc2l6ZTogMjBwdDtcclxuICAgIGZvbnQtZmFtaWx5OiBcIkFyaWFsIFJvdW5kZWQgTVQgQm9sZFwiO1xyXG4gICAgZm9udC1zdHlsZTogYm9sZDtcclxufVxyXG5cclxuLm9yZGVyQnV0dG9uIHtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IGRhcmtncmV5O1xyXG4gICAgLS1iYWNrZ3JvdW5kOiBkYXJrZ3JleTtcclxuICAgIHdpZHRoOiA5NSU7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/add-temp-venue-to-cart/add-temp-venue-to-cart.page.ts":
/*!***********************************************************************!*\
  !*** ./src/app/add-temp-venue-to-cart/add-temp-venue-to-cart.page.ts ***!
  \***********************************************************************/
/*! exports provided: AddTempVenueToCartPage, tempVenueItems */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddTempVenueToCartPage", function() { return AddTempVenueToCartPage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tempVenueItems", function() { return tempVenueItems; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals */ "./src/globals.ts");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _tab3_tab3_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../tab3/tab3.page */ "./src/app/tab3/tab3.page.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");







var AddTempVenueToCartPage = /** @class */ (function () {
    function AddTempVenueToCartPage(route, r, globals, events) {
        var _this = this;
        this.route = route;
        this.r = r;
        this.globals = globals;
        this.events = events;
        this.r.params.subscribe(function (params) { _this.item = JSON.parse(params['selectedVenue']); });
        this.r.params.subscribe(function (params) { _this.startHour = params['hrSlotArray']; });
        this.quantity = 1;
        console.log("this is my item=======" + this.item);
        // Doing checks about the recieving of the values
        console.log("DEBUG entered add-temp-venue-to-cart page!");
        console.log("DEBUG: recieved selectedVenue: " + JSON.stringify(this.item));
        console.log("DEBUG: recieved startHour is: " + this.startHour);
    }
    AddTempVenueToCartPage_1 = AddTempVenueToCartPage;
    AddTempVenueToCartPage.prototype.addToCart = function () {
        var _this = this;
        if (this.currentHourObject.numTickets < this.quantity) {
            alert("Invalid Input;\n Cannot Order More Than is Available.");
        }
        else if (this.quantity < 1) {
            alert("Invalid Input;\n The Quantity Cannot be a Negative Value.");
        }
        else {
            var k = [];
            AddTempVenueToCartPage_1.Cart = new _tab3_tab3_page__WEBPACK_IMPORTED_MODULE_5__["cart"]();
            console.log("DEBUG: the AddTempVenueToCartPage.Cart is: " +
                JSON.stringify(AddTempVenueToCartPage_1.Cart));
            firebase__WEBPACK_IMPORTED_MODULE_4__["database"]().ref('Cart/' + firebase__WEBPACK_IMPORTED_MODULE_4__["auth"]().currentUser.uid).once('value', function (snapshot) {
                snapshot.forEach(function (cShot) {
                    k.push(cShot.key);
                    firebase__WEBPACK_IMPORTED_MODULE_4__["database"]().ref('Cart/' + cShot.ref.parent.toString().substring(cShot.ref.parent.toString().lastIndexOf('/')) + '/' +
                        k[k.length - 1]).on('value', function (cSnap) {
                        var m = cSnap.val();
                        // extract the object from the 
                        console.log("DEBUG: extracting cart from firebase!");
                        var extractedOBJ = JSON.parse(m);
                        console.log("DEBUG the extractedOBJ is: " + JSON.stringify(extractedOBJ));
                        // we now take the arrays from being strings to being arrays
                        var extractedOrderList = JSON.parse(extractedOBJ.orderList);
                        console.log("DEBUG: the extractedOrderList is: " + extractedOrderList);
                        var extractedCurrentOrder = JSON.parse(extractedOBJ.currentOrder);
                        console.log("DEBUG: the extractedCurrentOrder is: " + extractedCurrentOrder);
                        extractedOBJ.orderList = extractedOrderList;
                        extractedOBJ.currentOrder = extractedCurrentOrder;
                        AddTempVenueToCartPage_1.Cart = extractedOBJ;
                    });
                });
            });
            this.tempVenueItem = new tempVenueItems(this.uid, this.price, this.time, this.quantity);
            this.tempVenueItem.uid = this.item.uid;
            this.tempVenueItem.quantity = this.quantity;
            // processing ticket information in order to update any changes
            console.log("this is the ticket info before updating:" +
                JSON.stringify(this.item.ticketInfo));
            var extractedString = this.item.ticketInfo;
            // if there is a '[' or ']'
            if (extractedString.charAt(0) == '[') {
                extractedString = extractedString.substr(1); // remove leading [
            }
            if (extractedString[extractedString.length - 1] == ']') {
                extractedString = extractedString.slice(0, -1);
            }
            var splitUpObjects = extractedString.split("},");
            var i = 0;
            for (i = 0; i < splitUpObjects.length; i++) {
                if (splitUpObjects[i].slice(-1) != '}') {
                    // it does not have the end curly bracked 
                    // to close off object in string representation which was chopped off. 
                    // correct this mistake
                    splitUpObjects[i] = splitUpObjects[i] + "}";
                }
            }
            // now we parse things and save it to the ticket array
            var allObjectsToStringifyAtOnce = [];
            splitUpObjects.forEach(function (element) {
                var extractedElement = JSON.parse(element);
                if (extractedElement.startHour == _this.startHour) {
                    _this.tempVenueItem.price = extractedElement.ticketPrice;
                    _this.tempVenueItem.time = _this.startHour;
                    extractedElement.numTickets = extractedElement.numTickets - _this.quantity;
                    extractedElement.numSold = extractedElement.numSold + _this.quantity;
                    // *========*update temp venue here
                }
                allObjectsToStringifyAtOnce.push(extractedElement);
            });
            AddTempVenueToCartPage_1.Cart.currentOrder.items.push(this.tempVenueItem);
            AddTempVenueToCartPage_1.Cart.currentOrder.totalItems++;
            AddTempVenueToCartPage_1.Cart.currentOrder.totalPrice += this.tempVenueItem.price * this.quantity;
            AddTempVenueToCartPage_1.Cart.orderList[AddTempVenueToCartPage_1.Cart.orderList.length - 1] = AddTempVenueToCartPage_1.Cart.currentOrder;
            console.log("DEBUG: in add-temp-venue-to-cart-page.ts!");
            console.log("\tDEBUG: the AddTempVenueToCartPage.Cart is: " +
                JSON.stringify(AddTempVenueToCartPage_1.Cart));
            var s = {};
            s['userOrder'] = JSON.stringify(new _tab3_tab3_page__WEBPACK_IMPORTED_MODULE_5__["StringifiedCart"](AddTempVenueToCartPage_1.Cart));
            firebase__WEBPACK_IMPORTED_MODULE_4__["database"]().ref('Cart/' + firebase__WEBPACK_IMPORTED_MODULE_4__["auth"]().currentUser.uid).update(s);
            if (this.quantity > 1) {
                alert("These items has been added to your order.");
            }
            else if (this.quantity == 1) {
                alert("This item has been added to your order.");
            }
            // now we update the temporary venue about the tickets ordered
            var stringifiedArrayToUpdate = JSON.stringify(allObjectsToStringifyAtOnce);
            var tempVenueUid = this.item.uid;
            AddTempVenueToCartPage_1.tempVenueRef.orderByChild("uid").equalTo(tempVenueUid).limitToFirst(1).once("value", function (data) {
                // we extract the current temporary venue's information just once
                var data_keys = Object.keys(data.val());
                var extractedTempOBJ = data.val()[data_keys[0]];
                console.log("DEBUG: the extracted TEMP VENUE OBJECT TO UPDATE IS: " +
                    JSON.stringify(extractedTempOBJ));
                // now we update the object's values 
                //
                // we update specifically the TICKET_INFO and PURCHASER ID's
                extractedTempOBJ.ticketInfo = stringifiedArrayToUpdate;
                // we update the purchaser id's
                if (extractedTempOBJ.purchaserIDs == "[]") {
                    // an empty array, no one purchased yet
                    extractedTempOBJ.purchaserIDs = JSON.stringify([firebase__WEBPACK_IMPORTED_MODULE_4__["auth"]().currentUser.uid]);
                }
                else {
                    // the array is not empty
                    // Case 1: Patron already purchased tickets from there, so uid is in there
                    // Case 2: Patron did not purchased tickets from there so we add it in
                    var extractedUIDARRAY = JSON.parse(extractedTempOBJ.purchaserIDs);
                    var i = 0; // iterator
                    var alreadyBought = false;
                    for (i = 0; i < extractedUIDARRAY.length; i++) {
                        if (extractedUIDARRAY[i] == firebase__WEBPACK_IMPORTED_MODULE_4__["auth"]().currentUser.uid) {
                            alreadyBought = true;
                            break;
                        }
                    }
                    // if we did not buy it, we add the current user's id to the array,
                    // then we stringify it and save it to the exractedOBJ for updating firebase
                    // otherwise... what's the point?
                    if (!alreadyBought) {
                        extractedUIDARRAY.push(firebase__WEBPACK_IMPORTED_MODULE_4__["auth"]().currentUser.uid);
                        extractedTempOBJ.purchaserIDs = JSON.stringify(extractedUIDARRAY);
                    }
                }
                // so now we have the extractedTempOBJ with updated ticket info and purchaser
                // id information. we can push the data and update it in firebase
                var newInfo = firebase__WEBPACK_IMPORTED_MODULE_4__["database"]().ref('tempVenueInfo/' + data_keys[0]).update(extractedTempOBJ);
            });
            // before we nagivate to needed page
            this.events.publish('updatedData', Date.now());
            this.route.navigate(['/tabs/tab1']);
        }
    };
    AddTempVenueToCartPage.prototype.goBack = function () {
        this.route.navigate(['/temp-venue-detail', { selectedVenue: JSON.stringify(this.item) }]);
    };
    AddTempVenueToCartPage.prototype.ngOnInit = function () {
        var _this = this;
        console.log("DEBUG: THE PARAMETER IS: " + this.startHour);
        console.log("DEBUG: THE PARAMETER IS: " + this.item);
        var extractedString = this.item.ticketInfo;
        // if there is a '[' or ']'
        if (extractedString.charAt(0) == '[') {
            extractedString = extractedString.substr(1); // remove leading [
        }
        if (extractedString[extractedString.length - 1] == ']') {
            extractedString = extractedString.slice(0, -1);
        }
        var splitUpObjects = extractedString.split("},");
        var i = 0;
        for (i = 0; i < splitUpObjects.length; i++) {
            if (splitUpObjects[i].slice(-1) != '}') {
                // it does not have the end curly bracked 
                // to close off object in string representation which was chopped off. 
                // correct this mistake
                splitUpObjects[i] = splitUpObjects[i] + "}";
            }
        }
        splitUpObjects.forEach(function (element) {
            var extractedElement = JSON.parse(element);
            if (extractedElement.startHour == _this.startHour) {
                _this.currentHourObject = extractedElement;
            }
        });
        console.log("UPDATED HOURLY INFORMATION");
        console.log("\thourly object information is: " + JSON.stringify(this.currentHourObject));
        // Now initialize the hourly information
        // we initialize the hourly information
        // this.currentTempID = firebase.auth().currentUser.uid;
        // let tempVenueRef = firebase.database().ref('tempVenueInfo/');
        // var self = this;
        // each time the object gets updated, we update the time slot information
        // tempVenueRef.orderByChild("uid").equalTo(this.currentTempID).limitToFirst(1).on("value", function (data) {
        //   var data_keys = Object.keys(data.val());
        //   var extractedOBJ = data.val()[data_keys[0]];
        // update the global variable due to some modification of related data
        // Globals.CURRENT_TEMP_VENUE_OBJ = extractedOBJ;
        // continue with updating the page's data
        // self.updateHourlyInformation(extractedOBJ);
        // });
    };
    AddTempVenueToCartPage.prototype.getTimeRange = function () {
        return this.getStringHour(this.startHour) +
            " to " +
            this.getStringHour(Number(this.startHour) + 1);
    };
    AddTempVenueToCartPage.prototype.getStringHour = function (hour) {
        // returns "<# hour> <AM/PM>" string
        // for a given inputted number of the starting hour
        if (hour < 12) {
            return String(hour) + " PM";
        }
        else if (hour == 12) {
            return String(hour) + " AM";
        }
        else {
            // this is all AM times after 12 AM
            return String(hour - 12) + " AM";
        }
    };
    var AddTempVenueToCartPage_1;
    AddTempVenueToCartPage.tempVenueRef = firebase__WEBPACK_IMPORTED_MODULE_4__["database"]().ref('tempVenueInfo/');
    AddTempVenueToCartPage = AddTempVenueToCartPage_1 = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-add-temp-venue-to-cart',
            template: __webpack_require__(/*! ./add-temp-venue-to-cart.page.html */ "./src/app/add-temp-venue-to-cart/add-temp-venue-to-cart.page.html"),
            styles: [__webpack_require__(/*! ./add-temp-venue-to-cart.page.scss */ "./src/app/add-temp-venue-to-cart/add-temp-venue-to-cart.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _globals__WEBPACK_IMPORTED_MODULE_3__["Globals"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["Events"]])
    ], AddTempVenueToCartPage);
    return AddTempVenueToCartPage;
}());

var tempVenueItems = /** @class */ (function () {
    function tempVenueItems(
    //  iaddress:string,
    //  idescription:string,
    //  iendDate:string,
    //  istartDate:string,
    //  iname:string,
    //  iphoneNumber:string,
    iuid, iprice, itime, iquantity) {
        // this.address=iaddress;
        // this.description=idescription;
        // this.endDate=iendDate;
        // this.startDate=istartDate;
        // this.name=iname;
        // this.phoneNumber=iphoneNumber;
        this.uid = iuid;
        this.price = iprice;
        this.time = itime;
        this.quantity = iquantity;
    }
    return tempVenueItems;
}());



/***/ })

}]);
//# sourceMappingURL=add-temp-venue-to-cart-add-temp-venue-to-cart-module.js.map