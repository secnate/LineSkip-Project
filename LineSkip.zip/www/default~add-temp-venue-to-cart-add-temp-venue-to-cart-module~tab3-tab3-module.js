(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~add-temp-venue-to-cart-add-temp-venue-to-cart-module~tab3-tab3-module"],{

/***/ "./src/app/tab3/tab3.page.html":
/*!*************************************!*\
  !*** ./src/app/tab3/tab3.page.html ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<ion-header>\n    <ion-toolbar>\n      <ion-title>\n        Cart\n      </ion-title>\n  \n      <ion-buttons slot=\"start\">\n        <ion-button (click)=\"logout()\">\n          <ion-icon slot=\"icon-only\" \n                    class=\"exitButton\"\n                    name=\"exit\"></ion-icon>\n        </ion-button>\n      </ion-buttons>\n  \n      <ion-buttons slot=\"end\">\n        <ion-button class=\"exitButton\" (click)=\"clearCart(true)\">\n          Clear\n        </ion-button>\n      </ion-buttons>\n\n    </ion-toolbar>\n  \n  </ion-header>\n\n<ion-content>\n  <ion-item *ngFor=\"let item of extractedCartTickets\">\n    <!--(click)=\"goToOrder(ord)\">-->\n    <ion-grid>\n    <ion-row>\n      <ion-item no-padding lines=\"none\">\n        <ion-label text-left>\n          <b>Name: {{ namesExtractedTicketsDict[item.uid] }} </b>\n        </ion-label>\n      </ion-item>\n    </ion-row>\n\n    <ion-row>\n      <ion-item no-padding lines=\"none\">\n        <ion-label text-left>\n          <b>Start Time: </b>{{getStartTimeString(item.time)}}\n        </ion-label>\n      </ion-item>\n    </ion-row>\n\n    <ion-row>\n      <ion-item no-padding lines=\"none\">\n        <ion-label text-left>\n          <b>Total:</b> ${{ item.quantity * item.price}} (${{item.price}} Per Ticket)\n        </ion-label>\n      </ion-item>\n     </ion-row>\n\n     <ion-row> \n      <ion-item no-padding lines=\"none\">\n        <ion-label text-left>\n          <b> Quantity: </b>{{item.quantity}}\n        </ion-label>\n      </ion-item>\n      </ion-row>\n    </ion-grid>\n  </ion-item>\n\n    <ion-item lines=\"none\" *ngIf='totalPrice != 0'>\n      <ion-label lines=\"none\">\n        <b> Total Tickets: </b> {{totalTickets}}\n      </ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\" *ngIf='totalPrice != 0'>\n      <ion-label lines=\"none\">\n        <b>Total Price: </b> $ {{totalPrice}}\n      </ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-button class=\"checkoutButton\"\n                  *ngIf='totalPrice != 0'\n                  (click)=\"checkOutCart()\">Proceed to Checkout</ion-button>\n    </ion-item>\n\n    <!-- Show a message that the cart is empty -->\n    <ion-item lines=\"none\" *ngIf='totalPrice == 0'> \n      <ion-label class=\"noneLabel\">Your Cart is Empty</ion-label>\n    </ion-item>\n\n </ion-content>\n\n\n\n\n"

/***/ }),

/***/ "./src/app/tab3/tab3.page.scss":
/*!*************************************!*\
  !*** ./src/app/tab3/tab3.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header,\nion-toolbar {\n  --background: black;\n  color: white; }\n\n.exitButton {\n  color: white; }\n\n.checkoutButton {\n  color: white;\n  background-color: darkgrey;\n  --background: darkgrey;\n  width: 95%;\n  border-radius: 10px;\n  height: 50px;\n  font-style: bold;\n  font-size: 18pt; }\n\n.noneLabel {\n  font-size: 20pt;\n  font-style: bold;\n  text-align: center;\n  font-family: \"Arial Rounded MT Bold\";\n  width: 100%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGFiMy9FOlxcVXNlcnNcXFNhZGVnaGlUYWJhc1xcRGVza3RvcFxcTGluZVNraXAvc3JjXFxhcHBcXHRhYjNcXHRhYjMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOztFQUVJLG1CQUFhO0VBQ2IsWUFBWSxFQUFBOztBQUdoQjtFQUNJLFlBQVksRUFBQTs7QUFHaEI7RUFDSSxZQUFZO0VBQ1osMEJBQTBCO0VBQzFCLHNCQUFhO0VBQ2IsVUFBVTtFQUNWLG1CQUFtQjtFQUNuQixZQUFZO0VBQ1osZ0JBQWdCO0VBQ2hCLGVBQWUsRUFBQTs7QUFHbkI7RUFDSSxlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixvQ0FBb0M7RUFDcEMsV0FBVyxFQUFBIiwiZmlsZSI6InNyYy9hcHAvdGFiMy90YWIzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXIsXG5pb24tdG9vbGJhciB7XG4gICAgLS1iYWNrZ3JvdW5kOiBibGFjaztcbiAgICBjb2xvcjogd2hpdGU7XG59XG5cbi5leGl0QnV0dG9uIHtcbiAgICBjb2xvcjogd2hpdGU7XG59XG5cbi5jaGVja291dEJ1dHRvbiB7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIGJhY2tncm91bmQtY29sb3I6IGRhcmtncmV5O1xuICAgIC0tYmFja2dyb3VuZDogZGFya2dyZXk7XG4gICAgd2lkdGg6IDk1JTtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIGhlaWdodDogNTBweDtcbiAgICBmb250LXN0eWxlOiBib2xkO1xuICAgIGZvbnQtc2l6ZTogMThwdDtcbn1cblxuLm5vbmVMYWJlbCB7XG4gICAgZm9udC1zaXplOiAyMHB0O1xuICAgIGZvbnQtc3R5bGU6IGJvbGQ7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtZmFtaWx5OiBcIkFyaWFsIFJvdW5kZWQgTVQgQm9sZFwiO1xuICAgIHdpZHRoOiAxMDAlO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/tab3/tab3.page.ts":
/*!***********************************!*\
  !*** ./src/app/tab3/tab3.page.ts ***!
  \***********************************/
/*! exports provided: Tab3Page, StringifiedCart, cart, order */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab3Page", function() { return Tab3Page; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StringifiedCart", function() { return StringifiedCart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cart", function() { return cart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "order", function() { return order; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_paypal_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/paypal/ngx */ "./node_modules/@ionic-native/paypal/ngx/index.js");






var Tab3Page = /** @class */ (function () {
    function Tab3Page(route, events, payPal) {
        var _this = this;
        this.route = route;
        this.events = events;
        this.payPal = payPal;
        this.tempVenueRef = firebase__WEBPACK_IMPORTED_MODULE_3__["database"]().ref('tempVenueInfo/');
        this.extractedCartTickets = [];
        this.namesExtractedTicketsDict = {};
        // Function
        this.totalTickets = 0;
        this.totalPrice = 0;
        this.events.subscribe('updatedData', function (time) {
            // the information was updated in firebase, update page accordingly
            _this.ionViewDidEnter();
        });
    }
    Tab3Page.prototype.ionViewDidEnter = function () {
        this.totalTickets = 0;
        var self = this;
        this.allOrders = new cart();
        firebase__WEBPACK_IMPORTED_MODULE_3__["database"]().ref('Cart/' + firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().currentUser.uid).on('value', function (snapshot) {
            snapshot.forEach(function (cShot) {
                var stringifiedCartObject = cShot.val();
                var cartObjectWithStringifiedOrderListCurrentOrder = JSON.parse(stringifiedCartObject);
                //var extractedOrderList = JSON.parse(cartObjectWithStringifiedOrderListCurrentOrder);
                //var extractedCurrentOrder
                //self.allOrders = JSON.parse(x);
                //console.log(self.allOrders);
                console.log("DEBUG: in tab3, the stringifiedCartObject is: " + stringifiedCartObject);
                console.log("DEBUG: the extracted orderList is: " + cartObjectWithStringifiedOrderListCurrentOrder.orderList);
                console.log("DEBUG: the currentOrder is: " + cartObjectWithStringifiedOrderListCurrentOrder.currentOrder);
                self.tab3CurrentOrder = JSON.parse(cartObjectWithStringifiedOrderListCurrentOrder.orderList);
                self.tab3OrderList = JSON.parse(cartObjectWithStringifiedOrderListCurrentOrder.orderList);
                console.log("DEBUG: the tab3OrderList is: " + JSON.stringify(self.tab3OrderList));
                console.log("DEBUG: the tab3Orderlist[0].items is: " +
                    JSON.stringify(self.tab3OrderList[0].items[0]));
                self.extractedCartTickets = [];
                // now we iterate over each item and load all extracted items into the typescript array
                var i = 0;
                var j = 0;
                for (i = 0; i < self.tab3OrderList.length; i++) {
                    for (j = 0; j < self.tab3OrderList[i].items.length; j++) {
                        self.extractedCartTickets.push(self.tab3OrderList[i].items[j]);
                        self.totalTickets = self.totalTickets +
                            self.tab3OrderList[i].items[j].quantity;
                    }
                    self.totalPrice = self.tab3OrderList[i].totalPrice;
                }
            });
            // we continue here
            // We now extract the names for each temporary venue per ticket
            var tempVenueInfoRef = firebase__WEBPACK_IMPORTED_MODULE_3__["database"]().ref('tempVenueInfo/');
            self.namesExtractedTicketsDict = {};
            self.extractedCartTickets.forEach(function (element) {
                // we iterate over each of the tickets, take its uid and then map
                tempVenueInfoRef.orderByChild("uid").equalTo(element.uid).limitToFirst(1).once("value", function (data) {
                    var data_keys = Object.keys(data.val());
                    // this will only happen once
                    var extractedTempVenue = data.val()[data_keys[0]];
                    self.namesExtractedTicketsDict[element.uid] = extractedTempVenue.name;
                });
            });
        });
    };
    Tab3Page.prototype.goToOrder = function (x) {
        if (x.totalItems > 0) {
            this.route.navigate(['/tab8', { selectedOrder: JSON.stringify(x) }]);
        }
        else {
            alert("This order is has no items. Go to the home page and navigate to the items you would like to add to your order.");
        }
    };
    Tab3Page.prototype.getTempVenueName = function (tempVenueID) {
        var nameToReturn = "";
        this.tempVenueRef.orderByChild("uid").equalTo(tempVenueID).limitToFirst(1).once("value", function (data) {
            // we extract the current temporary venue's information just once
            var data_keys = Object.keys(data.val());
            var extractedTempOBJ = data.val()[data_keys[0]];
            nameToReturn = extractedTempOBJ.name;
        });
        return nameToReturn;
    };
    Tab3Page.prototype.getStartTimeString = function (numStartTime) {
        if (numStartTime < 12) {
            return numStartTime + " PM";
        }
        else if (numStartTime == 12) {
            return numStartTime + " AM";
        }
        else {
            return (numStartTime - 12) + " AM";
        }
    };
    Tab3Page.prototype.clearCart = function (showClearMessage) {
        // first we need to restore the tickets back 
        // to being available to being sold
        console.log("DEBUG: clearing cart");
        console.log("DEBUG: the extractedCartTickets is: " +
            JSON.stringify(this.extractedCartTickets));
        var i = 0;
        for (i = 0; i < this.extractedCartTickets.length; i++) {
            // we go back into firebase and restore the tickets
            this.restoreTickets(this.extractedCartTickets[i]);
        }
        // we just need to delete the cart from the firebase cart collection
        var toDelete = firebase__WEBPACK_IMPORTED_MODULE_3__["database"]().ref('Cart/' +
            firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().currentUser.uid).remove();
        this.extractedCartTickets = []; // no tickets here
        this.totalPrice = 0;
        this.events.publish('updatedData', Date.now());
        if (showClearMessage) {
            alert("Cleared Cart");
        }
    };
    Tab3Page.prototype.restoreTickets = function (ticketOBJ) {
        // crux of the issue
        // we restore the information of available tickets
        // we had previously placed to cart and don't want anymore
        var self = this;
        this.tempVenueRef.orderByChild("uid").equalTo(ticketOBJ.uid).limitToFirst(1).once("value", function (data) {
            // we extract the current temporary venue's information just once
            var data_keys = Object.keys(data.val());
            var extractedTempOBJ = data.val()[data_keys[0]];
            // OK now we do processing on the extractedTempObj's ticket info
            var extractedTicketInfo = extractedTempOBJ.ticketInfo;
            // strip up the '[' and ']'
            if (extractedTicketInfo.charAt(0) == '[') {
                extractedTicketInfo = extractedTicketInfo.substr(1); // remove leading [
            }
            if (extractedTicketInfo[extractedTicketInfo.length - 1] == ']') {
                extractedTicketInfo = extractedTicketInfo.slice(0, -1);
            }
            // now we split up the objects in the string 
            var splitUpObjects = extractedTicketInfo.split("},");
            // restore the last "}" for each object
            var i = 0;
            for (i = 0; i < splitUpObjects.length; i++) {
                if (splitUpObjects[i].slice(-1) != '}') {
                    // it does not have the end curly bracked 
                    // to close off object in string representation which was chopped off. 
                    // correct this mistake
                    splitUpObjects[i] = splitUpObjects[i] + "}";
                }
            }
            // now we parse things and save it to the ticket array
            var allObjectsToStringifyAtOnce = [];
            splitUpObjects.forEach(function (element) {
                var parsedElement = JSON.parse(element);
                // now we update the information
                if (parsedElement.startHour == ticketOBJ.time) {
                    // we are in the given time slot
                    // we increment the number of tickets here
                    parsedElement.numTickets = parsedElement.numTickets + ticketOBJ.quantity;
                }
                allObjectsToStringifyAtOnce.push(parsedElement);
            });
            // OK now we need to stringify the array and push it back up
            extractedTempOBJ.ticketInfo = JSON.stringify(allObjectsToStringifyAtOnce);
            console.log("DEBUG: restoring the following object: " + JSON.stringify(extractedTempOBJ));
            // now we update the information 
            var newInfo = firebase__WEBPACK_IMPORTED_MODULE_3__["database"]().ref('tempVenueInfo/' + data_keys[0]).update(extractedTempOBJ);
        });
    };
    // send a payment from the user to the app for the tickets
    Tab3Page.prototype.checkOutCart = function () {
        var _this = this;
        var self = this;
        this.payPal.init({
            PayPalEnvironmentProduction: 'YOUR_PRODUCTION_CLIENT_ID',
            PayPalEnvironmentSandbox: 'AS1OTZPk1DoQbj1pln9LNGVE-dkJuc4nXlvYCQZPOTn8I1Yk8cA93JStSRb4ooTk9qHiUb93crg4H4pe'
        }).then(function () {
            // Environments: PayPalEnvironmentNoNetwork, PayPalEnvironmentSandbox, PayPalEnvironmentProduction
            _this.payPal.prepareToRender('PayPalEnvironmentSandbox', new _ionic_native_paypal_ngx__WEBPACK_IMPORTED_MODULE_5__["PayPalConfiguration"]({
            // Only needed if you get an "Internal Service Error" after PayPal login!
            //payPalShippingAddressOption: 2 // PayPalShippingAddressOptionPayPal
            })).then(function () {
                var payment = new _ionic_native_paypal_ngx__WEBPACK_IMPORTED_MODULE_5__["PayPalPayment"](JSON.stringify(self.totalPrice), 'USD', JSON.stringify(self.totalTickets) + ' Tickets', 'sale');
                _this.payPal.renderSinglePaymentUI(payment).then(function () {
                    // Successfully paid
                    alert("You Have Purchased " + self.totalTickets + " Tickets");
                    self.clearCart(false); // just for now
                    // Example sandbox response
                    //
                    // {
                    //   "client": {
                    //     "environment": "sandbox",
                    //     "product_name": "PayPal iOS SDK",
                    //     "paypal_sdk_version": "2.16.0",
                    //     "platform": "iOS"
                    //   },
                    //   "response_type": "payment",
                    //   "response": {
                    //     "id": "PAY-1AB23456CD789012EF34GHIJ",
                    //     "state": "approved",
                    //     "create_time": "2016-10-03T13:33:33Z",
                    //     "intent": "sale"
                    //   }
                    // }
                }, function (error) {
                    // Error or render dialog closed without being successful
                    console.log("DEBUG: ERROR IN PURCHASING");
                    console.log("DEBUG: the error is: " + JSON.stringify(error));
                });
            }, function (error) {
                // Error in configuration
                console.log("DEBUG: ERROR IN CONFIGURATION");
                console.log("DEBUG: the error is: " + JSON.stringify(error));
            });
        }, function (error) {
            // Error in initialization, maybe PayPal isn't supported or something else
            console.log("DEBUG: ERROR IN INITIALIZATION");
            console.log("DEBUG: the error is: " + JSON.stringify(error));
        });
    };
    Tab3Page.prototype.logout = function () {
        var self = this;
        var fireBaseUser = firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().currentUser;
        console.log(fireBaseUser.uid + " userid");
        firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().signOut().then(function () {
            console.log("logout succeed");
            self.route.navigate(["/homepage"]);
            this.globals.ResetUserType();
            // Sign-out successful.
        }).catch(function (error) {
            // An error happened.
        });
    };
    Tab3Page = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-tab3',
            template: __webpack_require__(/*! ./tab3.page.html */ "./src/app/tab3/tab3.page.html"),
            styles: [__webpack_require__(/*! ./tab3.page.scss */ "./src/app/tab3/tab3.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Events"],
            _ionic_native_paypal_ngx__WEBPACK_IMPORTED_MODULE_5__["PayPal"]])
    ], Tab3Page);
    return Tab3Page;
}());

var StringifiedCart = /** @class */ (function () {
    function StringifiedCart(toCopy) {
        // we take the "cart" object and we use it to create the better
        // and stringified version of the cart for storage in the firebase backend
        this.orderList = JSON.stringify(toCopy.orderList);
        this.currentOrder = JSON.stringify(toCopy.currentOrder);
    }
    return StringifiedCart;
}());

var cart = /** @class */ (function () {
    function cart() {
        this.orderList = [];
        this.createOrder(JSON.stringify(new Date()));
    }
    cart.prototype.createOrder = function (orderDate) {
        var tOrder = new order(orderDate);
        this.orderList.push(tOrder);
        this.currentOrder = this.orderList[this.orderList.length - 1];
    };
    cart.prototype.addAnItem = function (x) {
        this.currentOrder.addAnItem(x);
        this.orderList[this.orderList.length - 1] = this.currentOrder;
    };
    return cart;
}());

var order = /** @class */ (function () {
    function order(orderDate) {
        this.items = [];
        this.totalItems = 0;
        this.totalPrice = 0;
        this.date = orderDate;
    }
    order.prototype.addAnItem = function (x) {
        this.items.push(x);
        this.totalItems++;
        this.totalPrice += x.price * x.quantity; //***** */
    };
    return order;
}());



/***/ })

}]);
//# sourceMappingURL=default~add-temp-venue-to-cart-add-temp-venue-to-cart-module~tab3-tab3-module.js.map