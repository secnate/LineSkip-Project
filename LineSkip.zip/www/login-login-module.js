(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login-login-module"],{

/***/ "./src/app/login/login.module.ts":
/*!***************************************!*\
  !*** ./src/app/login/login.module.ts ***!
  \***************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.page */ "./src/app/login/login.page.ts");







var routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]
    }
];
var LoginPageModule = /** @class */ (function () {
    function LoginPageModule() {
    }
    LoginPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
        })
    ], LoginPageModule);
    return LoginPageModule;
}());



/***/ }),

/***/ "./src/app/login/login.page.html":
/*!***************************************!*\
  !*** ./src/app/login/login.page.html ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar class=\"toolbar_header\">\n      <ion-title></ion-title>\n      <ion-buttons slot=\"start\">\n          <ion-button (click)=\"goBack()\"\n            style=\"color: white;\">\n            <ion-icon slot=\"icon-only\" name=\"arrow-back\">\n            </ion-icon>\n            Back\n          </ion-button>\n      </ion-buttons>\n    </ion-toolbar>\n  </ion-header>\n\n  <ion-content padding>\n      <form [formGroup]=\"login_form\" \n            (submit)=\"login(login_form.value)\">\n\n        <ion-item class=\"title\">\n          <ion-label class=\"title\">\n            Login\n          </ion-label>\n        </ion-item>\n\n        <ion-item>\n          <ion-label color=\"black\" position=\"floating\" class=\"namesection\">\n            Email\n          </ion-label>\n          <ion-icon slot=\"start\" name=\"mail\"></ion-icon>\n          <ion-input type=\"email\" formControlName=\"email\" required>\n          </ion-input>\n        </ion-item>\n    \n        <ion-item>\n            <ion-label color=\"black\" position=\"floating\" class=\"namesection\">\n              Password\n            </ion-label>\n            <ion-icon slot=\"start\" name=\"key\"></ion-icon>\n            <ion-input type=\"password\" formControlName=\"password\" required>\n            </ion-input>\n        </ion-item>\n        \n    \n        <ion-button class=\"submitbutton\" expand=\"block\" type=\"submit\"\n                  (click)=\"login(login_form.value)\"\n                  [disabled]=\"!login_form.valid\">\n          Login\n        </ion-button>\n\n      </form>\n\n  </ion-content>\n"

/***/ }),

/***/ "./src/app/login/login.page.scss":
/*!***************************************!*\
  !*** ./src/app/login/login.page.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar_header {\n  --background: black;\n  color: white; }\n\nion-header {\n  --background: black; }\n\nion-content {\n  background-color: black;\n  --background: black;\n  color: white; }\n\n.title {\n  color: black;\n  --background: white;\n  font-style: bold;\n  font-size: 30pt;\n  text-align: center;\n  font-family: \"Arial Rounded MT Bold\"; }\n\n.namesection {\n  font-size: 18pt;\n  color: black; }\n\nion-input {\n  font-size: 15pt; }\n\n.submitbutton {\n  margin-top: 10px;\n  --background: darkgrey;\n  font-size: 18pt; }\n\n.logoimage {\n  display: block;\n  width: 200px;\n  height: 200px;\n  background-color: transparent;\n  text-align: center;\n  margin: 0 auto; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vRTpcXFVzZXJzXFxTYWRlZ2hpVGFiYXNcXERlc2t0b3BcXExpbmVTa2lwL3NyY1xcYXBwXFxsb2dpblxcbG9naW4ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksbUJBQWEsRUFBQTs7QUFHakI7RUFDSSx1QkFBdUI7RUFDdkIsbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksWUFBWTtFQUNaLG1CQUFhO0VBQ2IsZ0JBQWdCO0VBQ2hCLGVBQWU7RUFDZixrQkFBa0I7RUFDbEIsb0NBQW9DLEVBQUE7O0FBR3hDO0VBQ0ksZUFBZTtFQUNmLFlBQVksRUFBQTs7QUFHaEI7RUFDSSxlQUFlLEVBQUE7O0FBR25CO0VBQ0ksZ0JBQWdCO0VBQ2hCLHNCQUFhO0VBQ2IsZUFBZSxFQUFBOztBQUduQjtFQUNJLGNBQWM7RUFDZCxZQUFZO0VBQ1osYUFBYTtFQUNiLDZCQUE2QjtFQUM3QixrQkFBa0I7RUFDbEIsY0FBYyxFQUFBIiwiZmlsZSI6InNyYy9hcHAvbG9naW4vbG9naW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRvb2xiYXJfaGVhZGVyIHtcbiAgICAtLWJhY2tncm91bmQ6IGJsYWNrO1xuICAgIGNvbG9yOiB3aGl0ZTtcbn1cblxuaW9uLWhlYWRlciB7XG4gICAgLS1iYWNrZ3JvdW5kOiBibGFjaztcbn1cblxuaW9uLWNvbnRlbnQge1xuICAgIGJhY2tncm91bmQtY29sb3I6IGJsYWNrO1xuICAgIC0tYmFja2dyb3VuZDogYmxhY2s7XG4gICAgY29sb3I6IHdoaXRlO1xufVxuXG4udGl0bGUge1xuICAgIGNvbG9yOiBibGFjaztcbiAgICAtLWJhY2tncm91bmQ6IHdoaXRlO1xuICAgIGZvbnQtc3R5bGU6IGJvbGQ7XG4gICAgZm9udC1zaXplOiAzMHB0O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LWZhbWlseTogXCJBcmlhbCBSb3VuZGVkIE1UIEJvbGRcIjtcbn1cblxuLm5hbWVzZWN0aW9uIHtcbiAgICBmb250LXNpemU6IDE4cHQ7XG4gICAgY29sb3I6IGJsYWNrO1xufVxuXG5pb24taW5wdXQge1xuICAgIGZvbnQtc2l6ZTogMTVwdDtcbn1cblxuLnN1Ym1pdGJ1dHRvbiB7XG4gICAgbWFyZ2luLXRvcDogMTBweDtcbiAgICAtLWJhY2tncm91bmQ6IGRhcmtncmV5O1xuICAgIGZvbnQtc2l6ZTogMThwdDtcbn1cblxuLmxvZ29pbWFnZSB7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgd2lkdGg6IDIwMHB4O1xuICAgIGhlaWdodDogMjAwcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIG1hcmdpbjogMCBhdXRvO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/login/login.page.ts":
/*!*************************************!*\
  !*** ./src/app/login/login.page.ts ***!
  \*************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals */ "./src/globals.ts");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_5__);






var LoginPage = /** @class */ (function () {
    function LoginPage(router, globals, formBuilder) {
        this.router = router;
        this.globals = globals;
        this.formBuilder = formBuilder;
        this.logourl = "../assets/lineuplogo.png";
    }
    LoginPage.prototype.ngOnInit = function () {
        this.login_form = this.formBuilder.group({
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required),
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required)
        });
    };
    LoginPage.prototype.ionViewWillLeave = function () {
        // we clear up the form by reinitializing it
        this.ngOnInit();
    };
    LoginPage.prototype.goBack = function () {
        this.router.navigate(["splashscreen"]);
    };
    LoginPage.prototype.login = function (user) {
        var self = this;
        var email = user.email;
        var password = user.password;
        var successful = true;
        firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().signInWithEmailAndPassword(email, password).catch(function (error) {
            console.log("DEBUG: FAILED TO LOG IN");
            // Handle Errors here.
            var errorCode = error.code;
            var errorMessage = error.message;
            console.log(errorCode);
            if (errorCode === 'auth/wrong-password') {
                alert('Wrong password.');
            }
            else if (errorCode === 'auth/user-not-found') {
                alert("Failed to Log In.\nUser does not exist");
            }
            console.log(error);
            successful = false;
        }).then(function (result) {
            console.log("DEBUG: in result. successful is: " + successful);
            var user = result;
            if (successful) {
                // we successfully logged in
                // we extract the current user's type
                var userid = firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser.uid;
                console.log("DEBUG: extracted userid is: " + userid);
                console.log("DEBUG: the logged in userid is: " + userid);
                var userTypesRef = firebase__WEBPACK_IMPORTED_MODULE_5__["database"]().ref('userType/');
                // first we figure out what type of user it is...
                // we extract the first one because there only is one user with a given uid
                userTypesRef.orderByChild("uid").equalTo(userid).limitToFirst(1).on("value", function (data) {
                    var data_keys = Object.keys(data.val());
                    // this will only happen once
                    var extractedOBJ = data.val()[data_keys[0]];
                    var extractedType = extractedOBJ.type;
                    console.log("\tThe extracted user data is: " + JSON.stringify(extractedOBJ));
                    console.log("\tTHE TYPE OF THE LOGGING IN USER IS " + extractedType);
                    // now we figure out what user type it is
                    if (extractedType == "") {
                        successful = false;
                    }
                    else {
                        // set the login types
                        if (extractedType == _globals__WEBPACK_IMPORTED_MODULE_4__["USER_TYPES"].PATRON) {
                            self.globals.SET_CURRENT_LOGGED_IN_TYPE(_globals__WEBPACK_IMPORTED_MODULE_4__["USER_TYPES"].PATRON);
                        }
                        else if (extractedType == _globals__WEBPACK_IMPORTED_MODULE_4__["USER_TYPES"].PERMANENT_VENUE) {
                            self.globals.SET_CURRENT_LOGGED_IN_TYPE(_globals__WEBPACK_IMPORTED_MODULE_4__["USER_TYPES"].PERMANENT_VENUE);
                        }
                        else if (extractedType == _globals__WEBPACK_IMPORTED_MODULE_4__["USER_TYPES"].TEMPORARY_VENUE) {
                            self.globals.SET_CURRENT_LOGGED_IN_TYPE(_globals__WEBPACK_IMPORTED_MODULE_4__["USER_TYPES"].TEMPORARY_VENUE);
                        }
                        else {
                            self.globals.ResetUserType();
                        }
                        console.log("DEBUG: extractedType is: " + extractedType);
                        console.log("AND SUCCESSFUL IS: " + successful);
                    }
                    if (successful) {
                        console.log("DEBUG: we are in here and entering it.");
                        // First we extract the object that contains the data of the logged in user
                        // And then we do routing here for the default tab that will appear
                        // based on the value of the current user
                        var userid_1 = firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser.uid; // userid of the logged in user/venue/patron... entity
                        if (self.globals.GET_CURRENT_LOGGED_IN_TYPE() == _globals__WEBPACK_IMPORTED_MODULE_4__["USER_TYPES"].PATRON) {
                            console.log("DEBUG: in login and we are extracting the patron data.");
                            // we extract the patron data from the database and save it a global variable
                            var patronDataRef = firebase__WEBPACK_IMPORTED_MODULE_5__["database"]().ref('patronInfo/');
                            patronDataRef.orderByChild("uid").equalTo(userid_1).limitToFirst(1).on("value", function (data) {
                                // this will only happen once
                                //
                                // There exists only one patron for a specified uid and we extract its data
                                console.log("DEBUG: IN HERE!");
                                var extractedData = null;
                                var data_keys = Object.keys(data.val());
                                extractedData = data.val()[data_keys[0]];
                                console.log("DEBUG: the extracted PATRON data is: " + JSON.stringify(extractedData));
                                // now we figure out if we were able to extract object successfully
                                console.log("DEBUG: the extractedData is: " + JSON.stringify(extractedData));
                                if (extractedData != null) {
                                    console.log("DEBUG: we are now logging in as a patron.");
                                    _globals__WEBPACK_IMPORTED_MODULE_4__["Globals"].CURRENT_PATRON_OBJ = extractedData;
                                    self.router.navigate([_globals__WEBPACK_IMPORTED_MODULE_4__["PATRON_DEFAULT_TAB"]]);
                                }
                                else {
                                    // this should never happen
                                    _globals__WEBPACK_IMPORTED_MODULE_4__["Globals"].CURRENT_PATRON_OBJ = null;
                                    alert("ERROR and INVALID CASE: Tried to log in as patron and could not recover the data at all!! THIS SHOULD NOT HAPPEN!");
                                }
                            });
                        }
                        else if (self.globals.GET_CURRENT_LOGGED_IN_TYPE() == _globals__WEBPACK_IMPORTED_MODULE_4__["USER_TYPES"].PERMANENT_VENUE) {
                            //TODO: EXTRACT THE PERMANENT VENUE AND SET IT T THE GLOBAL VARIABLE
                            alert('NEED TO FIX THE PERMANENT VENUE SIGNING IN STUFF AFTER FIGURING IT OUT');
                            console.log('\n\tTODO: EXTRACT THE PERMANENT VENUE AND SET IT T THE GLOBAL VARIABLE\n');
                            console.log("the permanent venue object's stringified ticketInfo array will eventually have the format for each contained object: \
                \n\t(1) numTickets per hour \
                \n\t(2) startHour for each hourly slot - which will range from 8 to 13 (1 AM)\
                \n\t(3) price per ticket");
                            _globals__WEBPACK_IMPORTED_MODULE_4__["Globals"].CURRENT_PERM_VENUE_OBJ = null;
                            self.router.navigate([_globals__WEBPACK_IMPORTED_MODULE_4__["PERM_VENUES_DEFAULT_TAB"]]);
                        }
                        else if (self.globals.GET_CURRENT_LOGGED_IN_TYPE() == _globals__WEBPACK_IMPORTED_MODULE_4__["USER_TYPES"].TEMPORARY_VENUE) {
                            //EXTRACT THE TEMPORARY VENUE AND THEN SET IT TO THE GLOBAL VARIABLE
                            // we extract the temporary venue data from the database and save it a global variable
                            var tempVenueRef = firebase__WEBPACK_IMPORTED_MODULE_5__["database"]().ref('tempVenueInfo/');
                            tempVenueRef.orderByChild("uid").equalTo(userid_1).limitToFirst(1).on("value", function (data) {
                                // this will only happen once
                                var extractedData = null;
                                var data_keys = Object.keys(data.val());
                                extractedData = data.val()[data_keys[0]];
                                console.log("DEBUG: the extracted temporary venue data is: " + JSON.stringify(extractedData));
                                // now we figure out if we were able to extract something
                                if (extractedData != null) {
                                    _globals__WEBPACK_IMPORTED_MODULE_4__["Globals"].CURRENT_TEMP_VENUE_OBJ = extractedData;
                                    self.router.navigate([_globals__WEBPACK_IMPORTED_MODULE_4__["TEMP_VENUES_DEFAULT_TAB"]]);
                                }
                                else {
                                    // this should never happen
                                    _globals__WEBPACK_IMPORTED_MODULE_4__["Globals"].CURRENT_TEMP_VENUE_OBJ = null;
                                    alert("ERROR and INVALID CASE: Tried to log in as temporary venue and could not recover the data at all!! \
                        THIS SHOULD NOT HAPPEN!");
                                }
                            });
                        }
                        else {
                            // it wasn't successful
                            console.log("IT WASN\"T SUCCESSFUL FOR SOME REASON!");
                            alert("ERROR: was not successful in figuring out what user type this is.");
                        }
                    }
                    else {
                        // it wasn't successful
                        console.log("IT WASN\"T SUCCESSFUL FOR SOME REASON!");
                        alert("ERROR: was not successful in figuring out what user type this is.");
                    }
                });
            }
        });
    };
    LoginPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-login',
            template: __webpack_require__(/*! ./login.page.html */ "./src/app/login/login.page.html"),
            styles: [__webpack_require__(/*! ./login.page.scss */ "./src/app/login/login.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _globals__WEBPACK_IMPORTED_MODULE_4__["Globals"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"]])
    ], LoginPage);
    return LoginPage;
}());

//-------------
/*      ORIGINAL CODE TO INSERT INTO   userTypesRef.orderByChild("uid").equalTo(userid).limitToFirst(1).on("value", function(data) function
          var data_keys = Object.keys(data.val());

          console.log("DEBUG: data_keys is: " + JSON.stringify(data_keys) );
          console.log("DEBUG: in loop - " + JSON.stringify( data.val()[ data_keys[0] ] ) );

          // this will only happen once
          var extractedOBJ = data.val()[ data_keys[0] ];
          console.log("DEBUG: the extractedObject is: " + extractedOBJ);
          console.log("DEBUG: IN userTypesRef.orderByChild.");
          console.log("DEBUG: THE DATA WE ARE PRINTING IS: " + JSON.stringify(extractedOBJ) );
          console.log("DEBUG: the printing type is: " + extractedOBJ.type );
          var extractedType = extractedOBJ.type;
          console.log("DEBUG: the extracted type is: " + extractedType);

          console.log("\tDEBUG: BEFORE GOING TO FIGUREOUT WHAT THE USER TYPE IS, ");
          console.log("\tWE HAVE THE FOLLOIWING EXTRACTED TYPE: " + extractedType);

          // now we figure out what user type it is
          if (extractedType == "") {
            console.log("DEBUG: in loginpage and setting successful false.");
            successful = false;
          }
          else {
            console.log("DEBUG: IN HERE");

            // set the login types
            if (extractedType == USER_TYPES.PATRON) {
              console.log("DEBUG: in loginpage and setting the extracted type as being patron");
              self.globals.SET_CURRENT_LOGGED_IN_TYPE(USER_TYPES.PATRON);
            }
            else if (extractedType == USER_TYPES.PERMANENT_VENUE) {
             self.globals.SET_CURRENT_LOGGED_IN_TYPE(USER_TYPES.PERMANENT_VENUE);
            }
            else if (extractedType == USER_TYPES.TEMPORARY_VENUE) {
             self.globals.SET_CURRENT_LOGGED_IN_TYPE(USER_TYPES.TEMPORARY_VENUE);
            }
            else {
              self.globals.ResetUserType();
            }

            console.log("DEBUG: extractedType is: " + extractedType);
            console.log("AND SUCCESSFUL IS: " + successful);
          }
          
          if (successful) {
            console.log("DEBUG: we are in here and entering it.");
            // First we extract the object that contains the data of the logged in user
            // And then we do routing here for the default tab that will appear
            // based on the value of the current user

            let userid = firebase.auth().currentUser.uid; // userid of the logged in user/venue/patron... entity

            if (self.globals.GET_CURRENT_LOGGED_IN_TYPE() == USER_TYPES.PATRON ) {
              console.log("DEBUG: in login and we are extracting the patron data.");
              // we extract the patron data from the database and save it a global variable
              let patronDataRef = firebase.database().ref('patronInfo/');
        
              var extractedData = null;
              patronDataRef.orderByChild("uid").equalTo(userid).on("value", function(data) {
                // this will only happen once
                data.forEach( function (data) {
                  extractedData = data.val();
                  console.log("DEBUG: the extracted PATRON data is: " + JSON.stringify(extractedData));
                });
              });

              // now we figure out if we were able to extract object successfully
              if (extractedData != null) {
                console.log("DEBUG: we are now logging in as a patron.");
                Globals.CURRENT_PATRON_OBJ = extractedData;
                self.router.navigate([PATRON_DEFAULT_TAB]);
              }
              else {
                // this should never happen
                Globals.CURRENT_PATRON_OBJ = null;
                alert("ERROR and INVALID CASE: Tried to log in as patron and could not recover the data at all!! THIS SHOULD NOT HAPPEN!");
              }
            }
            else if (self.globals.GET_CURRENT_LOGGED_IN_TYPE() == USER_TYPES.PERMANENT_VENUE) {
              //TODO: EXTRACT THE PERMANENT VENUE AND SET IT T THE GLOBAL VARIABLE
              alert('NEED TO FIX THE PERMANENT VENUE SIGNING IN STUFF AFTER FIGURING IT OUT');
              console.log('\n\tTODO: EXTRACT THE PERMANENT VENUE AND SET IT T THE GLOBAL VARIABLE\n')
              Globals.CURRENT_PERM_VENUE_OBJ = null;
              self.router.navigate([PERM_VENUES_DEFAULT_TAB]);
            }
            else if (self.globals.GET_CURRENT_LOGGED_IN_TYPE() == USER_TYPES.TEMPORARY_VENUE) {
              //EXTRACT THE TEMPORARY VENUE AND THEN SET IT TO THE GLOBAL VARIABLE
              // we extract the temporary venue data from the database and save it a global variable
              let tempVenueRef = firebase.database().ref('tempVenueInfo/');
        
              var extractedData = null;
              tempVenueRef.orderByChild("uid").equalTo(userid).on("value", function(data) {
              // this will only happen once
               data.forEach( function (data) {
                extractedData = data.val();
                console.log("DEBUG: the extracted TEMPORARY VENUE data is: " + JSON.stringify(extractedData));
                });
              });
        
              // now we figure out if we were able to extract something
              if (extractedData != null) {
                Globals.CURRENT_TEMP_VENUE_OBJ = extractedData;
                self.router.navigate([TEMP_VENUES_DEFAULT_TAB]);
              }
            else {
              // this should never happen
              Globals.CURRENT_TEMP_VENUE_OBJ = null;
              alert("ERROR and INVALID CASE: Tried to log in as temporary and could not recover the data at all!! \
                     THIS SHOULD NOT HAPPEN!");
            }
          }
          else {
            // it wasn't successful
            console.log("IT WASN\"T SUCCESSFUL!");
            alert("ERROR: was not successful in figuring out what user type this is.")
          }




*/


/***/ })

}]);
//# sourceMappingURL=login-login-module.js.map