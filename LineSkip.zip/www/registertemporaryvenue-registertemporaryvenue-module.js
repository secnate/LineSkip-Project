(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["registertemporaryvenue-registertemporaryvenue-module"],{

/***/ "./src/app/registertemporaryvenue/registertemporaryvenue.module.ts":
/*!*************************************************************************!*\
  !*** ./src/app/registertemporaryvenue/registertemporaryvenue.module.ts ***!
  \*************************************************************************/
/*! exports provided: RegistertemporaryvenuePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegistertemporaryvenuePageModule", function() { return RegistertemporaryvenuePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _registertemporaryvenue_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./registertemporaryvenue.page */ "./src/app/registertemporaryvenue/registertemporaryvenue.page.ts");







var routes = [
    {
        path: '',
        component: _registertemporaryvenue_page__WEBPACK_IMPORTED_MODULE_6__["RegistertemporaryvenuePage"]
    }
];
var RegistertemporaryvenuePageModule = /** @class */ (function () {
    function RegistertemporaryvenuePageModule() {
    }
    RegistertemporaryvenuePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_registertemporaryvenue_page__WEBPACK_IMPORTED_MODULE_6__["RegistertemporaryvenuePage"]]
        })
    ], RegistertemporaryvenuePageModule);
    return RegistertemporaryvenuePageModule;
}());



/***/ }),

/***/ "./src/app/registertemporaryvenue/registertemporaryvenue.page.html":
/*!*************************************************************************!*\
  !*** ./src/app/registertemporaryvenue/registertemporaryvenue.page.html ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar class=\"toolbar_header\">\n      <ion-title></ion-title>\n      <ion-buttons slot=\"start\">\n          <ion-button (click)=\"goBack()\"\n            style=\"color: white;\">\n            <ion-icon slot=\"icon-only\" name=\"arrow-back\">\n            </ion-icon>\n            Back\n          </ion-button>\n      </ion-buttons>\n    </ion-toolbar>\n  </ion-header>\n\n  <ion-content padding>\n      <form [formGroup]=\"new_temp_venue_form\" \n            (submit)=\"signup(new_temp_venue_form.value)\">\n    \n        <ion-item class=\"skippinglabel\">\n          <ion-label class=\"skippinglabel\">\n             New Temp. Venue\n          </ion-label>\n        </ion-item>\n    \n        <ion-item>\n          <ion-label color=\"black\" position=\"floating\">\n            Name\n          </ion-label>\n          <ion-icon slot=\"start\" name=\"person-add\"></ion-icon>\n          <ion-input type=\"text\" formControlName=\"name\" required>\n          </ion-input>\n        </ion-item>\n    \n        <ion-item>\n            <ion-label color=\"black\" position=\"floating\">\n              Address\n            </ion-label>\n            <ion-icon slot=\"start\" name=\"home\"></ion-icon>\n            <ion-input type=\"text\" formControlName=\"address\" required>\n            </ion-input>\n          </ion-item>\n    \n          <ion-item>\n              <ion-label color=\"black\" position=\"floating\">\n                Venue Description\n              </ion-label>\n              <ion-icon slot=\"start\" name=\"reorder\"></ion-icon>\n              <ion-input type=\"text\" formControlName=\"venueDescription\" required>\n              </ion-input>\n            </ion-item>\n    \n        <ion-item>\n          <ion-label color=\"black\" position=\"floating\">\n            Phone Number\n          </ion-label>\n          <ion-icon slot=\"start\" name=\"call\"></ion-icon>\n          <ion-input type=\"number\" formControlName=\"phoneNumber\" required>\n          </ion-input>\n        </ion-item>\n        <ion-item lines=\"none\">\n          <ion-checkbox color=\"primary\" checked=\"false\" \n            (ionChange)=\"toggleHasReadTermsAndConditions()\">\n          </ion-checkbox>\n          <ion-label class=\"photoIDText\" text-wrap>\n            I have read the Terms and Conditions\n          </ion-label>\n      </ion-item>\n        <ion-item>\n          <ion-label (click) = \"openTermsAndConditions()\" text-wrap>\n            <u>Click</u> to read the Terms and Conditions\n          </ion-label>\n        </ion-item>\n      </form>\n    \n      <ion-button class=\"submitbutton\" expand=\"block\" type=\"submit\"\n                  (click)=\"next(new_temp_venue_form.value)\"\n                  [disabled]=\"!new_temp_venue_form.valid || !hasReadTermsAndConditions\">\n          Next\n      </ion-button>\n    \n    </ion-content>\n"

/***/ }),

/***/ "./src/app/registertemporaryvenue/registertemporaryvenue.page.scss":
/*!*************************************************************************!*\
  !*** ./src/app/registertemporaryvenue/registertemporaryvenue.page.scss ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar_header, ion-header, ion-content {\n  --background: black; }\n\n.skippinglabel {\n  text-align: center;\n  font-style: bold;\n  font-size: 18pt;\n  font-family: \"Arial Rounded MT Bold\"; }\n\n.submitbutton {\n  margin-top: 10px;\n  --background: darkgrey; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcmVnaXN0ZXJ0ZW1wb3Jhcnl2ZW51ZS9FOlxcVXNlcnNcXFNhZGVnaGlUYWJhc1xcRGVza3RvcFxcTGluZVNraXAvc3JjXFxhcHBcXHJlZ2lzdGVydGVtcG9yYXJ5dmVudWVcXHJlZ2lzdGVydGVtcG9yYXJ5dmVudWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQWEsRUFBQTs7QUFHakI7RUFDSSxrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLGVBQWU7RUFDZixvQ0FBb0MsRUFBQTs7QUFHdkM7RUFDRyxnQkFBZ0I7RUFDaEIsc0JBQWEsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3JlZ2lzdGVydGVtcG9yYXJ5dmVudWUvcmVnaXN0ZXJ0ZW1wb3Jhcnl2ZW51ZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudG9vbGJhcl9oZWFkZXIsIGlvbi1oZWFkZXIsIGlvbi1jb250ZW50IHtcbiAgICAtLWJhY2tncm91bmQ6IGJsYWNrO1xufVxuXG4uc2tpcHBpbmdsYWJlbCB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtc3R5bGU6IGJvbGQ7XG4gICAgZm9udC1zaXplOiAxOHB0OyBcbiAgICBmb250LWZhbWlseTogXCJBcmlhbCBSb3VuZGVkIE1UIEJvbGRcIjtcbiB9XG5cbiAuc3VibWl0YnV0dG9uIHtcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgIC0tYmFja2dyb3VuZDogZGFya2dyZXk7XG59Il19 */"

/***/ }),

/***/ "./src/app/registertemporaryvenue/registertemporaryvenue.page.ts":
/*!***********************************************************************!*\
  !*** ./src/app/registertemporaryvenue/registertemporaryvenue.page.ts ***!
  \***********************************************************************/
/*! exports provided: RegistertemporaryvenuePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegistertemporaryvenuePage", function() { return RegistertemporaryvenuePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals */ "./src/globals.ts");





var RegistertemporaryvenuePage = /** @class */ (function () {
    function RegistertemporaryvenuePage(router, globals, formBuilder) {
        this.router = router;
        this.globals = globals;
        this.formBuilder = formBuilder;
        this.hasReadTermsAndConditions = false;
    }
    RegistertemporaryvenuePage.prototype.ngOnInit = function () {
        this.new_temp_venue_form = this.formBuilder.group({
            name: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required),
            address: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required),
            venueDescription: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required),
            phoneNumber: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required)
        });
        this.hasReadTermsAndConditions = false;
    };
    RegistertemporaryvenuePage.prototype.ionViewWillLeave = function () {
        this.ngOnInit();
    };
    RegistertemporaryvenuePage.prototype.goBack = function () {
        this.router.navigate(["/signupvenue"]);
    };
    RegistertemporaryvenuePage.prototype.next = function (new_temp_venue) {
        // We move on to the next view controller 
        // to register information
        console.log("DEBUG: SIGNING UP " + JSON.stringify(new_temp_venue));
        this.router.navigate(["/newtempvenuedatetimepicker", new_temp_venue]);
    };
    RegistertemporaryvenuePage.prototype.toggleHasReadTermsAndConditions = function () {
        this.hasReadTermsAndConditions = !this.hasReadTermsAndConditions;
    };
    RegistertemporaryvenuePage.prototype.openTermsAndConditions = function () {
        var parmaeterOBJ = { returnURL: "/signupvenue" };
        this.router.navigate(['/venue-terms-cond', parmaeterOBJ]);
    };
    RegistertemporaryvenuePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-registertemporaryvenue',
            template: __webpack_require__(/*! ./registertemporaryvenue.page.html */ "./src/app/registertemporaryvenue/registertemporaryvenue.page.html"),
            styles: [__webpack_require__(/*! ./registertemporaryvenue.page.scss */ "./src/app/registertemporaryvenue/registertemporaryvenue.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _globals__WEBPACK_IMPORTED_MODULE_4__["Globals"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"]])
    ], RegistertemporaryvenuePage);
    return RegistertemporaryvenuePage;
}());



/***/ })

}]);
//# sourceMappingURL=registertemporaryvenue-registertemporaryvenue-module.js.map