(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["edit-temp-venue-info-edit-temp-venue-info-module"],{

/***/ "./src/app/edit-temp-venue-info/edit-temp-venue-info.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/edit-temp-venue-info/edit-temp-venue-info.module.ts ***!
  \*********************************************************************/
/*! exports provided: EditTempVenueInfoPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditTempVenueInfoPageModule", function() { return EditTempVenueInfoPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _edit_temp_venue_info_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./edit-temp-venue-info.page */ "./src/app/edit-temp-venue-info/edit-temp-venue-info.page.ts");







var routes = [
    {
        path: '',
        component: _edit_temp_venue_info_page__WEBPACK_IMPORTED_MODULE_6__["EditTempVenueInfoPage"]
    }
];
var EditTempVenueInfoPageModule = /** @class */ (function () {
    function EditTempVenueInfoPageModule() {
    }
    EditTempVenueInfoPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_edit_temp_venue_info_page__WEBPACK_IMPORTED_MODULE_6__["EditTempVenueInfoPage"]]
        })
    ], EditTempVenueInfoPageModule);
    return EditTempVenueInfoPageModule;
}());



/***/ }),

/***/ "./src/app/edit-temp-venue-info/edit-temp-venue-info.page.html":
/*!*********************************************************************!*\
  !*** ./src/app/edit-temp-venue-info/edit-temp-venue-info.page.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n\n  <ion-toolbar>\n\n    <ion-title></ion-title>\n    <ion-buttons slot=\"start\">\n        \n        <ion-button class=\"backButton\" \n                    (click)=\"goBack()\">\n          <ion-icon name=\"arrow-back\"></ion-icon>\n          Back\n        </ion-button>\n    </ion-buttons>\n\n    <ion-buttons slot=\"end\">\n        <ion-button class=\"editButton\" \n                    (click)=\"openEditPage()\">\n          Edit\n        </ion-button>\n    </ion-buttons>\n\n  </ion-toolbar>\n\n</ion-header>\n\n<ion-content>\n  <ion-item>\n    <ion-label class=\"generalInfoLabel\">\n      General Information\n    </ion-label>\n  </ion-item>\n\n  <ion-item lines=\"none\">\n    <ion-icon name=\"person\"></ion-icon>\n    <ion-label class=\"typeLabel\">Name</ion-label>\n  </ion-item>\n  <ion-item>\n      <ion-label>{{ getName() }}</ion-label>\n  </ion-item>\n\n  <ion-item lines=\"none\">\n      <ion-icon name=\"menu\"></ion-icon>\n      <ion-label class=\"typeLabel\">Description</ion-label>\n  </ion-item>\n  <ion-item>\n    <ion-label>{{ getDescription() }}</ion-label>\n  </ion-item>\n\n  <ion-item lines=\"none\">\n      <ion-icon name=\"home\"></ion-icon>\n      <ion-label class=\"typeLabel\">Address</ion-label>\n  </ion-item>\n  <ion-item>\n    <ion-label>{{ getAddress() }}</ion-label>\n  </ion-item>\n\n  <ion-item lines=\"none\">\n      <ion-icon name=\"call\"></ion-icon>\n      <ion-label class=\"typeLabel\">Phone</ion-label>\n  </ion-item>\n  <ion-item>\n    <ion-label>{{ getPhoneNumber() }}</ion-label>\n  </ion-item>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/edit-temp-venue-info/edit-temp-venue-info.page.scss":
/*!*********************************************************************!*\
  !*** ./src/app/edit-temp-venue-info/edit-temp-venue-info.page.scss ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header, ion-toolbar, ion-content {\n  --background: black;\n  color: white; }\n\n.backButton {\n  color: white; }\n\n.editButton {\n  color: white; }\n\n.typeLabel {\n  font-style: bold;\n  font-family: \"Arial Rounded MT Bold\";\n  padding-left: 20pt; }\n\n.generalInfoLabel {\n  width: 100%;\n  font-style: bold;\n  font-size: 20pt;\n  text-align: center;\n  font-family: \"Arial Rounded MT Bold\"; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZWRpdC10ZW1wLXZlbnVlLWluZm8vRTpcXFVzZXJzXFxTYWRlZ2hpVGFiYXNcXERlc2t0b3BcXExpbmVTa2lwL3NyY1xcYXBwXFxlZGl0LXRlbXAtdmVudWUtaW5mb1xcZWRpdC10ZW1wLXZlbnVlLWluZm8ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksWUFBWSxFQUFBOztBQUdoQjtFQUNJLFlBQVksRUFBQTs7QUFHaEI7RUFDSSxnQkFBZ0I7RUFDaEIsb0NBQW9DO0VBQ3BDLGtCQUFrQixFQUFBOztBQUd0QjtFQUNJLFdBQVc7RUFDWCxnQkFBZ0I7RUFDaEIsZUFBZTtFQUNmLGtCQUFrQjtFQUNsQixvQ0FBb0MsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2VkaXQtdGVtcC12ZW51ZS1pbmZvL2VkaXQtdGVtcC12ZW51ZS1pbmZvLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXIsIGlvbi10b29sYmFyLCBpb24tY29udGVudCB7XHJcbiAgICAtLWJhY2tncm91bmQ6IGJsYWNrO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gIH1cclxuICBcclxuLmJhY2tCdXR0b24ge1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG4uZWRpdEJ1dHRvbiB7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbn1cclxuXHJcbi50eXBlTGFiZWwge1xyXG4gICAgZm9udC1zdHlsZTogYm9sZDtcclxuICAgIGZvbnQtZmFtaWx5OiBcIkFyaWFsIFJvdW5kZWQgTVQgQm9sZFwiO1xyXG4gICAgcGFkZGluZy1sZWZ0OiAyMHB0O1xyXG59XHJcblxyXG4uZ2VuZXJhbEluZm9MYWJlbCB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGZvbnQtc3R5bGU6IGJvbGQ7XHJcbiAgICBmb250LXNpemU6IDIwcHQ7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250LWZhbWlseTogXCJBcmlhbCBSb3VuZGVkIE1UIEJvbGRcIjtcclxuICB9Il19 */"

/***/ }),

/***/ "./src/app/edit-temp-venue-info/edit-temp-venue-info.page.ts":
/*!*******************************************************************!*\
  !*** ./src/app/edit-temp-venue-info/edit-temp-venue-info.page.ts ***!
  \*******************************************************************/
/*! exports provided: EditTempVenueInfoPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditTempVenueInfoPage", function() { return EditTempVenueInfoPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals */ "./src/globals.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_5__);

// This page displays the temporary venue object's 
// generic information that does not pertain to tickets,
// like address, description, name, phone number, 
// May or may not allow them to update the start and end date as well





var EditTempVenueInfoPage = /** @class */ (function () {
    function EditTempVenueInfoPage(router, globals, events) {
        var _this = this;
        this.router = router;
        this.globals = globals;
        this.events = events;
        this.tempVenueRef = firebase__WEBPACK_IMPORTED_MODULE_5__["database"]().ref('tempVenueInfo/');
        this.tempVenueToDisplay = {
            name: "", description: "", address: "",
            phoneNumber: "", startDate: "", endDate: ""
        }; // initializing with a default object
        this.loadData();
        // if anything gets updated, we listen 
        // here to run it again
        this.events.subscribe('updatedBasicTempInfo', function (time) {
            _this.loadData();
        });
    }
    EditTempVenueInfoPage.prototype.loadData = function () {
        var currentTempID = firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser.uid;
        var self = this;
        this.tempVenueRef.orderByChild("uid").equalTo(currentTempID).limitToFirst(1).once("value", function (data) {
            // we extract the current temporary venue's information just once                  
            var data_keys = Object.keys(data.val());
            var extractedOBJ = data.val()[data_keys[0]];
            // update the global variable due to firebase 
            // updating the extracted data due to it being modified
            // and we are using it to display the data
            _globals__WEBPACK_IMPORTED_MODULE_3__["Globals"].CURRENT_TEMP_VENUE_OBJ = extractedOBJ;
            self.tempVenueToDisplay = {
                name: extractedOBJ.name,
                description: extractedOBJ.descripton,
                address: extractedOBJ.address,
                phoneNumber: extractedOBJ.phoneNumber,
                startDate: extractedOBJ.startDate,
                endDate: extractedOBJ.endDate
            };
        });
    };
    EditTempVenueInfoPage.prototype.ionViewWillEnter = function () {
    };
    EditTempVenueInfoPage.prototype.ngOnInit = function () {
    };
    EditTempVenueInfoPage.prototype.goBack = function () {
        this.router.navigate(["tabs/tab5"]);
    };
    EditTempVenueInfoPage.prototype.openEditPage = function () {
        this.router.navigate(["/modify-temp-venue-info"]);
    };
    EditTempVenueInfoPage.prototype.getName = function () {
        if (this.tempVenueToDisplay.name != "") {
            return this.tempVenueToDisplay.name;
        }
        else {
            return "Name Not Available";
        }
    };
    EditTempVenueInfoPage.prototype.getDescription = function () {
        if (this.tempVenueToDisplay.description != "") {
            return this.tempVenueToDisplay.description;
        }
        else {
            return "Description Not Available";
        }
    };
    EditTempVenueInfoPage.prototype.getAddress = function () {
        if (this.tempVenueToDisplay.address != "") {
            return this.tempVenueToDisplay.address;
        }
        else {
            return "Address Not Available";
        }
    };
    EditTempVenueInfoPage.prototype.getPhoneNumber = function () {
        if (this.tempVenueToDisplay.phoneNumber != "") {
            return this.tempVenueToDisplay.phoneNumber;
        }
        else {
            return "Phone Not Available";
        }
    };
    EditTempVenueInfoPage.prototype.getStartDate = function () {
        if (this.tempVenueToDisplay.startDate != "") {
            var extractedDateOBJ = new Date(this.tempVenueToDisplay.startDate);
            return extractedDateOBJ.toLocaleDateString('en-US');
        }
        else {
            return "Start Date Not Available";
        }
    };
    EditTempVenueInfoPage.prototype.getEndDate = function () {
        if (this.tempVenueToDisplay.endDate != "") {
            var extractedDateOBJ = new Date(this.tempVenueToDisplay.endDate);
            return extractedDateOBJ.toLocaleDateString('en-US');
        }
        else {
            return "End Date Not Available";
        }
    };
    EditTempVenueInfoPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-edit-temp-venue-info',
            template: __webpack_require__(/*! ./edit-temp-venue-info.page.html */ "./src/app/edit-temp-venue-info/edit-temp-venue-info.page.html"),
            styles: [__webpack_require__(/*! ./edit-temp-venue-info.page.scss */ "./src/app/edit-temp-venue-info/edit-temp-venue-info.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _globals__WEBPACK_IMPORTED_MODULE_3__["Globals"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Events"]])
    ], EditTempVenueInfoPage);
    return EditTempVenueInfoPage;
}());



/***/ })

}]);
//# sourceMappingURL=edit-temp-venue-info-edit-temp-venue-info-module.js.map