(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["take-temp-photo-take-temp-photo-module"],{

/***/ "./src/app/take-temp-photo/take-temp-photo.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/take-temp-photo/take-temp-photo.module.ts ***!
  \***********************************************************/
/*! exports provided: TakeTempPhotoPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TakeTempPhotoPageModule", function() { return TakeTempPhotoPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _take_temp_photo_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./take-temp-photo.page */ "./src/app/take-temp-photo/take-temp-photo.page.ts");







var routes = [
    {
        path: '',
        component: _take_temp_photo_page__WEBPACK_IMPORTED_MODULE_6__["TakeTempPhotoPage"]
    }
];
var TakeTempPhotoPageModule = /** @class */ (function () {
    function TakeTempPhotoPageModule() {
    }
    TakeTempPhotoPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_take_temp_photo_page__WEBPACK_IMPORTED_MODULE_6__["TakeTempPhotoPage"]]
        })
    ], TakeTempPhotoPageModule);
    return TakeTempPhotoPageModule;
}());



/***/ }),

/***/ "./src/app/take-temp-photo/take-temp-photo.page.html":
/*!***********************************************************!*\
  !*** ./src/app/take-temp-photo/take-temp-photo.page.html ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n\n  <ion-toolbar class=\"toolbar_header\">\n    <ion-title></ion-title>\n\n  </ion-toolbar>\n\n</ion-header>\n\n<ion-content>\n\n  <ion-item text-center lines=\"none\">\n    <ion-label class=\"titleLabel\" text-wrap>\n      Take Your Venue Photo\n    </ion-label>\n  </ion-item>\n\n  <ion-item class=\"image\" lines=\"none\">\n    <ion-img [src]=\"currentImageSource\" alt=\"Couldn't Image\"></ion-img>\n  </ion-item>\n\n\n\n\n    <ion-button class=\"submit-btn\" expand=\"block\" *ngIf=\"!hasTakenPhotographImage\" (click)=\"selectImage()\">\n      <ion-icon name=\"image\"></ion-icon>\n    Take Photo\n    </ion-button>\n\n\n    <ion-button class=\"submit-btn\" expand=\"block\" *ngIf=\"hasTakenPhotographImage\" (click)=\"selectImage()\">\n      <ion-icon name=\"image\"></ion-icon>\n     Update Photo\n    </ion-button>\n\n\n    <ion-button class=\"submit-btn\" expand=\"block\" *ngIf=\"hasTakenPhotographImage\" (click)=\"finish()\">\n\n      \n    Finish Register\n    </ion-button>\n\n\n</ion-content>\n<!-- *ngIf=\"hasTakenPhotographImage\" -->"

/***/ }),

/***/ "./src/app/take-temp-photo/take-temp-photo.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/take-temp-photo/take-temp-photo.page.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header, ion-toolbar, ion-content {\n  --background: black;\n  color: white; }\n\n.submit-btn {\n  --background: darkgrey;\n  color: white;\n  text-align: center;\n  border-radius: 10px;\n  text-align: center;\n  font-style: bold;\n  font-family: \"Arial Rounded MT Bold\";\n  margin: 0 auto;\n  font-size: 15pt; }\n\n.titleitem {\n  --background: black;\n  align-content: center; }\n\n.image {\n  margin-bottom: 10px; }\n\n.titleLabel {\n  text-align: center;\n  font-style: bold;\n  font-size: 18pt;\n  font-family: \"Arial Rounded MT Bold\"; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGFrZS10ZW1wLXBob3RvL0U6XFxVc2Vyc1xcU2FkZWdoaVRhYmFzXFxEZXNrdG9wXFxMaW5lU2tpcC9zcmNcXGFwcFxcdGFrZS10ZW1wLXBob3RvXFx0YWtlLXRlbXAtcGhvdG8ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBRWQ7RUFDRSxzQkFBYTtFQUNiLFlBQVk7RUFDWixrQkFBa0I7RUFDbEIsbUJBQW1CO0VBQ25CLGtCQUFrQjtFQUNsQixnQkFBZ0I7RUFDaEIsb0NBQW9DO0VBQ3BDLGNBQWM7RUFFZCxlQUFlLEVBQUE7O0FBRWpCO0VBQ0UsbUJBQWE7RUFDYixxQkFBcUIsRUFBQTs7QUFHdkI7RUFDRSxtQkFBbUIsRUFBQTs7QUFHckI7RUFDQSxrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLGVBQWU7RUFDZixvQ0FBb0MsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3Rha2UtdGVtcC1waG90by90YWtlLXRlbXAtcGhvdG8ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciwgaW9uLXRvb2xiYXIsIGlvbi1jb250ZW50IHtcclxuICAtLWJhY2tncm91bmQ6IGJsYWNrO1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxufVxyXG4uc3VibWl0LWJ0biB7XHJcbiAgLS1iYWNrZ3JvdW5kOiBkYXJrZ3JleTtcclxuICBjb2xvcjogd2hpdGU7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGZvbnQtc3R5bGU6IGJvbGQ7XHJcbiAgZm9udC1mYW1pbHk6IFwiQXJpYWwgUm91bmRlZCBNVCBCb2xkXCI7XHJcbiAgbWFyZ2luOiAwIGF1dG87XHJcblxyXG4gIGZvbnQtc2l6ZTogMTVwdDtcclxufVxyXG4udGl0bGVpdGVtIHtcclxuICAtLWJhY2tncm91bmQ6IGJsYWNrOyBcclxuICBhbGlnbi1jb250ZW50OiBjZW50ZXI7XHJcbn1cclxuXHJcbi5pbWFnZXtcclxuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG59XHJcblxyXG4udGl0bGVMYWJlbHtcclxudGV4dC1hbGlnbjogY2VudGVyO1xyXG5mb250LXN0eWxlOiBib2xkO1xyXG5mb250LXNpemU6IDE4cHQ7IFxyXG5mb250LWZhbWlseTogXCJBcmlhbCBSb3VuZGVkIE1UIEJvbGRcIjtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/take-temp-photo/take-temp-photo.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/take-temp-photo/take-temp-photo.page.ts ***!
  \*********************************************************/
/*! exports provided: TakeTempPhotoPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TakeTempPhotoPage", function() { return TakeTempPhotoPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/camera/ngx */ "./node_modules/@ionic-native/camera/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals */ "./src/globals.ts");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");








var TakeTempPhotoPage = /** @class */ (function () {
    function TakeTempPhotoPage(router, camera, file, activatedRoute, events) {
        this.router = router;
        this.camera = camera;
        this.file = file;
        this.activatedRoute = activatedRoute;
        this.events = events;
        this.tempVenueRef = firebase__WEBPACK_IMPORTED_MODULE_6__["database"]().ref('tempVenueInfo/');
        this.storageRef = firebase__WEBPACK_IMPORTED_MODULE_6__["storage"]().ref();
        this.currentImageSource = "../../assets/defaultImage.png";
        this.hasTakenPhotographImage = false;
        this.activatedRoute.params.subscribe(function (params) {
            TakeTempPhotoPage_1.idOfCreatedObject = params['id'];
            console.log("DEBUG: this.idOfCreatedObject is: " +
                TakeTempPhotoPage_1.idOfCreatedObject);
            // remove the start quote and end quote
            // TakeTempPhotoPage.idOfCreatedObject = TakeTempPhotoPage.idOfCreatedObject.substring(1, 
            //   TakeTempPhotoPage.idOfCreatedObject.length-1);
        });
    }
    TakeTempPhotoPage_1 = TakeTempPhotoPage;
    TakeTempPhotoPage.prototype.ngOnInit = function () {
    };
    TakeTempPhotoPage.prototype.ionViewWillEnter = function () {
        this.hasTakenPhotographImage = false;
        this.currentImageSource = "../../assets/defaultImage.png";
    };
    TakeTempPhotoPage.prototype.selectImage = function () {
        console.log("In PickImage() function");
        this.pickImage();
    };
    TakeTempPhotoPage.prototype.goBack = function () {
        this.router.navigate(['tabs.tab4']);
    };
    TakeTempPhotoPage.prototype.finish = function () {
        console.log("In finish() function.");
        //////////////////////////////////////////////////////////////////////////////////////
        this.tempVenueRef.orderByChild("uid").equalTo(TakeTempPhotoPage_1.idOfCreatedObject).limitToFirst(1).once("value", function (data) {
            // we extract the current temporary venue's information just once                  
            var data_keys = Object.keys(data.val());
            var extractedOBJ = data.val()[data_keys[0]];
            console.log("DEBUG: the extracted object is: " + JSON.stringify(extractedOBJ));
            _globals__WEBPACK_IMPORTED_MODULE_5__["Globals"].CURRENT_TEMP_VENUE_OBJ = extractedOBJ;
            extractedOBJ.imgUrl = TakeTempPhotoPage_1.menuUrl;
            var extractedID = data_keys[0];
            console.log("DEBUG: the extractedID is: " + extractedID);
            var newInfo = firebase__WEBPACK_IMPORTED_MODULE_6__["database"]().ref('tempVenueInfo/' + extractedID).update(extractedOBJ);
        });
        // this.events.publish('updatedBasicTempInfo', Date.now());
        ///////////////////////////////////////////////////////////////////////////
        this.router.navigate([_globals__WEBPACK_IMPORTED_MODULE_5__["TEMP_VENUES_DEFAULT_TAB"]]);
    };
    TakeTempPhotoPage.prototype.pickImage = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var options, cameraInfo, blobInfo, uploadInfo, e_1;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        options = {
                            quality: 40,
                            targetWidth: 1024,
                            targetHeight: 1024,
                            destinationType: this.camera.DestinationType.FILE_URI,
                            encodingType: this.camera.EncodingType.JPEG,
                            mediaType: this.camera.MediaType.PICTURE
                        };
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 5, , 6]);
                        // we have already picked an image... we first delete it
                        // and then add a new photographed image to it
                        if (this.hasTakenPhotographImage) {
                            // delete it first
                            this.deleteImageFromFirebase(TakeTempPhotoPage_1.idOfCreatedObject);
                        }
                        return [4 /*yield*/, this.camera.getPicture(options)];
                    case 2:
                        cameraInfo = _a.sent();
                        return [4 /*yield*/, this.makeFileIntoBlob(cameraInfo)];
                    case 3:
                        blobInfo = _a.sent();
                        return [4 /*yield*/, this.uploadStoreImageToFirebase(blobInfo)];
                    case 4:
                        uploadInfo = _a.sent();
                        console.log(uploadInfo);
                        // this.url = uploadInfo.ref.getDownloadURL();
                        this.hasTakenPhotographImage = true;
                        this.events.publish("updatedPhoto");
                        return [3 /*break*/, 6];
                    case 5:
                        e_1 = _a.sent();
                        console.log(e_1.message);
                        if (e_1.message != "undefined") {
                            alert("File Upload Error " + e_1.messasge);
                        }
                        return [3 /*break*/, 6];
                    case 6: return [2 /*return*/];
                }
            });
        });
    };
    TakeTempPhotoPage.prototype.makeFileIntoBlob = function (_imagePath) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var fileName = TakeTempPhotoPage_1.idOfCreatedObject + ".JPG";
            _this.file
                .resolveLocalFilesystemUrl(_imagePath)
                .then(function (fileEntry) {
                var name = fileEntry.name, nativeURL = fileEntry.nativeURL;
                // get the path..
                var path = nativeURL.substring(0, nativeURL.lastIndexOf("/"));
                console.log("path", path);
                console.log("fileName", name);
                fileName = name;
                // we are provided the name, so now read the file into
                // a buffer
                return _this.file.readAsArrayBuffer(path, name);
            })
                .then(function (buffer) {
                // get the buffer and make a blob to be saved
                var imgBlob = new Blob([buffer], {
                    type: "image/jpeg"
                });
                console.log(imgBlob.type, imgBlob.size);
                resolve({
                    fileName: fileName,
                    imgBlob: imgBlob
                });
            })
                .catch(function (e) { return reject(e); });
        });
    };
    TakeTempPhotoPage.prototype.uploadStoreImageToFirebase = function (_imageBlobInfo) {
        var _this = this;
        console.log("uploadToFirebase");
        return new Promise(function (resolve, reject) {
            var imageid = (Math.floor(Math.random() * 2000)).toString();
            var filename = _imageBlobInfo.fileName;
            var fileRef = firebase__WEBPACK_IMPORTED_MODULE_6__["storage"]().ref().child("menuImages").child(TakeTempPhotoPage_1.idOfCreatedObject + ".JPG");
            //firebase.storage().ref(EditstoreinfoPage.RESTAURANT_FILE_NAME);
            var uploadTask = fileRef.put(_imageBlobInfo.imgBlob);
            var mydownloadurl = "";
            var self = _this;
            uploadTask.on("state_changed", function (_snapshot) {
                console.log("snapshot progess " +
                    (_snapshot.bytesTransferred / _snapshot.totalBytes) * 100);
            }, function (_error) {
                console.log(_error);
                reject(_error);
            }, function () {
                // completion...  get the image URL for saving to database
                uploadTask.snapshot.ref.getDownloadURL().then(function (downloadURL) {
                    console.log('File available at', downloadURL);
                    self.currentImageSource = downloadURL;
                    TakeTempPhotoPage_1.menuUrl = self.currentImageSource;
                    resolve(mydownloadurl);
                });
                // resolve( uploadTask.snapshot);
                // resolve( mydownloadurl);
            });
        });
    };
    TakeTempPhotoPage.prototype.deleteImageFromFirebase = function (id) {
        // Create a reference to the file to delete
        var self = this;
        var fileRef = firebase__WEBPACK_IMPORTED_MODULE_6__["storage"]().ref().child("menuImages").child(id + ".JPG");
        // Delete the file
        fileRef.delete().then(function () {
            // File deleted successfully
        }).catch(function (error) {
            // Uh-oh, an error occurred!
            alert("Delete Error Occurred: " + error.message);
        });
    };
    var TakeTempPhotoPage_1;
    TakeTempPhotoPage.idOfCreatedObject = "";
    TakeTempPhotoPage = TakeTempPhotoPage_1 = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-take-temp-photo',
            template: __webpack_require__(/*! ./take-temp-photo.page.html */ "./src/app/take-temp-photo/take-temp-photo.page.html"),
            styles: [__webpack_require__(/*! ./take-temp-photo.page.scss */ "./src/app/take-temp-photo/take-temp-photo.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_3__["Camera"],
            _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_4__["File"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["Events"]])
    ], TakeTempPhotoPage);
    return TakeTempPhotoPage;
}());



/***/ })

}]);
//# sourceMappingURL=take-temp-photo-take-temp-photo-module.js.map