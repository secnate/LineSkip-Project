(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["terms-and-conditions-page-terms-and-conditions-page-module"],{

/***/ "./src/app/terms-and-conditions-page/terms-and-conditions-page.module.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/terms-and-conditions-page/terms-and-conditions-page.module.ts ***!
  \*******************************************************************************/
/*! exports provided: TermsAndConditionsPagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TermsAndConditionsPagePageModule", function() { return TermsAndConditionsPagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _terms_and_conditions_page_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./terms-and-conditions-page.page */ "./src/app/terms-and-conditions-page/terms-and-conditions-page.page.ts");







var routes = [
    {
        path: '',
        component: _terms_and_conditions_page_page__WEBPACK_IMPORTED_MODULE_6__["TermsAndConditionsPagePage"]
    }
];
var TermsAndConditionsPagePageModule = /** @class */ (function () {
    function TermsAndConditionsPagePageModule() {
    }
    TermsAndConditionsPagePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_terms_and_conditions_page_page__WEBPACK_IMPORTED_MODULE_6__["TermsAndConditionsPagePage"]]
        })
    ], TermsAndConditionsPagePageModule);
    return TermsAndConditionsPagePageModule;
}());



/***/ }),

/***/ "./src/app/terms-and-conditions-page/terms-and-conditions-page.page.html":
/*!*******************************************************************************!*\
  !*** ./src/app/terms-and-conditions-page/terms-and-conditions-page.page.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar class=\"toolbar_header\">\n      <ion-title></ion-title>\n      <ion-buttons slot=\"start\">\n          <ion-button (click)=\"goBack()\"\n            style=\"color: white;\">\n            <ion-icon slot=\"icon-only\" name=\"arrow-back\">\n            </ion-icon>\n            Back\n          </ion-button>\n      </ion-buttons>\n    </ion-toolbar>\n  </ion-header>\n\n<ion-content>\n  <br>\n  <ion-item>\n    <ion-label class=\"title\">Terms And Conditions</ion-label>\n  </ion-item>\n  <ion-item>\n      <p> This is the future location of \n          LineUp app's <b>Terms and Conditions</b> document.</p>\n  </ion-item>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/terms-and-conditions-page/terms-and-conditions-page.page.scss":
/*!*******************************************************************************!*\
  !*** ./src/app/terms-and-conditions-page/terms-and-conditions-page.page.scss ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar_header {\n  --background: black;\n  color: white; }\n\nion-content {\n  --background: white;\n  width: 100%;\n  margin-left: 0px;\n  margin-right: 0px;\n  margin-top: 0px;\n  margin-bottom: 0px; }\n\n.title {\n  margin-top: 20px;\n  margin-left: 0;\n  margin-right: 0;\n  margin: 0 auto;\n  font-style: bold;\n  font-family: \"Arial Rounded MT Bold\";\n  width: 100%;\n  color: black;\n  text-align: center;\n  font-size: 20pt; }\n\nion-item {\n  --background: transparent; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGVybXMtYW5kLWNvbmRpdGlvbnMtcGFnZS9FOlxcVXNlcnNcXFNhZGVnaGlUYWJhc1xcRGVza3RvcFxcTGluZVNraXAvc3JjXFxhcHBcXHRlcm1zLWFuZC1jb25kaXRpb25zLXBhZ2VcXHRlcm1zLWFuZC1jb25kaXRpb25zLXBhZ2UucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksbUJBQWE7RUFDYixXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLGlCQUFpQjtFQUNqQixlQUFlO0VBQ2Ysa0JBQWtCLEVBQUE7O0FBR3RCO0VBQ0ksZ0JBQWdCO0VBQ2hCLGNBQWM7RUFDZCxlQUFlO0VBQ2YsY0FBYztFQUNkLGdCQUFnQjtFQUNoQixvQ0FBb0M7RUFDcEMsV0FBVztFQUNYLFlBQVk7RUFDWixrQkFBa0I7RUFDbEIsZUFBZSxFQUFBOztBQUduQjtFQUNJLHlCQUFhLEVBQUEiLCJmaWxlIjoic3JjL2FwcC90ZXJtcy1hbmQtY29uZGl0aW9ucy1wYWdlL3Rlcm1zLWFuZC1jb25kaXRpb25zLXBhZ2UucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRvb2xiYXJfaGVhZGVyIHtcbiAgICAtLWJhY2tncm91bmQ6IGJsYWNrO1xuICAgIGNvbG9yOiB3aGl0ZTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAgIC0tYmFja2dyb3VuZDogd2hpdGU7IFxuICAgIHdpZHRoOiAxMDAlO1xuICAgIG1hcmdpbi1sZWZ0OiAwcHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAwcHg7XG4gICAgbWFyZ2luLXRvcDogMHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDBweDtcbn1cblxuLnRpdGxlIHtcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xuICAgIG1hcmdpbi1sZWZ0OiAwO1xuICAgIG1hcmdpbi1yaWdodDogMDtcbiAgICBtYXJnaW46IDAgYXV0bztcbiAgICBmb250LXN0eWxlOiBib2xkO1xuICAgIGZvbnQtZmFtaWx5OiBcIkFyaWFsIFJvdW5kZWQgTVQgQm9sZFwiO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGNvbG9yOiBibGFjaztcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1zaXplOiAyMHB0O1xufVxuXG5pb24taXRlbSB7XG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/terms-and-conditions-page/terms-and-conditions-page.page.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/terms-and-conditions-page/terms-and-conditions-page.page.ts ***!
  \*****************************************************************************/
/*! exports provided: TermsAndConditionsPagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TermsAndConditionsPagePage", function() { return TermsAndConditionsPagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var TermsAndConditionsPagePage = /** @class */ (function () {
    function TermsAndConditionsPagePage(router, route) {
        this.router = router;
        this.route = route;
    }
    TermsAndConditionsPagePage.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.subscribe(function (param) {
            // We get the URL for which we can return to 
            // the invoking view controller
            _this.nameOfInvokingViewController = param.returnURL;
            console.log("DEBUG: received parameter: " +
                JSON.stringify(_this.nameOfInvokingViewController));
        });
    };
    TermsAndConditionsPagePage.prototype.goBack = function () {
        if (this.nameOfInvokingViewController != "") {
            this.router.navigate([this.nameOfInvokingViewController]);
        }
        else {
            alert("We don't have a valid view controller to go back to.");
        }
    };
    TermsAndConditionsPagePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-terms-and-conditions-page',
            template: __webpack_require__(/*! ./terms-and-conditions-page.page.html */ "./src/app/terms-and-conditions-page/terms-and-conditions-page.page.html"),
            styles: [__webpack_require__(/*! ./terms-and-conditions-page.page.scss */ "./src/app/terms-and-conditions-page/terms-and-conditions-page.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])
    ], TermsAndConditionsPagePage);
    return TermsAndConditionsPagePage;
}());



/***/ })

}]);
//# sourceMappingURL=terms-and-conditions-page-terms-and-conditions-page-module.js.map