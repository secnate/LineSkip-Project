(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["venue-terms-cond-venue-terms-cond-module"],{

/***/ "./src/app/venue-terms-cond/venue-terms-cond.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/venue-terms-cond/venue-terms-cond.module.ts ***!
  \*************************************************************/
/*! exports provided: VenueTermsCondPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VenueTermsCondPageModule", function() { return VenueTermsCondPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _venue_terms_cond_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./venue-terms-cond.page */ "./src/app/venue-terms-cond/venue-terms-cond.page.ts");







var routes = [
    {
        path: '',
        component: _venue_terms_cond_page__WEBPACK_IMPORTED_MODULE_6__["VenueTermsCondPage"]
    }
];
var VenueTermsCondPageModule = /** @class */ (function () {
    function VenueTermsCondPageModule() {
    }
    VenueTermsCondPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_venue_terms_cond_page__WEBPACK_IMPORTED_MODULE_6__["VenueTermsCondPage"]]
        })
    ], VenueTermsCondPageModule);
    return VenueTermsCondPageModule;
}());



/***/ }),

/***/ "./src/app/venue-terms-cond/venue-terms-cond.page.html":
/*!*************************************************************!*\
  !*** ./src/app/venue-terms-cond/venue-terms-cond.page.html ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar class=\"toolbar_header\">\n    <ion-title></ion-title>\n    <ion-buttons slot=\"start\">\n        <ion-button (click)=\"goBack()\"\n          style=\"color: white;\">\n          <ion-icon slot=\"icon-only\" name=\"arrow-back\">\n          </ion-icon>\n          Back\n        </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n<br>\n<ion-item>\n  <ion-label class=\"title\">Terms And Conditions</ion-label>\n</ion-item>\n<ion-item>\n    <p> This is the future location of \n        LineUp app's <b>Terms and Conditions</b> document.</p>\n</ion-item>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/venue-terms-cond/venue-terms-cond.page.scss":
/*!*************************************************************!*\
  !*** ./src/app/venue-terms-cond/venue-terms-cond.page.scss ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar_header {\n  --background: black;\n  color: white; }\n\nion-content {\n  --background: white;\n  width: 100%;\n  margin-left: 0px;\n  margin-right: 0px;\n  margin-top: 0px;\n  margin-bottom: 0px; }\n\n.title {\n  margin-top: 20px;\n  margin-left: 0;\n  margin-right: 0;\n  margin: 0 auto;\n  font-style: bold;\n  font-family: \"Arial Rounded MT Bold\";\n  width: 100%;\n  color: black;\n  text-align: center;\n  font-size: 20pt; }\n\nion-item {\n  --background: transparent; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdmVudWUtdGVybXMtY29uZC9FOlxcVXNlcnNcXFNhZGVnaGlUYWJhc1xcRGVza3RvcFxcTGluZVNraXAvc3JjXFxhcHBcXHZlbnVlLXRlcm1zLWNvbmRcXHZlbnVlLXRlcm1zLWNvbmQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksbUJBQWE7RUFDYixXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLGlCQUFpQjtFQUNqQixlQUFlO0VBQ2Ysa0JBQWtCLEVBQUE7O0FBR3RCO0VBQ0ksZ0JBQWdCO0VBQ2hCLGNBQWM7RUFDZCxlQUFlO0VBQ2YsY0FBYztFQUNkLGdCQUFnQjtFQUNoQixvQ0FBb0M7RUFDcEMsV0FBVztFQUNYLFlBQVk7RUFDWixrQkFBa0I7RUFDbEIsZUFBZSxFQUFBOztBQUduQjtFQUNJLHlCQUFhLEVBQUEiLCJmaWxlIjoic3JjL2FwcC92ZW51ZS10ZXJtcy1jb25kL3ZlbnVlLXRlcm1zLWNvbmQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRvb2xiYXJfaGVhZGVyIHtcclxuICAgIC0tYmFja2dyb3VuZDogYmxhY2s7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbn1cclxuXHJcbmlvbi1jb250ZW50IHtcclxuICAgIC0tYmFja2dyb3VuZDogd2hpdGU7IFxyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBtYXJnaW4tbGVmdDogMHB4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAwcHg7XHJcbiAgICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbn1cclxuXHJcbi50aXRsZSB7XHJcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDA7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDA7XHJcbiAgICBtYXJnaW46IDAgYXV0bztcclxuICAgIGZvbnQtc3R5bGU6IGJvbGQ7XHJcbiAgICBmb250LWZhbWlseTogXCJBcmlhbCBSb3VuZGVkIE1UIEJvbGRcIjtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgZm9udC1zaXplOiAyMHB0O1xyXG59XHJcblxyXG5pb24taXRlbSB7XHJcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/venue-terms-cond/venue-terms-cond.page.ts":
/*!***********************************************************!*\
  !*** ./src/app/venue-terms-cond/venue-terms-cond.page.ts ***!
  \***********************************************************/
/*! exports provided: VenueTermsCondPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VenueTermsCondPage", function() { return VenueTermsCondPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var VenueTermsCondPage = /** @class */ (function () {
    function VenueTermsCondPage(router, route) {
        this.router = router;
        this.route = route;
    }
    VenueTermsCondPage.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.subscribe(function (param) {
            // We get the URL for which we can return to 
            // the invoking view controller
            _this.nameOfInvokingViewController = param.returnURL;
            console.log("DEBUG: received parameter: " +
                JSON.stringify(_this.nameOfInvokingViewController));
        });
    };
    VenueTermsCondPage.prototype.goBack = function () {
        if (this.nameOfInvokingViewController != "") {
            this.router.navigate([this.nameOfInvokingViewController]);
        }
        else {
            alert("We don't have a valid view controller to go back to.");
        }
    };
    VenueTermsCondPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-venue-terms-cond',
            template: __webpack_require__(/*! ./venue-terms-cond.page.html */ "./src/app/venue-terms-cond/venue-terms-cond.page.html"),
            styles: [__webpack_require__(/*! ./venue-terms-cond.page.scss */ "./src/app/venue-terms-cond/venue-terms-cond.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])
    ], VenueTermsCondPage);
    return VenueTermsCondPage;
}());



/***/ })

}]);
//# sourceMappingURL=venue-terms-cond-venue-terms-cond-module.js.map