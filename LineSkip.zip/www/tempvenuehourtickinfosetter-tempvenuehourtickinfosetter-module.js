(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tempvenuehourtickinfosetter-tempvenuehourtickinfosetter-module"],{

/***/ "./src/app/tempvenuehourtickinfosetter/tempvenuehourtickinfosetter.module.ts":
/*!***********************************************************************************!*\
  !*** ./src/app/tempvenuehourtickinfosetter/tempvenuehourtickinfosetter.module.ts ***!
  \***********************************************************************************/
/*! exports provided: TempvenuehourtickinfosetterPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TempvenuehourtickinfosetterPageModule", function() { return TempvenuehourtickinfosetterPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _tempvenuehourtickinfosetter_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tempvenuehourtickinfosetter.page */ "./src/app/tempvenuehourtickinfosetter/tempvenuehourtickinfosetter.page.ts");







var routes = [
    {
        path: '',
        component: _tempvenuehourtickinfosetter_page__WEBPACK_IMPORTED_MODULE_6__["TempvenuehourtickinfosetterPage"]
    }
];
var TempvenuehourtickinfosetterPageModule = /** @class */ (function () {
    function TempvenuehourtickinfosetterPageModule() {
    }
    TempvenuehourtickinfosetterPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_tempvenuehourtickinfosetter_page__WEBPACK_IMPORTED_MODULE_6__["TempvenuehourtickinfosetterPage"]]
        })
    ], TempvenuehourtickinfosetterPageModule);
    return TempvenuehourtickinfosetterPageModule;
}());



/***/ }),

/***/ "./src/app/tempvenuehourtickinfosetter/tempvenuehourtickinfosetter.page.html":
/*!***********************************************************************************!*\
  !*** ./src/app/tempvenuehourtickinfosetter/tempvenuehourtickinfosetter.page.html ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar class=\"toolbar_header\">\n      <ion-title></ion-title>\n      <ion-buttons slot=\"start\">\n          <ion-button (click)=\"cancel()\"\n            style=\"color: white;\">\n            Cancel\n          </ion-button>\n      </ion-buttons>\n    </ion-toolbar>\n  </ion-header>\n\n<ion-content>\n\n  <ion-item lines=\"none\">\n    <ion-label class=\"title\">\n      Enter Hourly Information\n    </ion-label>\n  </ion-item>\n\n  <ion-item>\n    <ion-label>\n      Note: Enter Only Positive Integers \n    </ion-label>\n  </ion-item>\n\n  <!-- We assume that the user enters valid input \n       due to their phone keyboards limiting them only\n       to numerical inputs.\n  -->\n  <ion-item *ngFor = \"let hourSlot of ticketInfo\" text-wrap>\n      <ion-grid>\n        <ion-row>\n          <ion-label class=\"timeslotlabel\">\n            <b>{{ getHourSlotString(hourSlot.startHour )}}</b>\n           </ion-label>\n        </ion-row>\n     \n        <ion-row>\n          <ion-label class=\"inputlabel\"><b>Number of Tickets:</b></ion-label>\n          <ion-input type=\"number\" inputmode=\"numeric\" \n                     min=\"0\" pattern=\"^[1-9]\\d*$\"\n                     [(ngModel)]=\"hourSlot.numTickets\">\n          </ion-input>\n        </ion-row>\n\n        <ion-row>\n          <ion-label class=\"inputlabel\"><b>Price Per Ticket:</b></ion-label>\n          <ion-input type=\"number\" inputmode=\"numeric\"\n                     min=\"0\" pattern=\"^[1-9]\\d*$\"\n                     [(ngModel)]=\"hourSlot.ticketPrice\">\n          </ion-input>\n        </ion-row>\n    </ion-grid>\n  </ion-item>\n\n\n  <!-- If any empty, we can not go next -->\n    <ion-button (click)=\"moveNext()\" *ngIf=\"!anyEmpty()\" id=\"button\">\n     Next\n    </ion-button>\n\n  <!-- Instead, we display a warning -->\n  <ion-grid>\n    <ion-row>\n      <ion-label *ngIf=\"anyEmpty()\" text-wrap class=\"warninglabel\">\n        <u>Invalid State:</u>\n      </ion-label>\n    </ion-row>\n    <ion-row>\n      <ion-label *ngIf=\"anyEmpty()\" text-wrap class=\"warninglabel\">\n       At least one input box is empty.\n       </ion-label>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/tempvenuehourtickinfosetter/tempvenuehourtickinfosetter.page.scss":
/*!***********************************************************************************!*\
  !*** ./src/app/tempvenuehourtickinfosetter/tempvenuehourtickinfosetter.page.scss ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar_header {\n  --background: black;\n  color: white; }\n\nion-content {\n  --background: white;\n  color: white; }\n\n.title {\n  font-size: 15pt;\n  font-style: bold;\n  font-family: \"Arial Rounded MT Bold\";\n  text-align: center; }\n\nion-input {\n  border-bottom: 1px black solid;\n  margin-left: 5px; }\n\nion-row {\n  height: 100%;\n  vertical-align: middle;\n  align-items: center; }\n\n.inputlabel {\n  display: flex;\n  vertical-align: middle;\n  background: transparent; }\n\n.timeslotlabel {\n  font-size: 13pt;\n  font-style: bold;\n  font-family: \"Arial Rounded MT Bold\"; }\n\n#button {\n  margin-top: 15px;\n  margin-left: 10%;\n  margin-right: 0px;\n  width: 100px;\n  --background: darkgrey;\n  color: white;\n  font-size: 16pt;\n  font-style: bold;\n  font-family: \"Arial Rounded MT Bold\";\n  height: 50px;\n  text-align: right;\n  border-radius: 10px;\n  vertical-align: bottom; }\n\n.warninglabel {\n  margin-top: 10px;\n  --background: white;\n  color: black;\n  font-size: 13pt;\n  font-style: bold;\n  font-family: \"Arial Rounded MT Bold\";\n  margin-left: 10%;\n  margin-right: -10%;\n  text-align: center; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGVtcHZlbnVlaG91cnRpY2tpbmZvc2V0dGVyL0U6XFxVc2Vyc1xcU2FkZWdoaVRhYmFzXFxEZXNrdG9wXFxMaW5lU2tpcC9zcmNcXGFwcFxcdGVtcHZlbnVlaG91cnRpY2tpbmZvc2V0dGVyXFx0ZW1wdmVudWVob3VydGlja2luZm9zZXR0ZXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixvQ0FBb0M7RUFDcEMsa0JBQWtCLEVBQUE7O0FBR3RCO0VBQ0ksOEJBQThCO0VBQzlCLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLFlBQVk7RUFDWixzQkFBc0I7RUFDdEIsbUJBQW1CLEVBQUE7O0FBR3ZCO0VBQ0ksYUFBYTtFQUNiLHNCQUFzQjtFQUN0Qix1QkFBdUIsRUFBQTs7QUFHM0I7RUFDSSxlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLG9DQUFvQyxFQUFBOztBQUd4QztFQUNJLGdCQUFnQjtFQUNoQixnQkFBZ0I7RUFDaEIsaUJBQWlCO0VBQ2pCLFlBQVk7RUFDWixzQkFBYTtFQUNiLFlBQVk7RUFDWixlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLG9DQUFvQztFQUNwQyxZQUFZO0VBQ1osaUJBQWlCO0VBQ2pCLG1CQUFtQjtFQUNuQixzQkFBc0IsRUFBQTs7QUFHMUI7RUFDSSxnQkFBZ0I7RUFDaEIsbUJBQWE7RUFDYixZQUFZO0VBQ1osZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixvQ0FBb0M7RUFDcEMsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixrQkFBa0IsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3RlbXB2ZW51ZWhvdXJ0aWNraW5mb3NldHRlci90ZW1wdmVudWVob3VydGlja2luZm9zZXR0ZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRvb2xiYXJfaGVhZGVyIHtcbiAgICAtLWJhY2tncm91bmQ6IGJsYWNrO1xuICAgIGNvbG9yOiB3aGl0ZTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAgIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gICAgY29sb3I6IHdoaXRlO1xufVxuXG4udGl0bGUge1xuICAgIGZvbnQtc2l6ZTogMTVwdDtcbiAgICBmb250LXN0eWxlOiBib2xkO1xuICAgIGZvbnQtZmFtaWx5OiBcIkFyaWFsIFJvdW5kZWQgTVQgQm9sZFwiO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuaW9uLWlucHV0IHtcbiAgICBib3JkZXItYm90dG9tOiAxcHggYmxhY2sgc29saWQ7XG4gICAgbWFyZ2luLWxlZnQ6IDVweDtcbn1cblxuaW9uLXJvdyB7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLmlucHV0bGFiZWwge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cblxuLnRpbWVzbG90bGFiZWwge1xuICAgIGZvbnQtc2l6ZTogMTNwdDtcbiAgICBmb250LXN0eWxlOiBib2xkO1xuICAgIGZvbnQtZmFtaWx5OiBcIkFyaWFsIFJvdW5kZWQgTVQgQm9sZFwiO1xufVxuXG4jYnV0dG9uIHtcbiAgICBtYXJnaW4tdG9wOiAxNXB4O1xuICAgIG1hcmdpbi1sZWZ0OiAxMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwcHg7XG4gICAgd2lkdGg6IDEwMHB4O1xuICAgIC0tYmFja2dyb3VuZDogZGFya2dyZXk7XG4gICAgY29sb3I6IHdoaXRlOyBcbiAgICBmb250LXNpemU6IDE2cHQ7XG4gICAgZm9udC1zdHlsZTogYm9sZDtcbiAgICBmb250LWZhbWlseTogXCJBcmlhbCBSb3VuZGVkIE1UIEJvbGRcIjtcbiAgICBoZWlnaHQ6IDUwcHg7XG4gICAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICB2ZXJ0aWNhbC1hbGlnbjogYm90dG9tO1xufVxuXG4ud2FybmluZ2xhYmVsIHtcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gICAgY29sb3I6IGJsYWNrO1xuICAgIGZvbnQtc2l6ZTogMTNwdDtcbiAgICBmb250LXN0eWxlOiBib2xkO1xuICAgIGZvbnQtZmFtaWx5OiBcIkFyaWFsIFJvdW5kZWQgTVQgQm9sZFwiO1xuICAgIG1hcmdpbi1sZWZ0OiAxMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAtMTAlO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbiJdfQ== */"

/***/ }),

/***/ "./src/app/tempvenuehourtickinfosetter/tempvenuehourtickinfosetter.page.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/tempvenuehourtickinfosetter/tempvenuehourtickinfosetter.page.ts ***!
  \*********************************************************************************/
/*! exports provided: TempvenuehourtickinfosetterPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TempvenuehourtickinfosetterPage", function() { return TempvenuehourtickinfosetterPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals */ "./src/globals.ts");




var TempvenuehourtickinfosetterPage = /** @class */ (function () {
    function TempvenuehourtickinfosetterPage(router, globals, route) {
        this.router = router;
        this.globals = globals;
        this.route = route;
        this.received_temp_venue_info = null;
        // information about the start and end time
        this.startHour = null;
        this.endHour = null;
        this.totalNumHours = null;
        // array of information about tickets
        this.ticketInfo = null;
    }
    TempvenuehourtickinfosetterPage.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.subscribe(function (param) {
            _this.received_temp_venue_info = param;
            console.log(JSON.stringify(_this.received_temp_venue_info));
            // Now we have received the user information
            // we now extract the start hour and end hour
            // and start preparing the ticket information
            var dateWithStartTime = _this.received_temp_venue_info.startTime;
            var dateWithEndTime = _this.received_temp_venue_info.endTime;
            // we extract the hours from the two date objects
            _this.startHour = (new Date(dateWithStartTime)).getHours(); // this is PM
            _this.endHour = (new Date(dateWithEndTime)).getHours(); // this is AM
            var numberOfPMHours = 12 - _this.startHour;
            var numberOfAMHours = _this.endHour;
            if (_this.endHour == 12) {
                numberOfAMHours = 0;
            }
            _this.totalNumHours = numberOfPMHours + numberOfAMHours;
            // Now we create an array of objects that will contain
            // three items:
            // (1) Start Hour - the hour that starts the one-hour period
            // (2) Number Tickets
            // (3) End Time
            // This is just a basic empty value array right now
            _this.ticketInfo = new Array(_this.totalNumHours);
            for (var i = 0; i < _this.totalNumHours; i++) {
                _this.ticketInfo[i] = {
                    // if start hour goes over 12, then this is AM zone
                    startHour: _this.startHour + i,
                    numTickets: 0,
                    ticketPrice: 0,
                    numSold: 0
                };
            }
        });
    };
    TempvenuehourtickinfosetterPage.prototype.ionViewWillAppear = function () {
        console.log("DEBUG in it");
        this.ngOnInit();
    };
    TempvenuehourtickinfosetterPage.prototype.cancel = function () {
        this.router.navigate(['/signupvenue']);
    };
    TempvenuehourtickinfosetterPage.prototype.getHourSlotString = function (startHour) {
        // startHour is a number from 8 to numbers greater than 12
        // 8 to 12 (non-inclusive) are pm times
        // 12 and onwards are AM times
        var toReturn = "";
        if (startHour < 12) {
            // starting hour is PM
            toReturn += startHour.toString() + " PM to ";
        }
        else {
            // starting hour is AM
            if (startHour == 12) {
                toReturn += startHour.toString() + " AM to ";
            }
            else {
                toReturn += (startHour - 12).toString() + " AM to ";
            }
        }
        var endHour = startHour + 1;
        if (endHour < 12) {
            // ending hour is PM
            toReturn += endHour.toString() + " PM: ";
        }
        else {
            // ending hour is AM
            if (endHour == 12) {
                toReturn += endHour.toString() + " AM: ";
            }
            else {
                toReturn += (endHour - 12).toString() + " AM: ";
            }
        }
        return toReturn;
    };
    TempvenuehourtickinfosetterPage.prototype.anyEmpty = function () {
        // indicates if any of the inputs are empty
        var toReturn = false;
        this.ticketInfo.forEach(function (element) {
            if (element.ticketPrice == null || element.numTickets == null) {
                toReturn = true;
            }
        });
        return toReturn;
    };
    TempvenuehourtickinfosetterPage.prototype.moveNext = function () {
        // prepackage information to send to next view controller
        // create an array of stringified ticket information to pass on
        var stringifiedHourTicketInfo = [];
        var i = 0;
        for (i = 0; i < this.ticketInfo.length; i++) {
            stringifiedHourTicketInfo.push(JSON.stringify(this.ticketInfo[i]));
        }
        console.log("DEBUG: stringifiedHourTicketInfo array is: " + JSON.stringify(stringifiedHourTicketInfo));
        var toPassOn = {
            //original information received from previous slide
            name: this.received_temp_venue_info.name,
            address: this.received_temp_venue_info.address,
            venueDescription: this.received_temp_venue_info.venueDescription,
            phoneNumber: this.received_temp_venue_info.phoneNumber,
            // now we add in the new information
            //    the start and end dates of the event
            startDate: this.received_temp_venue_info.startDate,
            endDate: this.received_temp_venue_info.endDate,
            //    the start times and end times of the event
            //    note the CRITICAL ASSUMPTION that the start 
            //    time is PM and the end time is AM.
            startTime: this.received_temp_venue_info.startTime,
            endTime: this.received_temp_venue_info.endTime,
            // Now we toss in the array of information
            // It is an array with the following information
            // for each one-hour time slot:
            //    startHour, numTickets, ticketPrice 
            ticketInfo: stringifiedHourTicketInfo
        };
        this.router.navigate(["tempvenuecredentialregister", toPassOn]);
    };
    TempvenuehourtickinfosetterPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-tempvenuehourtickinfosetter',
            template: __webpack_require__(/*! ./tempvenuehourtickinfosetter.page.html */ "./src/app/tempvenuehourtickinfosetter/tempvenuehourtickinfosetter.page.html"),
            styles: [__webpack_require__(/*! ./tempvenuehourtickinfosetter.page.scss */ "./src/app/tempvenuehourtickinfosetter/tempvenuehourtickinfosetter.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _globals__WEBPACK_IMPORTED_MODULE_3__["Globals"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])
    ], TempvenuehourtickinfosetterPage);
    return TempvenuehourtickinfosetterPage;
}());



/***/ })

}]);
//# sourceMappingURL=tempvenuehourtickinfosetter-tempvenuehourtickinfosetter-module.js.map