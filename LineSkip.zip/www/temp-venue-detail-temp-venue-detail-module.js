(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["temp-venue-detail-temp-venue-detail-module"],{

/***/ "./src/app/temp-venue-detail/temp-venue-detail.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/temp-venue-detail/temp-venue-detail.module.ts ***!
  \***************************************************************/
/*! exports provided: TempVenueDetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TempVenueDetailPageModule", function() { return TempVenueDetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _temp_venue_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./temp-venue-detail.page */ "./src/app/temp-venue-detail/temp-venue-detail.page.ts");







var routes = [
    {
        path: '',
        component: _temp_venue_detail_page__WEBPACK_IMPORTED_MODULE_6__["TempVenueDetailPage"]
    }
];
var TempVenueDetailPageModule = /** @class */ (function () {
    function TempVenueDetailPageModule() {
    }
    TempVenueDetailPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_temp_venue_detail_page__WEBPACK_IMPORTED_MODULE_6__["TempVenueDetailPage"]]
        })
    ], TempVenueDetailPageModule);
    return TempVenueDetailPageModule;
}());



/***/ }),

/***/ "./src/app/temp-venue-detail/temp-venue-detail.page.html":
/*!***************************************************************!*\
  !*** ./src/app/temp-venue-detail/temp-venue-detail.page.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-button slot=\"start\" (click)=\"goBack()\" fill=\"clear\">\n      <ion-icon name=\"arrow-back\" class=\"back\"></ion-icon>\n    </ion-button>\n    <ion-title text-center>{{item.name}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content padding>\n  <!-- <ion-img src=\"{{item.photo}}\"></ion-img> -->\n  <ion-item lines=\"none\">\n    <ion-label class=\"descriptiveInfolabel\">\n      <b>Description:</b> \n    </ion-label>\n  </ion-item>\n  <ion-item>\n    <ion-label class=\"descriptiveInfolabel\">{{item.descripton}}</ion-label>\n  </ion-item>\n\n  <ion-item lines=\"none\">\n    <ion-label class=\"descriptiveInfolabel\"> <b>Start Date:</b> {{getDateString(item.startDate)}}</ion-label>\n  </ion-item>\n  \n\n  <ion-item>\n  <ion-label class=\"descriptiveInfolabel\"><b>End Date:</b> {{getDateString(item.endDate)}}</ion-label>\n  </ion-item>\n\n  <ion-item lines=\"none\">\n  <ion-label class=\"descriptiveInfolabel\"><b>Address:</b></ion-label>\n  </ion-item>\n  <ion-item lines=\"none\">\n    <ion-label class=\"descriptiveInfolabel\">{{item.address}}</ion-label>\n  </ion-item>\n\n  <ion-item>\n  <ion-label class=\"descriptiveInfolabel\"><b>Phone Number:</b> {{item.phoneNumber}}</ion-label>\n  </ion-item>\n\n  <ion-item>\n    <ion-label class=\"eventInfoLabel\">\n      Hourly Ticket Info:\n    </ion-label>\n  </ion-item>\n\n  <ion-item *ngFor=\"let hour of hourSlotArray\" (click)=\"selectedSlot(hour)\" text-wrap>\n    <ion-icon class=\"bullet\" name=\"radio-button-on\"></ion-icon>\n    <ion-label class=\"timeslotlabel\">\n       {{ getStringHour( hour ) }}\n      to {{ getStringHour( hour + 1) }}\n    </ion-label>\n  </ion-item>\n\n</ion-content>"

/***/ }),

/***/ "./src/app/temp-venue-detail/temp-venue-detail.page.scss":
/*!***************************************************************!*\
  !*** ./src/app/temp-venue-detail/temp-venue-detail.page.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header,\nion-toolbar, ion-content {\n  --background: black;\n  color: white; }\n\n.back {\n  color: white; }\n\n.eventInfoLabel {\n  width: 100%;\n  font-style: bold;\n  font-size: 20pt;\n  text-align: center;\n  font-family: \"Arial Rounded MT Bold\"; }\n\n.descriptiveInfolabel {\n  font-style: bold;\n  font-size: 15pt; }\n\n.timeslotlabel {\n  margin-left: 5px; }\n\n.bullet {\n  width: 20px;\n  height: 20px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGVtcC12ZW51ZS1kZXRhaWwvRTpcXFVzZXJzXFxTYWRlZ2hpVGFiYXNcXERlc2t0b3BcXExpbmVTa2lwL3NyY1xcYXBwXFx0ZW1wLXZlbnVlLWRldGFpbFxcdGVtcC12ZW51ZS1kZXRhaWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOztFQUVJLG1CQUFhO0VBQ2IsWUFBWSxFQUFBOztBQUdoQjtFQUNJLFlBQVksRUFBQTs7QUFHaEI7RUFDSSxXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLGVBQWU7RUFDZixrQkFBa0I7RUFDbEIsb0NBQW9DLEVBQUE7O0FBR3hDO0VBQ0ksZ0JBQWdCO0VBQ2hCLGVBQWUsRUFBQTs7QUFHbkI7RUFDSSxnQkFBZ0IsRUFBQTs7QUFHcEI7RUFDSSxXQUFXO0VBQ1gsWUFBWSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvdGVtcC12ZW51ZS1kZXRhaWwvdGVtcC12ZW51ZS1kZXRhaWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlcixcclxuaW9uLXRvb2xiYXIsIGlvbi1jb250ZW50IHtcclxuICAgIC0tYmFja2dyb3VuZDogYmxhY2s7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbn1cclxuXHJcbi5iYWNrIHtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufVxyXG5cclxuLmV2ZW50SW5mb0xhYmVsIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgZm9udC1zdHlsZTogYm9sZDtcclxuICAgIGZvbnQtc2l6ZTogMjBwdDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtZmFtaWx5OiBcIkFyaWFsIFJvdW5kZWQgTVQgQm9sZFwiO1xyXG59XHJcblxyXG4uZGVzY3JpcHRpdmVJbmZvbGFiZWwge1xyXG4gICAgZm9udC1zdHlsZTogYm9sZDtcclxuICAgIGZvbnQtc2l6ZTogMTVwdDtcclxufVxyXG5cclxuLnRpbWVzbG90bGFiZWwge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDVweDtcclxufVxyXG5cclxuLmJ1bGxldCB7XHJcbiAgICB3aWR0aDogMjBweDtcclxuICAgIGhlaWdodDogMjBweDtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/temp-venue-detail/temp-venue-detail.page.ts":
/*!*************************************************************!*\
  !*** ./src/app/temp-venue-detail/temp-venue-detail.page.ts ***!
  \*************************************************************/
/*! exports provided: TempVenueDetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TempVenueDetailPage", function() { return TempVenueDetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var TempVenueDetailPage = /** @class */ (function () {
    function TempVenueDetailPage(route, r) {
        var _this = this;
        this.route = route;
        this.r = r;
        this.r.params.subscribe(function (params) { _this.item = JSON.parse(params['selectedVenue']); });
    }
    TempVenueDetailPage.prototype.ngOnInit = function () {
        console.log("In tab4, initializing the hour slot array");
        this.initializeHourSlotArray();
    };
    TempVenueDetailPage.prototype.ionViewDidEnter = function () {
        // update its value
        console.log("DEBUG: ENTERING temVenueDetailPage - the temporary venue is: " +
            JSON.stringify(this.item.name));
        console.log("\tAND DEBUG: The ticket info is: " +
            JSON.stringify(this.item.ticketInfo));
        console.log("Logging into a temp venue. \
                      \nThe objects stored inside the stringified purchaserIDs array contain the following \
                      \n\t(1) uid of the purchaser \
                      \n\t(2) the hour for which they purchased tickets");
    };
    TempVenueDetailPage.prototype.initializeHourSlotArray = function () {
        // we initialize the ticket array by parsing the string representation of the 
        // array and converting all items into objects
        var _this = this;
        // split up the objects
        var extractedString = this.item.ticketInfo; // string to process
        // if there is a '[' at the start of the string or end ']'
        if (extractedString.charAt(0) == '[') {
            //remove the leading '['
            extractedString = extractedString.substr(1);
        }
        if (extractedString[extractedString.length - 1] == ']') {
            // remove the trailing ']'
            extractedString = extractedString.slice(0, -1);
        }
        var splitUpObjects = extractedString.split("},");
        var i = 0;
        for (i = 0; i < splitUpObjects.length; i++) {
            if (splitUpObjects[i].slice(-1) != '}') {
                // it does not have the end curly bracked 
                // to close off object in string representation which was chopped off. 
                // correct this mistake
                splitUpObjects[i] = splitUpObjects[i] + "}";
            }
        }
        // now we parse things and save it to the ticket array
        this.hourSlotArray = [];
        splitUpObjects.forEach(function (element) {
            _this.hourSlotArray.push(JSON.parse(element).startHour);
        });
    };
    TempVenueDetailPage.prototype.selectedSlot = function (startHour) {
        console.log("DEBUG: clicked slot and selectedSlot");
        this.route.navigate(['/add-temp-venue-to-cart', { selectedVenue: JSON.stringify(this.item), hrSlotArray: startHour }]);
        console.log("this is my item before sending=" + this.item);
    };
    TempVenueDetailPage.prototype.getDateString = function (stringifiedDateObject) {
        var extractedDateObject = new Date(stringifiedDateObject);
        return extractedDateObject.toLocaleDateString('en-US');
    };
    TempVenueDetailPage.prototype.getStringHour = function (hourNum) {
        // returns "<# hour> <AM/PM>" string
        // for a given inputted number of the starting hour
        if (hourNum < 12) {
            return String(hourNum) + " PM";
        }
        else if (hourNum == 12) {
            return String(hourNum) + " AM";
        }
        else {
            // this is all AM times after 12 AM
            return String(hourNum - 12) + " AM";
        }
    };
    TempVenueDetailPage.prototype.goBack = function () {
        this.route.navigate(['/tabs/tab1']);
    };
    TempVenueDetailPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-temp-venue-detail',
            template: __webpack_require__(/*! ./temp-venue-detail.page.html */ "./src/app/temp-venue-detail/temp-venue-detail.page.html"),
            styles: [__webpack_require__(/*! ./temp-venue-detail.page.scss */ "./src/app/temp-venue-detail/temp-venue-detail.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])
    ], TempVenueDetailPage);
    return TempVenueDetailPage;
}());

// ====================================
// public item: tempVenue;
//   quantity: number;
//   public static Cart;
//   constructor(private route: Router, private r: ActivatedRoute) {
//     this.r.params.subscribe(params => {this.item = JSON.parse(params['selectedItem']);});
//     this.quantity = 1;
//   }
//   ngOnInit() {
//   }
//   addToOrder() {
//     var k = [];
//     TempVenueDetailPage.Cart = new cart();
//     firebase.database().ref('Cart/'+firebase.auth().currentUser.uid).on('value', function(snapshot) {
//       snapshot.forEach(function(cShot) {
//         k.push(cShot.key);
//         firebase.database().ref('Cart/'+cShot.ref.parent.toString().substring(cShot.ref.parent.toString().lastIndexOf('/'))+'/'+k[k.length-1]).on('value', function(cSnap) {
//           var m = cSnap.val();
//           TempVenueDetailPage.Cart = JSON.parse(m);
//         });
//       });
//     });
//     for(var i:number=0; i<this.quantity; i++) {
//       TempVenueDetailPage.Cart.currentOrder.items.push(this.item);
//       TempVenueDetailPage.Cart.currentOrder.totalItems++;
//       TempVenueDetailPage.Cart.currentOrder.totalPrice += this.item.ticketInfo; // *** price
//       TempVenueDetailPage.Cart.orderList[TempVenueDetailPage.Cart.orderList.length-1] = TempVenueDetailPage.Cart.currentOrder;
//     }
//     var s = {};
//     s['userOrder'] = JSON.stringify(TempVenueDetailPage.Cart);
//     firebase.database().ref('Cart/'+firebase.auth().currentUser.uid).update(s);
//     if(this.quantity > 1) {
//       alert("These items has been added to your order.");
//     } else if(this.quantity == 1) {
//       alert("This item has been added to your order.");
//     }
//   }
//   goBack() {
//     this.route.navigate(['/tab1']);
//   }


/***/ })

}]);
//# sourceMappingURL=temp-venue-detail-temp-venue-detail-module.js.map