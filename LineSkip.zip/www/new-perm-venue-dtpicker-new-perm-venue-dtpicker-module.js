(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["new-perm-venue-dtpicker-new-perm-venue-dtpicker-module"],{

/***/ "./src/app/new-perm-venue-dtpicker/new-perm-venue-dtpicker.module.ts":
/*!***************************************************************************!*\
  !*** ./src/app/new-perm-venue-dtpicker/new-perm-venue-dtpicker.module.ts ***!
  \***************************************************************************/
/*! exports provided: NewPermVenueDtpickerPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewPermVenueDtpickerPageModule", function() { return NewPermVenueDtpickerPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _new_perm_venue_dtpicker_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./new-perm-venue-dtpicker.page */ "./src/app/new-perm-venue-dtpicker/new-perm-venue-dtpicker.page.ts");
/* harmony import */ var ionic4_date_picker__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ionic4-date-picker */ "./node_modules/ionic4-date-picker/dist/index.js");








var routes = [
    {
        path: '',
        component: _new_perm_venue_dtpicker_page__WEBPACK_IMPORTED_MODULE_6__["NewPermVenueDtpickerPage"]
    }
];
var NewPermVenueDtpickerPageModule = /** @class */ (function () {
    function NewPermVenueDtpickerPageModule() {
    }
    NewPermVenueDtpickerPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                ionic4_date_picker__WEBPACK_IMPORTED_MODULE_7__["DatePickerModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_new_perm_venue_dtpicker_page__WEBPACK_IMPORTED_MODULE_6__["NewPermVenueDtpickerPage"]]
        })
    ], NewPermVenueDtpickerPageModule);
    return NewPermVenueDtpickerPageModule;
}());



/***/ }),

/***/ "./src/app/new-perm-venue-dtpicker/new-perm-venue-dtpicker.page.html":
/*!***************************************************************************!*\
  !*** ./src/app/new-perm-venue-dtpicker/new-perm-venue-dtpicker.page.html ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar class=\"toolbar_header\">\n    <ion-title>Add New Permanent Venue</ion-title>\n    <ion-buttons slot=\"start\">\n        <ion-button (click)=\"cancel()\"\n          style=\"color: white;\">\n          Cancel\n        </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n\n\n</ion-header>\n\n<ion-content>\n\n<!-- Start Date Calendar -->\n<!-- <ion-item>\n    <ion-icon slot=\"start\" name=\"calendar\" size=\"large\"></ion-icon>\n    <ion-label position=\"floating\">Select the Date</ion-label>\n    <ion-datetime display-format=\"YYYY-MM-DD\" picker-format=\"YYYY MMMM DD\" min=\"2019-04-05\" max=\"2019\"></ion-datetime>\n\n</ion-item> -->\n<ion-item>\n    <ion-label>Select The Day Type</ion-label>\n    <ion-select value=\"brown\" okText=\"Okay\" cancelText=\"Dismiss\">\n      <ion-select-option value=\"brown\">Regular Day</ion-select-option>\n      <ion-select-option value=\"blue\">Drinking Holiday</ion-select-option>\n      <ion-select-option value=\"green\">Game Day</ion-select-option>\n      <ion-select-option value=\"red\">Something else..</ion-select-option>\n    </ion-select>\n  </ion-item>\n  \n<!-- Date Calendar -->\n <ion-item lines=\"none\" \n           (click)=\"toggleViewingEndDateCalendar()\">\n  <ion-label class=\"selectlabel\">\n    <b>Select the Dates:</b> \n  </ion-label>\n\n</ion-item>\n\n<ion-item> \n\n  <ionic-calendar-date-picker \n    [fromDate]= \"getDateAfterSelectedStartDate()\"\n    [date]= \"getDateAfterSelectedStartDate()\" \n    [toDate]=\"getEndOfYear()\"\n    (onSelect)=\"endDateSelected($event)\">\n  </ionic-calendar-date-picker>\t\n</ion-item> -->\n\n<!-- Select Start Time -->\n<!-- <ion-item>\n  <ion-label><b>Start Time (PM): </b></ion-label>\n  <ion-label class=\"promptLabel\"\n             *ngIf=\"!hasSelectedStartTime()\">\n    <b>Click to Choose</b>\n  </ion-label>\n  <ion-datetime displayFormat=\"h:mm\" \n                minuteValues=\"0\"\n                hourValues=\"8,9,10,11\"\n                [(ngModel)]=\"startTime\"\n                (ngModelChange)=\"changedStartTime($event)\"\n                name=\"startTime\">\n  </ion-datetime>\n</ion-item> -->\n\n<!-- Select End Time  -->\n  <!-- <ion-item>\n      <ion-label><b>End Time (AM): </b></ion-label>\n      <ion-label class=\"promptLabel\"\n             *ngIf=\"!hasSelectedEndTime()\">\n        <b>Click to Choose</b>\n      </ion-label>\n      <ion-datetime displayFormat=\"h:mm\" \n                    minuteValues=\"0\"\n                    hourValues=\"12,1,2\"\n                    name=\"endTime\"\n                    [(ngModel)]=\"endTime\"\n                    (ngModelChange)=\"changedEndTime($event)\">\n      </ion-datetime>\n  </ion-item> -->\n<ion-item *ngIf=\"\"\n  (clicked)=\"moveToTicketsInfo()\">\n<ion-button slot=\"start\" class=\"submitbutton\"\n      (click)=\"moveToTicketsInfo()\">\nSave\n</ion-button>\n</ion-item>\n<ion-item *ngIf=\"\"\n          (clicked)=\"moveToTicketsInfo()\">\n  <ion-button slot=\"end\" class=\"submitbutton\"\n              (click)=\"moveToTicketsInfo()\">\n    Next\n  </ion-button>\n</ion-item>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/new-perm-venue-dtpicker/new-perm-venue-dtpicker.page.scss":
/*!***************************************************************************!*\
  !*** ./src/app/new-perm-venue-dtpicker/new-perm-venue-dtpicker.page.scss ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar_header {\n  --background: black;\n  color: white; }\n\nion-content {\n  --background: black;\n  color: white; }\n\n.selectlabel {\n  font-style: bold;\n  font-size: 13pt; }\n\n.submitbutton {\n  margin: 0 auto;\n  width: 100pt;\n  height: 25pt;\n  font-style: bold;\n  --background: darkgrey;\n  color: white;\n  font-size: 15pt;\n  margin-top: 10px;\n  margin-bottom: 10px; }\n\n.promptLabel {\n  color: darkgrey;\n  font-style: bold;\n  text-align: right;\n  margin-right: -5px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbmV3LXBlcm0tdmVudWUtZHRwaWNrZXIvRTpcXFVzZXJzXFxTYWRlZ2hpVGFiYXNcXERlc2t0b3BcXExpbmVTa2lwL3NyY1xcYXBwXFxuZXctcGVybS12ZW51ZS1kdHBpY2tlclxcbmV3LXBlcm0tdmVudWUtZHRwaWNrZXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksZ0JBQWdCO0VBQ2hCLGVBQWUsRUFBQTs7QUFHbkI7RUFDSSxjQUFjO0VBQ2QsWUFBWTtFQUNaLFlBQVk7RUFDWixnQkFBZ0I7RUFDaEIsc0JBQWE7RUFDYixZQUFZO0VBQ1osZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixtQkFBbUIsRUFBQTs7QUFHdkI7RUFDSSxlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLGlCQUFpQjtFQUNqQixrQkFBa0IsRUFBQSIsImZpbGUiOiJzcmMvYXBwL25ldy1wZXJtLXZlbnVlLWR0cGlja2VyL25ldy1wZXJtLXZlbnVlLWR0cGlja2VyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50b29sYmFyX2hlYWRlciB7XHJcbiAgICAtLWJhY2tncm91bmQ6IGJsYWNrO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG5pb24tY29udGVudCB7XHJcbiAgICAtLWJhY2tncm91bmQ6IGJsYWNrO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG4uc2VsZWN0bGFiZWwge1xyXG4gICAgZm9udC1zdHlsZTogYm9sZDtcclxuICAgIGZvbnQtc2l6ZTogMTNwdDtcclxufVxyXG5cclxuLnN1Ym1pdGJ1dHRvbiB7XHJcbiAgICBtYXJnaW46IDAgYXV0bztcclxuICAgIHdpZHRoOiAxMDBwdDtcclxuICAgIGhlaWdodDogMjVwdDtcclxuICAgIGZvbnQtc3R5bGU6IGJvbGQ7XHJcbiAgICAtLWJhY2tncm91bmQ6IGRhcmtncmV5O1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgZm9udC1zaXplOiAxNXB0O1xyXG4gICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbn1cclxuXHJcbi5wcm9tcHRMYWJlbCB7XHJcbiAgICBjb2xvcjogZGFya2dyZXk7XHJcbiAgICBmb250LXN0eWxlOiBib2xkO1xyXG4gICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IC01cHg7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/new-perm-venue-dtpicker/new-perm-venue-dtpicker.page.ts":
/*!*************************************************************************!*\
  !*** ./src/app/new-perm-venue-dtpicker/new-perm-venue-dtpicker.page.ts ***!
  \*************************************************************************/
/*! exports provided: NewPermVenueDtpickerPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewPermVenueDtpickerPage", function() { return NewPermVenueDtpickerPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);




var NewPermVenueDtpickerPage = /** @class */ (function () {
    function NewPermVenueDtpickerPage(router, route) {
        this.router = router;
        this.route = route;
        // this page allows us to select a temporary venue's
        // start date, end date, start time, and end time
        this.selectedStartDate = false;
        this.selectedEndDate = false;
        this.selectedInitialTime = false;
        this.selectedEndTime = false;
        // we have the minimum date for the starting of the date
        // picker
        this.minStartDate = new Date().toISOString();
        // The results of the date pickers
        this.startDate = null;
        this.endDate = null;
        this.startTime = null;
        this.endTime = null;
        // variables that control the collapsing of the calendars
        // for easier visual viewing by saving space
        this.collapseStartDateCalendar = false;
        this.collapseEndDateCalendar = false;
    }
    NewPermVenueDtpickerPage.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.subscribe(function (param) {
            _this.basicNewPermVenueInfo = param;
        });
    };
    NewPermVenueDtpickerPage.prototype.ionViewDidLeave = function () {
        // we leave the view so we reset all the variables
        // so that when we re-enter the view will be good as new!
        this.selectedStartDate = false;
        this.selectedEndDate = false;
        this.selectedInitialTime = false;
        this.selectedEndTime = false;
        this.startDate = null;
        this.endDate = null;
        this.startTime = null;
        this.endTime = null;
        this.collapseStartDateCalendar = false;
        this.collapseEndDateCalendar = false;
    };
    NewPermVenueDtpickerPage.prototype.getTodayDate = function () {
        return new Date();
    };
    NewPermVenueDtpickerPage.prototype.getTomorrow = function () {
        // we get tomorrow's date
        return new Date(this.getTodayDate().getTime() +
            (24 * 60 * 60 * 1000));
    };
    NewPermVenueDtpickerPage.prototype.getEndOfYear = function () {
        // get the beginning of the year
        var beginningOfNextYear = new Date(new Date().getFullYear() + 1, 0, 1);
        // subtract a day from it and return that
        return new Date(beginningOfNextYear.getTime() -
            (24 * 60 * 60 * 1000));
    };
    NewPermVenueDtpickerPage.prototype.cancel = function () {
        this.router.navigate(["/signupvenue"]);
    };
    NewPermVenueDtpickerPage.prototype.changedStartTime = function (newTime) {
        this.selectedInitialTime = true;
        console.log("DEBUG: the new start time is: " + this.startTime);
    };
    NewPermVenueDtpickerPage.prototype.changedEndTime = function (newTime) {
        this.selectedEndTime = true;
        console.log("DEBUG: the new end time is: " + this.endTime);
    };
    NewPermVenueDtpickerPage.prototype.getChoseOrSelectedStartTime = function () {
        if (this.selectedInitialTime) {
            return "Selected ";
        }
        else {
            return "Choose ";
        }
    };
    NewPermVenueDtpickerPage.prototype.getChoseOrSelectedEndTime = function () {
        if (this.selectedEndTime) {
            return "Selected ";
        }
        else {
            return "Choose ";
        }
    };
    NewPermVenueDtpickerPage.prototype.hasSelectedStartTime = function () {
        // IF the start time is selected
        return this.selectedInitialTime;
    };
    NewPermVenueDtpickerPage.prototype.hasSelectedEndTime = function () {
        return this.selectedEndTime;
    };
    NewPermVenueDtpickerPage.prototype.initialDateSelected = function (newDate) {
        console.log("DEBUG: SELECTED INITIAL DATE: " + newDate);
        this.selectedStartDate = true;
        this.startDate = newDate;
        // Now we check the case if 
        // the second date has already been selected
        if (this.endDate != null && this.selectedEndDate == true) {
            // We need to reset the whole thing in order to 
            // select a proper end date
            // And have the end date calendar open
            this.endDate = null;
            this.selectedEndDate = false;
            // collapse the first calendar
            this.toggleViewingStartDateCalendar();
        }
    };
    NewPermVenueDtpickerPage.prototype.endDateSelected = function (newEndDate) {
        console.log("DEBUG: SELECTED END DATE: " + newEndDate);
        this.selectedEndDate = true;
        this.endDate = newEndDate;
    };
    NewPermVenueDtpickerPage.prototype.getDateAfterSelectedStartDate = function () {
        if (this.startDate == null) {
            return null;
        }
        // otherwise, take the startDate and add 24 hours to it
        return new Date(this.startDate.getTime() +
            (24 * 60 * 60 * 1000));
    };
    NewPermVenueDtpickerPage.prototype.toggleViewingStartDateCalendar = function () {
        if (this.startDate != null &&
            this.selectedStartDate == true) {
            //we selected a start date
            // and toggle the start date calendar's viewing
            this.collapseStartDateCalendar = !this.collapseStartDateCalendar;
        }
    };
    NewPermVenueDtpickerPage.prototype.toggleViewingEndDateCalendar = function () {
        if (this.endDate != null && this.selectedEndDate == true) {
            // we selected the end date and toggle the
            // end date calendar's viewing
            this.collapseEndDateCalendar = !this.collapseEndDateCalendar;
        }
    };
    NewPermVenueDtpickerPage.prototype.getStartDateOutput = function () {
        // we get the string representation of the date
        // if one is selected
        if (this.startDate == null) {
            return "";
        }
        else {
            return moment__WEBPACK_IMPORTED_MODULE_3__(this.startDate).format("MM/DD/YYYY");
        }
    };
    NewPermVenueDtpickerPage.prototype.getEndDateOutput = function () {
        // we get the string representation of the date
        // if one is selected
        if (this.endDate == null) {
            return "";
        }
        else {
            return moment__WEBPACK_IMPORTED_MODULE_3__(this.endDate).format("MM/DD/YYYY");
        }
    };
    NewPermVenueDtpickerPage.prototype.getChoseOrSelectedStartDate = function () {
        // if we selected a start date,
        // then we return the string "Selected"
        // for display in the html file
        // if we did not select, then we return the
        // string "Choose" - to prompt users to select a start date
        if (this.startDate == null) {
            return "Choose ";
        }
        else {
            return "Selected ";
        }
    };
    NewPermVenueDtpickerPage.prototype.getChoseOrSelectedEndDate = function () {
        // if we selected a end date,
        // then we return the string "Selected"
        // for display in the html file
        // if we did not select, then we return the
        // string "Choose" - to prompt users to select a start date
        if (this.endDate == null) {
            return "Choose ";
        }
        else {
            return "Selected ";
        }
    };
    NewPermVenueDtpickerPage.prototype.canShowStartDateCalendar = function () {
        // we display the calendar only if
        // the initial date wasn't selected
        // or if the initial date was selected
        // and we deliberately want to see it
        var toReturn = (!this.selectedStartDate ||
            (this.selectedStartDate &&
                this.collapseStartDateCalendar));
        return toReturn;
    };
    NewPermVenueDtpickerPage.prototype.canShowEndDateCalendar = function () {
        // we display the calendar only if
        // the initial date wasn't selected
        // or if the initial date was selected
        // and we deliberately want to see it
        var toReturn = ((!this.selectedEndDate &&
            this.selectedStartDate)
            ||
                (this.selectedEndDate &&
                    this.collapseEndDateCalendar));
        return toReturn;
    };
    NewPermVenueDtpickerPage.prototype.showStartPullUpArrow = function () {
        return this.canShowStartDateCalendar() && this.selectedStartDate != false;
    };
    NewPermVenueDtpickerPage.prototype.showEndPullUpArrow = function () {
        return this.canShowEndDateCalendar() && this.selectedEndDate != false;
    };
    // moveToTicketsInfo packages the information collected
    // so far about the new temporary venue and passes it on
    // to the next view controller.
    // We add extra information to basicNewPermVenueInfo
    NewPermVenueDtpickerPage.prototype.moveToTicketsInfo = function () {
        console.log("CLICKED MOVE TO TICKETS INFO");
        var toPassOn = {
            //original information received from previous slide
            name: this.basicNewPermVenueInfo.name,
            address: this.basicNewPermVenueInfo.address,
            venueDescription: this.basicNewPermVenueInfo.venueDescription,
            phoneNumber: this.basicNewPermVenueInfo.phoneNumber,
            // now we add in the new information
            //    the start and end dates of the event
            startDate: this.startDate,
            endDate: this.endDate,
            //    the start times and end times of the event
            //    note the CRITICAL ASSUMPTION that the start 
            //    time is PM and the end time is AM.
            startTime: this.startTime,
            endTime: this.endTime
        };
        this.router.navigate(["perm-venue-hr-info-setter", toPassOn]);
    };
    NewPermVenueDtpickerPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-new-perm-venue-dtpicker',
            template: __webpack_require__(/*! ./new-perm-venue-dtpicker.page.html */ "./src/app/new-perm-venue-dtpicker/new-perm-venue-dtpicker.page.html"),
            styles: [__webpack_require__(/*! ./new-perm-venue-dtpicker.page.scss */ "./src/app/new-perm-venue-dtpicker/new-perm-venue-dtpicker.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])
    ], NewPermVenueDtpickerPage);
    return NewPermVenueDtpickerPage;
}());



/***/ })

}]);
//# sourceMappingURL=new-perm-venue-dtpicker-new-perm-venue-dtpicker-module.js.map