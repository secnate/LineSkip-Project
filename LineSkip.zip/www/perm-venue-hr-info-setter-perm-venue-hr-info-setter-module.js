(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["perm-venue-hr-info-setter-perm-venue-hr-info-setter-module"],{

/***/ "./src/app/perm-venue-hr-info-setter/perm-venue-hr-info-setter.module.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/perm-venue-hr-info-setter/perm-venue-hr-info-setter.module.ts ***!
  \*******************************************************************************/
/*! exports provided: PermVenueHrInfoSetterPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PermVenueHrInfoSetterPageModule", function() { return PermVenueHrInfoSetterPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _perm_venue_hr_info_setter_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./perm-venue-hr-info-setter.page */ "./src/app/perm-venue-hr-info-setter/perm-venue-hr-info-setter.page.ts");







var routes = [
    {
        path: '',
        component: _perm_venue_hr_info_setter_page__WEBPACK_IMPORTED_MODULE_6__["PermVenueHrInfoSetterPage"]
    }
];
var PermVenueHrInfoSetterPageModule = /** @class */ (function () {
    function PermVenueHrInfoSetterPageModule() {
    }
    PermVenueHrInfoSetterPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_perm_venue_hr_info_setter_page__WEBPACK_IMPORTED_MODULE_6__["PermVenueHrInfoSetterPage"]]
        })
    ], PermVenueHrInfoSetterPageModule);
    return PermVenueHrInfoSetterPageModule;
}());



/***/ }),

/***/ "./src/app/perm-venue-hr-info-setter/perm-venue-hr-info-setter.page.html":
/*!*******************************************************************************!*\
  !*** ./src/app/perm-venue-hr-info-setter/perm-venue-hr-info-setter.page.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar class=\"toolbar_header\">\n    <ion-title></ion-title>\n    <ion-buttons slot=\"start\">\n        <ion-button (click)=\"cancel()\"\n          style=\"color: white;\">\n          Cancel\n        </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n<ion-item lines=\"none\">\n  <ion-label class=\"title\">\n    Enter Hourly Information\n  </ion-label>\n</ion-item>\n\n<ion-item>\n  <ion-label>\n    Note: Enter Only Positive Integers \n  </ion-label>\n</ion-item>\n\n<!-- We assume that the user enters valid input \n     due to their phone keyboards limiting them only\n     to numerical inputs.\n-->\n<ion-item *ngFor = \"let hourSlot of ticketInfo\" text-wrap>\n    <ion-grid>\n      <ion-row>\n        <ion-label class=\"timeslotlabel\">\n          <b>{{ getHourSlotString(hourSlot.startHour )}}</b>\n         </ion-label>\n      </ion-row>\n   \n      <ion-row>\n        <ion-label class=\"inputlabel\"><b>Number of Tickets:</b></ion-label>\n        <ion-input type=\"number\" inputmode=\"numeric\" \n                   min=\"0\" pattern=\"^[1-9]\\d*$\"\n                   [(ngModel)]=\"hourSlot.numTickets\">\n        </ion-input>\n      </ion-row>\n\n      <ion-row>\n        <ion-label class=\"inputlabel\"><b>Price Per Ticket:</b></ion-label>\n        <ion-input type=\"number\" inputmode=\"numeric\"\n                   min=\"0\" pattern=\"^[1-9]\\d*$\"\n                   [(ngModel)]=\"hourSlot.ticketPrice\">\n        </ion-input>\n      </ion-row>\n  </ion-grid>\n</ion-item>\n\n\n<!-- If any empty, we can not go next -->\n  <ion-button (click)=\"moveNext()\" *ngIf=\"!anyEmpty()\" id=\"button\">\n   Next\n  </ion-button>\n\n<!-- Instead, we display a warning -->\n<ion-grid>\n  <ion-row>\n    <ion-label *ngIf=\"anyEmpty()\" text-wrap class=\"warninglabel\">\n      <u>Invalid State:</u>\n    </ion-label>\n  </ion-row>\n  <ion-row>\n    <ion-label *ngIf=\"anyEmpty()\" text-wrap class=\"warninglabel\">\n     At least one input box is empty.\n     </ion-label>\n  </ion-row>\n</ion-grid>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/perm-venue-hr-info-setter/perm-venue-hr-info-setter.page.scss":
/*!*******************************************************************************!*\
  !*** ./src/app/perm-venue-hr-info-setter/perm-venue-hr-info-setter.page.scss ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar_header {\n  --background: black;\n  color: white; }\n\nion-content {\n  --background: white;\n  color: white; }\n\n.title {\n  font-size: 15pt;\n  font-style: bold;\n  font-family: \"Arial Rounded MT Bold\";\n  text-align: center; }\n\nion-input {\n  border-bottom: 1px black solid;\n  margin-left: 5px; }\n\nion-row {\n  height: 100%;\n  vertical-align: middle;\n  align-items: center; }\n\n.inputlabel {\n  display: flex;\n  vertical-align: middle;\n  background: transparent; }\n\n.timeslotlabel {\n  font-size: 13pt;\n  font-style: bold;\n  font-family: \"Arial Rounded MT Bold\"; }\n\n#button {\n  margin-top: 15px;\n  margin-left: 10%;\n  margin-right: 0px;\n  width: 100px;\n  --background: darkgrey;\n  color: white;\n  font-size: 16pt;\n  font-style: bold;\n  font-family: \"Arial Rounded MT Bold\";\n  height: 50px;\n  text-align: right;\n  border-radius: 10px;\n  vertical-align: bottom; }\n\n.warninglabel {\n  margin-top: 10px;\n  --background: white;\n  color: black;\n  font-size: 13pt;\n  font-style: bold;\n  font-family: \"Arial Rounded MT Bold\";\n  margin-left: 10%;\n  margin-right: -10%;\n  text-align: center; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGVybS12ZW51ZS1oci1pbmZvLXNldHRlci9FOlxcVXNlcnNcXFNhZGVnaGlUYWJhc1xcRGVza3RvcFxcTGluZVNraXAvc3JjXFxhcHBcXHBlcm0tdmVudWUtaHItaW5mby1zZXR0ZXJcXHBlcm0tdmVudWUtaHItaW5mby1zZXR0ZXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixvQ0FBb0M7RUFDcEMsa0JBQWtCLEVBQUE7O0FBR3RCO0VBQ0ksOEJBQThCO0VBQzlCLGdCQUFnQixFQUFBOztBQUdwQjtFQUNJLFlBQVk7RUFDWixzQkFBc0I7RUFDdEIsbUJBQW1CLEVBQUE7O0FBR3ZCO0VBQ0ksYUFBYTtFQUNiLHNCQUFzQjtFQUN0Qix1QkFBdUIsRUFBQTs7QUFHM0I7RUFDSSxlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLG9DQUFvQyxFQUFBOztBQUd4QztFQUNJLGdCQUFnQjtFQUNoQixnQkFBZ0I7RUFDaEIsaUJBQWlCO0VBQ2pCLFlBQVk7RUFDWixzQkFBYTtFQUNiLFlBQVk7RUFDWixlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLG9DQUFvQztFQUNwQyxZQUFZO0VBQ1osaUJBQWlCO0VBQ2pCLG1CQUFtQjtFQUNuQixzQkFBc0IsRUFBQTs7QUFHMUI7RUFDSSxnQkFBZ0I7RUFDaEIsbUJBQWE7RUFDYixZQUFZO0VBQ1osZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixvQ0FBb0M7RUFDcEMsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixrQkFBa0IsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3Blcm0tdmVudWUtaHItaW5mby1zZXR0ZXIvcGVybS12ZW51ZS1oci1pbmZvLXNldHRlci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudG9vbGJhcl9oZWFkZXIge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiBibGFjaztcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufVxyXG5cclxuaW9uLWNvbnRlbnQge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufVxyXG5cclxuLnRpdGxlIHtcclxuICAgIGZvbnQtc2l6ZTogMTVwdDtcclxuICAgIGZvbnQtc3R5bGU6IGJvbGQ7XHJcbiAgICBmb250LWZhbWlseTogXCJBcmlhbCBSb3VuZGVkIE1UIEJvbGRcIjtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuaW9uLWlucHV0IHtcclxuICAgIGJvcmRlci1ib3R0b206IDFweCBibGFjayBzb2xpZDtcclxuICAgIG1hcmdpbi1sZWZ0OiA1cHg7XHJcbn1cclxuXHJcbmlvbi1yb3cge1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5pbnB1dGxhYmVsIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbn1cclxuXHJcbi50aW1lc2xvdGxhYmVsIHtcclxuICAgIGZvbnQtc2l6ZTogMTNwdDtcclxuICAgIGZvbnQtc3R5bGU6IGJvbGQ7XHJcbiAgICBmb250LWZhbWlseTogXCJBcmlhbCBSb3VuZGVkIE1UIEJvbGRcIjtcclxufVxyXG5cclxuI2J1dHRvbiB7XHJcbiAgICBtYXJnaW4tdG9wOiAxNXB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDEwJTtcclxuICAgIG1hcmdpbi1yaWdodDogMHB4O1xyXG4gICAgd2lkdGg6IDEwMHB4O1xyXG4gICAgLS1iYWNrZ3JvdW5kOiBkYXJrZ3JleTtcclxuICAgIGNvbG9yOiB3aGl0ZTsgXHJcbiAgICBmb250LXNpemU6IDE2cHQ7XHJcbiAgICBmb250LXN0eWxlOiBib2xkO1xyXG4gICAgZm9udC1mYW1pbHk6IFwiQXJpYWwgUm91bmRlZCBNVCBCb2xkXCI7XHJcbiAgICBoZWlnaHQ6IDUwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICB2ZXJ0aWNhbC1hbGlnbjogYm90dG9tO1xyXG59XHJcblxyXG4ud2FybmluZ2xhYmVsIHtcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICAtLWJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG4gICAgZm9udC1zaXplOiAxM3B0O1xyXG4gICAgZm9udC1zdHlsZTogYm9sZDtcclxuICAgIGZvbnQtZmFtaWx5OiBcIkFyaWFsIFJvdW5kZWQgTVQgQm9sZFwiO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDEwJTtcclxuICAgIG1hcmdpbi1yaWdodDogLTEwJTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/perm-venue-hr-info-setter/perm-venue-hr-info-setter.page.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/perm-venue-hr-info-setter/perm-venue-hr-info-setter.page.ts ***!
  \*****************************************************************************/
/*! exports provided: PermVenueHrInfoSetterPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PermVenueHrInfoSetterPage", function() { return PermVenueHrInfoSetterPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals */ "./src/globals.ts");




var PermVenueHrInfoSetterPage = /** @class */ (function () {
    function PermVenueHrInfoSetterPage(router, globals, route) {
        this.router = router;
        this.globals = globals;
        this.route = route;
        this.received_perm_venue_info = null;
        // information about the start and end time
        this.startHour = null;
        this.endHour = null;
        this.totalNumHours = null;
        // array of information about tickets
        this.ticketInfo = null;
    }
    PermVenueHrInfoSetterPage.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.subscribe(function (param) {
            _this.received_perm_venue_info = param;
            console.log(JSON.stringify(_this.received_perm_venue_info));
            // Now we have received the user information
            // we now extract the start hour and end hour
            // and start preparing the ticket information
            var dateWithStartTime = _this.received_perm_venue_info.startTime;
            var dateWithEndTime = _this.received_perm_venue_info.endTime;
            // we extract the hours from the two date objects
            _this.startHour = (new Date(dateWithStartTime)).getHours(); // this is PM
            _this.endHour = (new Date(dateWithEndTime)).getHours(); // this is AM
            var numberOfPMHours = 12 - _this.startHour;
            var numberOfAMHours = _this.endHour;
            if (_this.endHour == 12) {
                numberOfAMHours = 0;
            }
            _this.totalNumHours = numberOfPMHours + numberOfAMHours;
            // Now we create an array of objects that will contain
            // three items:
            // (1) Start Hour - the hour that starts the one-hour period
            // (2) Number Tickets
            // (3) End Time
            // This is just a basic empty value array right now
            _this.ticketInfo = new Array(_this.totalNumHours);
            for (var i = 0; i < _this.totalNumHours; i++) {
                _this.ticketInfo[i] = {
                    // if start hour goes over 12, then this is AM zone
                    startHour: _this.startHour + i,
                    numTickets: 0,
                    ticketPrice: 0
                };
            }
            console.log("DEBUG: ticketInfo array is: " + JSON.stringify(_this.ticketInfo));
        });
    };
    PermVenueHrInfoSetterPage.prototype.ionViewWillAppear = function () {
        console.log("DEBUG in it");
        this.ngOnInit();
    };
    PermVenueHrInfoSetterPage.prototype.cancel = function () {
        this.router.navigate(['/signupvenue']);
    };
    PermVenueHrInfoSetterPage.prototype.getHourSlotString = function (startHour) {
        // startHour is a number from 8 to numbers greater than 12
        // 8 to 12 (non-inclusive) are pm times
        // 12 and onwards are AM times
        var toReturn = "";
        if (startHour < 12) {
            // starting hour is PM
            toReturn += startHour.toString() + " PM to ";
        }
        else {
            // starting hour is AM
            if (startHour == 12) {
                toReturn += startHour.toString() + " AM to ";
            }
            else {
                toReturn += (startHour - 12).toString() + " AM to ";
            }
        }
        var endHour = startHour + 1;
        if (endHour < 12) {
            // ending hour is PM
            toReturn += endHour.toString() + " PM: ";
        }
        else {
            // ending hour is AM
            if (endHour == 12) {
                toReturn += endHour.toString() + " AM: ";
            }
            else {
                toReturn += (endHour - 12).toString() + " AM: ";
            }
        }
        return toReturn;
    };
    PermVenueHrInfoSetterPage.prototype.anyEmpty = function () {
        // indicates if any of the inputs are empty
        var toReturn = false;
        this.ticketInfo.forEach(function (element) {
            if (element.ticketPrice == null || element.numTickets == null) {
                toReturn = true;
            }
        });
        return toReturn;
    };
    PermVenueHrInfoSetterPage.prototype.moveNext = function () {
        // prepackage information to send to next view controller
        var toPassOn = {
            //original information received from previous slide
            name: this.received_perm_venue_info.name,
            address: this.received_perm_venue_info.address,
            venueDescription: this.received_perm_venue_info.venueDescription,
            phoneNumber: this.received_perm_venue_info.phoneNumber,
            // now we add in the new information
            //    the start and end dates of the event
            startDate: this.received_perm_venue_info.startDate,
            endDate: this.received_perm_venue_info.endDate,
            //    the start times and end times of the event
            //    note the CRITICAL ASSUMPTION that the start 
            //    time is PM and the end time is AM.
            startTime: this.received_perm_venue_info.startTime,
            endTime: this.received_perm_venue_info.endTime,
            // Now we toss in the array of information
            // It is an array with the following information
            // for each one-hour time slot:
            //    startHour, numTickets, ticketPrice 
            ticketInfo: this.ticketInfo
        };
        this.router.navigate(["perm-venue-cred-reg", toPassOn]);
    };
    PermVenueHrInfoSetterPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-perm-venue-hr-info-setter',
            template: __webpack_require__(/*! ./perm-venue-hr-info-setter.page.html */ "./src/app/perm-venue-hr-info-setter/perm-venue-hr-info-setter.page.html"),
            styles: [__webpack_require__(/*! ./perm-venue-hr-info-setter.page.scss */ "./src/app/perm-venue-hr-info-setter/perm-venue-hr-info-setter.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _globals__WEBPACK_IMPORTED_MODULE_3__["Globals"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])
    ], PermVenueHrInfoSetterPage);
    return PermVenueHrInfoSetterPage;
}());



/***/ })

}]);
//# sourceMappingURL=perm-venue-hr-info-setter-perm-venue-hr-info-setter-module.js.map