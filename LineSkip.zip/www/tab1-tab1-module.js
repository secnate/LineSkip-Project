(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab1-tab1-module"],{

/***/ "./src/app/tab1/tab1.module.ts":
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.module.ts ***!
  \*************************************/
/*! exports provided: Tab1PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab1PageModule", function() { return Tab1PageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _tab1_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tab1.page */ "./src/app/tab1/tab1.page.ts");
// 
//  THIS IS THE NATHAN SIDE OF THE APP.
//  ONLY NATHAN SHOULD MODIFY THIS FILE
//







var Tab1PageModule = /** @class */ (function () {
    function Tab1PageModule() {
    }
    Tab1PageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
            imports: [
                _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild([{ path: '', component: _tab1_page__WEBPACK_IMPORTED_MODULE_6__["Tab1Page"] }])
            ],
            declarations: [_tab1_page__WEBPACK_IMPORTED_MODULE_6__["Tab1Page"]]
        })
    ], Tab1PageModule);
    return Tab1PageModule;
}());



/***/ }),

/***/ "./src/app/tab1/tab1.page.html":
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.page.html ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>\n      \n    </ion-title>\n\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"logout()\">\n        <ion-icon slot=\"icon-only\" class=\"exitButton\" name=\"exit\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n  </ion-toolbar>\n  <ion-toolbar>\n    <ion-searchbar [showCancelButton]=\"true\" color=\"light\" animated=\"true\" placeholder=\"Search Temporary Venues\"\n      [(ngModel)]=\"searchKey\" (ionInput)=\"search()\" (ionClear)=\"clear()\">\n    </ion-searchbar>\n  </ion-toolbar>\n\n</ion-header>\n\n<ion-content>\n  <ion-list lines=\"none\">\n    <ion-item *ngFor=\"let venue of getVenues()\" (click)=\"tempVenueDetail(venue)\" class=\"venueItem\">\n      <ion-thumbnail class=\"venueIMG\" slot=\"start\">\n        <ion-img [src]=\"venue.imgUrl\" ></ion-img>\n      </ion-thumbnail>\n      <ion-label text-wrap lines=\"none\">\n        <div align=left lines=\"none\">\n          <ion-grid no-padding lines=\"none\">\n            <ion-row>\n              <ion-label>\n                <h1>{{ venue.name }}</h1>\n              </ion-label>\n            </ion-row>\n            <ion-row>\n              <ion-label> <b>Description:</b> {{ venue.descripton }} </ion-label>\n            </ion-row>\n            <ion-row >\n              <ion-label> <b>Start Date:</b> {{ getDateString(venue.startDate) }} </ion-label>\n            </ion-row>\n            <ion-row>\n              <ion-label> <b>End Date:</b> {{ getDateString(venue.endDate) }} </ion-label>\n            </ion-row>\n          </ion-grid>\n        </div>\n      </ion-label>\n    </ion-item>\n\n  </ion-list>\n</ion-content>"

/***/ }),

/***/ "./src/app/tab1/tab1.page.scss":
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header, ion-toolbar {\n  --background: black;\n  color: white; }\n\n.exitButton {\n  color: white; }\n\n.welcome-card ion-img {\n  max-height: 35vh;\n  overflow: hidden; }\n\n.venueIMG {\n  min-width: 5rem;\n  min-height: 5rem; }\n\n.venueIMG img {\n    max-width: 5rem;\n    min-width: 5rem; }\n\n.noBtmBorder {\n  border-bottom: none; }\n\n.venueItem {\n  padding-right: 0%;\n  padding-top: 0%;\n  padding-left: 0px;\n  border-bottom: 1px lightgray solid; }\n\n.divNoBorder {\n  border-bottom: none; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGFiMS9FOlxcVXNlcnNcXFNhZGVnaGlUYWJhc1xcRGVza3RvcFxcTGluZVNraXAvc3JjXFxhcHBcXHRhYjFcXHRhYjEucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBR2Q7RUFDRSxZQUFZLEVBQUE7O0FBR2Q7RUFDRSxnQkFBZ0I7RUFDaEIsZ0JBQWdCLEVBQUE7O0FBUWxCO0VBQ0UsZUFBZTtFQUNmLGdCQUFnQixFQUFBOztBQUZsQjtJQUlNLGVBQWU7SUFDZixlQUFlLEVBQUE7O0FBU3JCO0VBQ0UsbUJBQW1CLEVBQUE7O0FBSXJCO0VBQ0UsaUJBQWlCO0VBQ2pCLGVBQWU7RUFDZixpQkFBaUI7RUFDakIsa0NBQWtDLEVBQUE7O0FBR3BDO0VBQ0UsbUJBQW1CLEVBQUEiLCJmaWxlIjoic3JjL2FwcC90YWIxL3RhYjEucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciwgaW9uLXRvb2xiYXJ7XG4gIC0tYmFja2dyb3VuZDogYmxhY2s7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cblxuLmV4aXRCdXR0b24ge1xuICBjb2xvcjogd2hpdGU7XG59XG5cbi53ZWxjb21lLWNhcmQgaW9uLWltZyB7XG4gIG1heC1oZWlnaHQ6IDM1dmg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi8vIC5zZWFyY2hCYXIge1xuLy8gICAtLWJhY2tncm91bmQ6IGJsYWNrO1xuLy8gICBjb2xvcjogd2hpdGU7XG4vLyB9XG5cbi52ZW51ZUlNRyB7XG4gIG1pbi13aWR0aDogNXJlbTsgICAgXG4gIG1pbi1oZWlnaHQ6IDVyZW07XG4gIGltZyB7XG4gICAgICBtYXgtd2lkdGg6IDVyZW07ICAgIFxuICAgICAgbWluLXdpZHRoOiA1cmVtO1xuICB9XG4gIFxufVxuXG4vLyAubGFiZWxHcmlke1xuLy8gICAvLyBtYXJnaW4tbGVmdDogMTBweDtcbi8vIH1cblxuLm5vQnRtQm9yZGVyIHtcbiAgYm9yZGVyLWJvdHRvbTogbm9uZTsgXG4gIC8vIGJvcmRlci1ib3R0b20tY29sb3I6IHRyYW5zcGFyZW50O1xufVxuXG4udmVudWVJdGVte1xuICBwYWRkaW5nLXJpZ2h0OiAwJTtcbiAgcGFkZGluZy10b3A6IDAlO1xuICBwYWRkaW5nLWxlZnQ6IDBweDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IGxpZ2h0Z3JheSBzb2xpZDsgXG59XG5cbi5kaXZOb0JvcmRlcntcbiAgYm9yZGVyLWJvdHRvbTogbm9uZTsgXG59XG5cbiJdfQ== */"

/***/ }),

/***/ "./src/app/tab1/tab1.page.ts":
/*!***********************************!*\
  !*** ./src/app/tab1/tab1.page.ts ***!
  \***********************************/
/*! exports provided: Tab1Page, tempVenue */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab1Page", function() { return Tab1Page; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tempVenue", function() { return tempVenue; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals */ "./src/globals.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");

// 
//  THIS IS THE NATHAN SIDE OF THE APP.
//  ONLY NATHAN SHOULD MODIFY THIS FILE
//





// import { Storage } from '@ionic/storage'
var Tab1Page = /** @class */ (function () {
    function Tab1Page(globals, router, events) {
        var _this = this;
        this.globals = globals;
        this.router = router;
        this.events = events;
        ///////////////////////////////////////////////////////////////////////////
        // Searchbar information
        this.isClearing = false;
        this.searchKey = "";
        this.menus = []; // will be used to indicate the filtered items
        this.menus_all = [];
        this.needToReset = false;
        // default value: change in text --> change in items shown
        this.canModifySearch = true;
        // searchVenues() {
        //   this.reset();
        //   if(!this.searchWord) {
        //     return;
        //   }
        //   Tab1Page.venues = Tab1Page.venues.filter((item) => {
        //    // var booleanNameSearch = <BOOLEAN EXPRESSION > -1 >
        //    // var booleanDescriptionSearch = <Boolean expression > -1>
        //    // return booleanNameSearch || booleanDescriptionSearch
        //     return item.name.toLowerCase().indexOf(this.searchWord.toLowerCase())>-1;
        //   });
        // }
        // reset() {
        //   Tab1Page.venues = [];
        //   firebase.database().ref('tempVenueInfo/').on('value', function(snapshot) {
        //     snapshot.forEach(function(cShot) {
        //       var k = cShot.key;
        //       firebase.database().ref(cShot.ref.parent.toString().substring(cShot.ref.parent.toString().lastIndexOf('/'))).child(k).on('value', function(items) {
        //         let x = items.val();
        //         Tab1Page.venues.push(new tempVenue(x.address, x.descripton, x.endDate,x.startDate,
        //                                            x.endHourAM,x.startHourPM,x.name,x.phoneNumber,x.uid,x.ticketInfo,x.purchaserIDs));
        //       });
        //     });
        //   });
        // }
        this.search = function () {
            console.log("DEBUG: in search()");
            _this.resetChanges();
            if (!_this.isClearing) {
                // we are not clearing completely,
                // then we can just filter stuff out
                _this.menus = _this.menus.filter(function (item) {
                    return item.name.toLowerCase().indexOf(_this.searchKey.toLowerCase()) > -1;
                });
            }
            else {
                // we are clearing and now done
                _this.isClearing = false; // reset this
            }
        };
        this.resetChanges = function () {
            _this.menus = _this.menus_all;
        };
        this.clear = function () {
            _this.isClearing = true; // means we are clearing this
            _this.menus = _this.menus_all;
        };
        Tab1Page_1.storageRef = firebase__WEBPACK_IMPORTED_MODULE_4__["storage"]().ref();
        this.events.subscribe('updatedData', function (time) {
            // invoke the ionViewWillEnter function
            _this.ionViewWillEnter();
        });
    }
    Tab1Page_1 = Tab1Page;
    Tab1Page.prototype.ngOnInit = function () {
    };
    Tab1Page.prototype.getDateString = function (stringifiedDateObject) {
        var extractedDateObject = new Date(stringifiedDateObject);
        return extractedDateObject.toLocaleDateString('en-US');
    };
    Tab1Page.prototype.getVenues = function () {
        return this.menus;
    };
    Tab1Page.prototype.ionViewWillEnter = function () {
        // initialize the data by default
        console.log("DEBUG entering ionViewWIllEnter. Tab1Page.venues = []");
        Tab1Page_1.venues = [];
        firebase__WEBPACK_IMPORTED_MODULE_4__["database"]().ref('tempVenueInfo/').on('value', function (snapshot) {
            snapshot.forEach(function (cShot) {
                var k = cShot.key;
                firebase__WEBPACK_IMPORTED_MODULE_4__["database"]().ref(cShot.ref.parent.toString().substring(cShot.ref.parent.toString().lastIndexOf('/'))).child(k).on('value', function (items) {
                    var x = items.val();
                    Tab1Page_1.venues.push(new tempVenue(x.address, x.descripton, x.endDate, x.startDate, x.endHourAM, x.startHourPM, x.name, x.phoneNumber, x.uid, x.ticketInfo, x.purchaserIDs, x.imgUrl));
                    console.log("DEBUG: the extracted data is: " + JSON.stringify(x.phoneNumber));
                });
            });
            // imagesrc array = [] - get downloadurls linked to photographs of the given object key
            //for each venue to display... iterate over all, extract object key (which is linked to photo name), and add to array
            // in the getVenues() function, return not an object, but a tuple or object [<THE ACTUAL OBJECT>, index in array]
            // [{object: , index },]
            // Tab1Page.venues.push( { object: new tempvenue(...), index: i <given position in array>})
            // in html file
            // let item of getVenues() 
            //
            //  ion-labels itme.object.address, kjlkjalks
            // <ion-img [src] = getSrcUrl(item.index) --> the passed in index will allow you to extract string from array
        });
        // we loaded the array completely up to this point.
        this.menus = Tab1Page_1.venues;
        this.menus_all = Tab1Page_1.venues;
        // this.searchWord = "";
        console.log("DEBUG: the Tab1Page.venues array is: " + JSON.stringify(Tab1Page_1.venues));
    };
    Tab1Page.prototype.ionViewDidEnter = function () {
        console.log("DEBUG: ENTERING TAB1 - the patron is: " + JSON.stringify(_globals__WEBPACK_IMPORTED_MODULE_2__["Globals"].CURRENT_PATRON_OBJ));
        console.log("DEBUG: ENTERING TAB1 - the patron's purchased tickets are: " + JSON.stringify(_globals__WEBPACK_IMPORTED_MODULE_2__["Globals"].CURRENT_PATRON_OBJ.firstName));
        console.log("the patron object's purchasedTickets array will eventually have the format for each contained object: \
                \n\t(1) uid of venue @ which I purchased at \
                \n\t(2) number of tickets purchased \
                \n\t(3) price per ticket  \
                \n\t(4) starting hour per ticket");
        this.CurrentPatron = JSON.stringify(_globals__WEBPACK_IMPORTED_MODULE_2__["Globals"].CURRENT_PATRON_OBJ);
        console.log("this is current patron name:  " + this.CurrentPatron);
    };
    Tab1Page.prototype.tempVenueDetail = function (x) {
        this.router.navigate(['/temp-venue-detail', { selectedVenue: JSON.stringify(x) }]);
    };
    Tab1Page.prototype.getImageSrc = function (venue) {
        // the item key is mapped to a .JPG photo
        console.log("We are here");
    };
    Tab1Page.prototype.logout = function () {
        var self = this;
        var fireBaseUser = firebase__WEBPACK_IMPORTED_MODULE_4__["auth"]().currentUser;
        console.log(fireBaseUser.uid + " userid");
        firebase__WEBPACK_IMPORTED_MODULE_4__["auth"]().signOut().then(function () {
            console.log("logout succeed");
            self.router.navigate(["/homepage"]);
            this.globals.ResetUserType();
            // Sign-out successful.
        }).catch(function (error) {
            // An error happened.
        });
    };
    var Tab1Page_1;
    Tab1Page.menuUrls = {};
    Tab1Page = Tab1Page_1 = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-tab1',
            template: __webpack_require__(/*! ./tab1.page.html */ "./src/app/tab1/tab1.page.html"),
            styles: [__webpack_require__(/*! ./tab1.page.scss */ "./src/app/tab1/tab1.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_globals__WEBPACK_IMPORTED_MODULE_2__["Globals"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["Events"]])
    ], Tab1Page);
    return Tab1Page;
}());

var tempVenue = /** @class */ (function () {
    function tempVenue(iaddress, idescription, iendDate, istartDate, iendHourAM, istartHourPM, iname, iphoneNumber, iuid, iticketInfo, ipurchaserIDs, iimgUrl) {
        this.address = iaddress;
        this.descripton = idescription;
        this.endDate = iendDate;
        this.startDate = istartDate;
        this.endHourAM = iendHourAM;
        this.startHourPM = istartHourPM;
        this.name = iname;
        this.phoneNumber = iphoneNumber;
        this.uid = iuid;
        this.ticketInfo = iticketInfo;
        this.purchaserIDs = ipurchaserIDs;
        this.imgUrl = iimgUrl;
    }
    return tempVenue;
}());



/***/ })

}]);
//# sourceMappingURL=tab1-tab1-module.js.map