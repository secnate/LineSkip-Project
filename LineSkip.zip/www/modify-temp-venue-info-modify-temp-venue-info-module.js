(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["modify-temp-venue-info-modify-temp-venue-info-module"],{

/***/ "./src/app/modify-temp-venue-info/modify-temp-venue-info.module.ts":
/*!*************************************************************************!*\
  !*** ./src/app/modify-temp-venue-info/modify-temp-venue-info.module.ts ***!
  \*************************************************************************/
/*! exports provided: ModifyTempVenueInfoPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModifyTempVenueInfoPageModule", function() { return ModifyTempVenueInfoPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _modify_temp_venue_info_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./modify-temp-venue-info.page */ "./src/app/modify-temp-venue-info/modify-temp-venue-info.page.ts");







var routes = [
    {
        path: '',
        component: _modify_temp_venue_info_page__WEBPACK_IMPORTED_MODULE_6__["ModifyTempVenueInfoPage"]
    }
];
var ModifyTempVenueInfoPageModule = /** @class */ (function () {
    function ModifyTempVenueInfoPageModule() {
    }
    ModifyTempVenueInfoPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_modify_temp_venue_info_page__WEBPACK_IMPORTED_MODULE_6__["ModifyTempVenueInfoPage"]]
        })
    ], ModifyTempVenueInfoPageModule);
    return ModifyTempVenueInfoPageModule;
}());



/***/ }),

/***/ "./src/app/modify-temp-venue-info/modify-temp-venue-info.page.html":
/*!*************************************************************************!*\
  !*** ./src/app/modify-temp-venue-info/modify-temp-venue-info.page.html ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar class=\"toolbar_header\">\n    <ion-title></ion-title>\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"goBack()\" class=\"backButton\">\n          Cancel\n        </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n    <form [formGroup]=\"update_temp_venue_form\" \n          (submit)=\"update(update_temp_venue_form.value)\">\n  \n      <ion-item>\n        <ion-label class=\"updateInfoLabel\">\n           Update Information\n        </ion-label>\n      </ion-item>\n  \n      <ion-item>\n        <ion-label color=\"black\" position=\"floating\">\n          Name\n        </ion-label>\n        <ion-icon slot=\"start\" name=\"person-add\"></ion-icon>\n        <ion-input type=\"text\" formControlName=\"name\" required>\n        </ion-input>\n      </ion-item>\n  \n      <ion-item>\n          <ion-label color=\"black\" position=\"floating\">\n            Address\n          </ion-label>\n          <ion-icon slot=\"start\" name=\"home\"></ion-icon>\n          <ion-input type=\"text\" formControlName=\"address\" required>\n          </ion-input>\n        </ion-item>\n  \n        <ion-item>\n            <ion-label color=\"black\" position=\"floating\">\n              Description\n            </ion-label>\n            <ion-icon slot=\"start\" name=\"reorder\"></ion-icon>\n            <ion-input type=\"text\" formControlName=\"venueDescription\" required>\n            </ion-input>\n          </ion-item>\n  \n      <ion-item>\n        <ion-label color=\"black\" position=\"floating\">\n          Phone Number\n        </ion-label>\n        <ion-icon slot=\"start\" name=\"call\"></ion-icon>\n        <ion-input type=\"number\" formControlName=\"phoneNumber\" required>\n        </ion-input>\n      </ion-item>\n\n      <ion-button class=\"submitbutton\" expand=\"block\" type=\"submit\"\n                (click)=\"update(update_temp_venue_form.value)\"\n                [disabled]=\"!update_temp_venue_form.valid\">\n        Update\n      </ion-button>\n\n    </form>\n  \n  </ion-content>\n"

/***/ }),

/***/ "./src/app/modify-temp-venue-info/modify-temp-venue-info.page.scss":
/*!*************************************************************************!*\
  !*** ./src/app/modify-temp-venue-info/modify-temp-venue-info.page.scss ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar_header, ion-header, ion-content {\n  --background: black;\n  color: white; }\n\n.backButton {\n  color: white; }\n\n.submitbutton {\n  margin-top: 10px;\n  --background: darkgrey; }\n\n.updateInfoLabel {\n  text-align: center;\n  font-style: bold;\n  font-size: 18pt;\n  font-family: \"Arial Rounded MT Bold\"; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbW9kaWZ5LXRlbXAtdmVudWUtaW5mby9FOlxcVXNlcnNcXFNhZGVnaGlUYWJhc1xcRGVza3RvcFxcTGluZVNraXAvc3JjXFxhcHBcXG1vZGlmeS10ZW1wLXZlbnVlLWluZm9cXG1vZGlmeS10ZW1wLXZlbnVlLWluZm8ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksWUFBWSxFQUFBOztBQUdoQjtFQUNJLGdCQUFnQjtFQUNoQixzQkFBYSxFQUFBOztBQUdqQjtFQUNJLGtCQUFrQjtFQUNsQixnQkFBZ0I7RUFDaEIsZUFBZTtFQUNmLG9DQUFvQyxFQUFBIiwiZmlsZSI6InNyYy9hcHAvbW9kaWZ5LXRlbXAtdmVudWUtaW5mby9tb2RpZnktdGVtcC12ZW51ZS1pbmZvLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50b29sYmFyX2hlYWRlciwgaW9uLWhlYWRlciwgaW9uLWNvbnRlbnQge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiBibGFjaztcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufVxyXG5cclxuLmJhY2tCdXR0b24ge1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG4uc3VibWl0YnV0dG9uIHtcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICAtLWJhY2tncm91bmQ6IGRhcmtncmV5O1xyXG59XHJcblxyXG4udXBkYXRlSW5mb0xhYmVsIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtc3R5bGU6IGJvbGQ7XHJcbiAgICBmb250LXNpemU6IDE4cHQ7IFxyXG4gICAgZm9udC1mYW1pbHk6IFwiQXJpYWwgUm91bmRlZCBNVCBCb2xkXCI7XHJcbiB9Il19 */"

/***/ }),

/***/ "./src/app/modify-temp-venue-info/modify-temp-venue-info.page.ts":
/*!***********************************************************************!*\
  !*** ./src/app/modify-temp-venue-info/modify-temp-venue-info.page.ts ***!
  \***********************************************************************/
/*! exports provided: ModifyTempVenueInfoPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModifyTempVenueInfoPage", function() { return ModifyTempVenueInfoPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../globals */ "./src/globals.ts");







var ModifyTempVenueInfoPage = /** @class */ (function () {
    function ModifyTempVenueInfoPage(router, formBuilder, events) {
        this.router = router;
        this.formBuilder = formBuilder;
        this.events = events;
        this.tempVenueRef = firebase__WEBPACK_IMPORTED_MODULE_5__["database"]().ref('tempVenueInfo/');
    }
    ModifyTempVenueInfoPage.prototype.ngOnInit = function () {
        // read out the data from firebase
        var currentTempID = firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser.uid;
        var self = this;
        var extractedOBJ;
        this.tempVenueRef.orderByChild("uid").equalTo(currentTempID).limitToFirst(1).once("value", function (data) {
            // we extract the current temporary venue's information just once                  
            var data_keys = Object.keys(data.val());
            extractedOBJ = data.val()[data_keys[0]];
            // update the global variable due to firebase 
            // updating the extracted data due to it being modified
            // and we are using it to display the data
            _globals__WEBPACK_IMPORTED_MODULE_6__["Globals"].CURRENT_TEMP_VENUE_OBJ = extractedOBJ;
        });
        // initialize the form
        self.update_temp_venue_form = this.formBuilder.group({
            name: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"](extractedOBJ.name, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required),
            address: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"](extractedOBJ.address, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required),
            venueDescription: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"](extractedOBJ.descripton, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required),
            phoneNumber: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"](extractedOBJ.phoneNumber, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required)
        });
    };
    ModifyTempVenueInfoPage.prototype.goBack = function () {
        this.router.navigate(['/edit-temp-venue-info']);
    };
    ModifyTempVenueInfoPage.prototype.update = function (updated_temp_venue_values) {
        console.log("DEBUG: clicked update!");
        console.log("DEBUG: The updated_temp_venue_values is: " +
            JSON.stringify(updated_temp_venue_values));
        var currentTempID = firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser.uid;
        this.tempVenueRef.orderByChild("uid").equalTo(currentTempID).limitToFirst(1).once("value", function (data) {
            // we extract the current temporary venue's information just once                  
            var data_keys = Object.keys(data.val());
            var extractedOBJ = data.val()[data_keys[0]];
            console.log("DEBUG: the extracted object is: " + JSON.stringify(extractedOBJ));
            // update the global variable due to firebase 
            // updating the extracted data due to it being modified
            // and we are using it to display the data
            _globals__WEBPACK_IMPORTED_MODULE_6__["Globals"].CURRENT_TEMP_VENUE_OBJ = extractedOBJ;
            // we now update the extracted object with 
            // the updated values from the form
            extractedOBJ.name = updated_temp_venue_values.name;
            extractedOBJ.address = updated_temp_venue_values.address;
            extractedOBJ.descripton = updated_temp_venue_values.venueDescription;
            extractedOBJ.phoneNumber = updated_temp_venue_values.phoneNumber;
            // now we save the chagnges
            var extractedID = data_keys[0];
            console.log("DEBUG: the extractedID is: " + extractedID);
            // now we find the id
            // and use it to update the object
            var newInfo = firebase__WEBPACK_IMPORTED_MODULE_5__["database"]().ref('tempVenueInfo/' + extractedID).update(extractedOBJ);
        });
        this.events.publish('updatedBasicTempInfo', Date.now());
        this.router.navigate(["/edit-temp-venue-info"]);
    };
    ModifyTempVenueInfoPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-modify-temp-venue-info',
            template: __webpack_require__(/*! ./modify-temp-venue-info.page.html */ "./src/app/modify-temp-venue-info/modify-temp-venue-info.page.html"),
            styles: [__webpack_require__(/*! ./modify-temp-venue-info.page.scss */ "./src/app/modify-temp-venue-info/modify-temp-venue-info.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Events"]])
    ], ModifyTempVenueInfoPage);
    return ModifyTempVenueInfoPage;
}());



/***/ })

}]);
//# sourceMappingURL=modify-temp-venue-info-modify-temp-venue-info-module.js.map