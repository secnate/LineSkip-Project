(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tempvenuecredentialregister-tempvenuecredentialregister-module"],{

/***/ "./src/app/tempvenuecredentialregister/tempvenuecredentialregister.module.ts":
/*!***********************************************************************************!*\
  !*** ./src/app/tempvenuecredentialregister/tempvenuecredentialregister.module.ts ***!
  \***********************************************************************************/
/*! exports provided: TempvenuecredentialregisterPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TempvenuecredentialregisterPageModule", function() { return TempvenuecredentialregisterPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _tempvenuecredentialregister_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tempvenuecredentialregister.page */ "./src/app/tempvenuecredentialregister/tempvenuecredentialregister.page.ts");







var routes = [
    {
        path: '',
        component: _tempvenuecredentialregister_page__WEBPACK_IMPORTED_MODULE_6__["TempvenuecredentialregisterPage"]
    }
];
var TempvenuecredentialregisterPageModule = /** @class */ (function () {
    function TempvenuecredentialregisterPageModule() {
    }
    TempvenuecredentialregisterPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_tempvenuecredentialregister_page__WEBPACK_IMPORTED_MODULE_6__["TempvenuecredentialregisterPage"]]
        })
    ], TempvenuecredentialregisterPageModule);
    return TempvenuecredentialregisterPageModule;
}());



/***/ }),

/***/ "./src/app/tempvenuecredentialregister/tempvenuecredentialregister.page.html":
/*!***********************************************************************************!*\
  !*** ./src/app/tempvenuecredentialregister/tempvenuecredentialregister.page.html ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar class=\"toolbar_header\">\n      <ion-title></ion-title>\n      <ion-buttons slot=\"start\">\n          <ion-button (click)=\"cancel()\"\n            class=\"cancelbutton\">\n            Cancel\n          </ion-button>\n      </ion-buttons>\n    </ion-toolbar>\n  </ion-header>\n\n<ion-content padding>\n\n  <!-- email and password -->\n  <form [formGroup]=\"new_temp_venue_form\" \n        (submit)=\"createTempVenue(new_temp_venue_form.value)\">\n\n    <ion-item>\n      <ion-label color=\"black\" position=\"floating\">\n        Email\n      </ion-label>\n      <ion-icon slot=\"start\" name=\"mail\"></ion-icon>\n      <ion-input type=\"email\" formControlName=\"email\" required></ion-input>\n    </ion-item>\n\n    <ion-item>\n      <ion-label color=\"black\" position=\"floating\">\n        Password\n      </ion-label>\n      <ion-icon slot=\"start\" name=\"key\"></ion-icon>\n      <ion-input type=\"password\" formControlName=\"password\" required></ion-input>\n    </ion-item>\n\n    <ion-button class=\"submit-btn\" expand=\"block\" \n              type=\"submit\" [disabled]=\"!new_temp_venue_form.valid\">\n      Next\n    </ion-button>\n    \n  </form>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/tempvenuecredentialregister/tempvenuecredentialregister.page.scss":
/*!***********************************************************************************!*\
  !*** ./src/app/tempvenuecredentialregister/tempvenuecredentialregister.page.scss ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar_header {\n  --background: black;\n  color: white; }\n\nion-content {\n  --background: black;\n  color: white;\n  width: 100%;\n  margin-left: 0px;\n  margin-right: 0px;\n  margin-top: 0px;\n  margin-bottom: 0px; }\n\n.cancelbutton {\n  --background: transparent;\n  color: white; }\n\n.submit-btn {\n  --background: darkgrey;\n  color: white; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGVtcHZlbnVlY3JlZGVudGlhbHJlZ2lzdGVyL0U6XFxVc2Vyc1xcU2FkZWdoaVRhYmFzXFxEZXNrdG9wXFxMaW5lU2tpcC9zcmNcXGFwcFxcdGVtcHZlbnVlY3JlZGVudGlhbHJlZ2lzdGVyXFx0ZW1wdmVudWVjcmVkZW50aWFscmVnaXN0ZXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksbUJBQWE7RUFDYixZQUFZO0VBQ1osV0FBVztFQUNYLGdCQUFnQjtFQUNoQixpQkFBaUI7RUFDakIsZUFBZTtFQUNmLGtCQUFrQixFQUFBOztBQUd0QjtFQUNJLHlCQUFhO0VBQ2IsWUFBWSxFQUFBOztBQUdoQjtFQUNJLHNCQUFhO0VBQ2IsWUFBWSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvdGVtcHZlbnVlY3JlZGVudGlhbHJlZ2lzdGVyL3RlbXB2ZW51ZWNyZWRlbnRpYWxyZWdpc3Rlci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudG9vbGJhcl9oZWFkZXIge1xuICAgIC0tYmFja2dyb3VuZDogYmxhY2s7XG4gICAgY29sb3I6IHdoaXRlO1xufVxuXG5pb24tY29udGVudCB7XG4gICAgLS1iYWNrZ3JvdW5kOiBibGFjaztcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgbWFyZ2luLWxlZnQ6IDBweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDBweDtcbiAgICBtYXJnaW4tdG9wOiAwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMHB4O1xufVxuXG4uY2FuY2VsYnV0dG9uIHtcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAgIGNvbG9yOiB3aGl0ZTtcbn1cblxuLnN1Ym1pdC1idG4ge1xuICAgIC0tYmFja2dyb3VuZDogZGFya2dyZXk7XG4gICAgY29sb3I6IHdoaXRlO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/tempvenuecredentialregister/tempvenuecredentialregister.page.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/tempvenuecredentialregister/tempvenuecredentialregister.page.ts ***!
  \*********************************************************************************/
/*! exports provided: TempvenuecredentialregisterPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TempvenuecredentialregisterPage", function() { return TempvenuecredentialregisterPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals */ "./src/globals.ts");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_5__);






var TempvenuecredentialregisterPage = /** @class */ (function () {
    function TempvenuecredentialregisterPage(router, route, globals, formBuilder) {
        this.router = router;
        this.route = route;
        this.globals = globals;
        this.formBuilder = formBuilder;
    }
    TempvenuecredentialregisterPage.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.subscribe(function (param) {
            _this.prepreparedItems = param;
            console.log("DEBUG: the parameter received is: " + JSON.stringify(_this.prepreparedItems));
        });
        this.new_temp_venue_form = this.formBuilder.group({
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required),
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required)
        });
    };
    TempvenuecredentialregisterPage.prototype.cancel = function () {
        this.router.navigate(['/signupvenue']);
    };
    TempvenuecredentialregisterPage.prototype.createTempVenue = function (value) {
        // We now register the account into firebase 
        // and upload all the data up to the database
        var email = value.email;
        var password = value.password;
        var self = this;
        // we register the new user
        // and save all his information to firebase
        var successful = true;
        console.log("DEBUG: we are going to create a user with this information");
        firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().createUserWithEmailAndPassword(email, password).catch(function (error) {
            // Handle Errors here.
            console.log(error);
            var errorCode = error.code;
            var errorMessage = error.message;
            console.log(error.message);
            if (errorCode.length > 0) {
                alert('Failed to Sign Up.\n' + errorMessage);
                successful = false;
            }
            else {
                console.log("signup ok");
                successful = true;
            }
            // ...
        }).then(function (user) {
            if (successful) {
                console.log("DEBUG: registering new tempVenueCredentials.");
                console.log("DEBUG: want to save " + self.prepreparedItems.ticketInfo);
                console.log("DEBUG - string representation is \'" +
                    JSON.stringify(self.prepreparedItems.ticketInfo + "\'"));
                var userID = firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser.uid;
                var newVenueInfo = {
                    address: self.prepreparedItems.address,
                    endDate: self.prepreparedItems.endDate,
                    startDate: self.prepreparedItems.startDate,
                    // this is AM time - 12 to 2 AM
                    endHourAM: (new Date(self.prepreparedItems.endDate)).getHours(),
                    // this is PM time
                    startHourPM: (new Date(self.prepreparedItems.startDate)).getHours(),
                    name: self.prepreparedItems.name,
                    phoneNumber: self.prepreparedItems.phoneNumber,
                    uid: userID,
                    descripton: self.prepreparedItems.venueDescription,
                    // Now we add in the collection of hourly ticket info
                    // in stringified format. The formatting of the objects
                    // stored inside it is defined on the previous page
                    ticketInfo: self.prepreparedItems.ticketInfo,
                    // Now we add in a collection of puchaserID
                    // which is an stringified array
                    // containing their hourly purchasers' information
                    // The objects stored inside this stringified array will have
                    // the following information:
                    // (1) uid of the purchaser
                    // (2) the hour for which they purchased tickets
                    purchaserIDs: JSON.stringify([]),
                    imgUrl: "" // empty object
                };
                console.log("Creating new temp venue. \
                       \nThe objects stored inside the stringified purchaserIDs array contain the following \
                       \n\t(1) uid of the purchaser \
                       \n\t(2) the hour for which they purchased tickets");
                var newVenueFirebase = firebase__WEBPACK_IMPORTED_MODULE_5__["database"]().ref('tempVenueInfo/').push();
                newVenueFirebase.set(JSON.parse(JSON.stringify(newVenueInfo)));
                console.log("DEBUG: ticketInfo is: " +
                    JSON.stringify(self.prepreparedItems.ticketInfo));
                // we also add the user type to the user types
                var newPatronType = firebase__WEBPACK_IMPORTED_MODULE_5__["database"]().ref('userType/').push();
                newPatronType.set({
                    uid: userID, type: _globals__WEBPACK_IMPORTED_MODULE_4__["USER_TYPES"].TEMPORARY_VENUE
                });
                self.globals.SET_CURRENT_LOGGED_IN_TYPE(_globals__WEBPACK_IMPORTED_MODULE_4__["USER_TYPES"].TEMPORARY_VENUE);
                _globals__WEBPACK_IMPORTED_MODULE_4__["Globals"].CURRENT_TEMP_VENUE_OBJ = newVenueInfo; // so we set the currently logged in information
                // Move to the core of the app itself after logging in
                // by default we go to tab3 - the first tab 
                // for the venue side of the app
                self.router.navigate(['/take-temp-photo',
                    { id: userID }]);
            }
            else {
                alert('Failed to Sign Up due to Invalid Credentials.\nPlease Try Again.');
            }
        });
    };
    TempvenuecredentialregisterPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-tempvenuecredentialregister',
            template: __webpack_require__(/*! ./tempvenuecredentialregister.page.html */ "./src/app/tempvenuecredentialregister/tempvenuecredentialregister.page.html"),
            styles: [__webpack_require__(/*! ./tempvenuecredentialregister.page.scss */ "./src/app/tempvenuecredentialregister/tempvenuecredentialregister.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
            _globals__WEBPACK_IMPORTED_MODULE_4__["Globals"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]])
    ], TempvenuecredentialregisterPage);
    return TempvenuecredentialregisterPage;
}());



/***/ })

}]);
//# sourceMappingURL=tempvenuecredentialregister-tempvenuecredentialregister-module.js.map