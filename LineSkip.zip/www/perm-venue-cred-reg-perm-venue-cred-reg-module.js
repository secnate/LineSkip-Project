(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["perm-venue-cred-reg-perm-venue-cred-reg-module"],{

/***/ "./src/app/perm-venue-cred-reg/perm-venue-cred-reg.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/perm-venue-cred-reg/perm-venue-cred-reg.module.ts ***!
  \*******************************************************************/
/*! exports provided: PermVenueCredRegPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PermVenueCredRegPageModule", function() { return PermVenueCredRegPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _perm_venue_cred_reg_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./perm-venue-cred-reg.page */ "./src/app/perm-venue-cred-reg/perm-venue-cred-reg.page.ts");







var routes = [
    {
        path: '',
        component: _perm_venue_cred_reg_page__WEBPACK_IMPORTED_MODULE_6__["PermVenueCredRegPage"]
    }
];
var PermVenueCredRegPageModule = /** @class */ (function () {
    function PermVenueCredRegPageModule() {
    }
    PermVenueCredRegPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_perm_venue_cred_reg_page__WEBPACK_IMPORTED_MODULE_6__["PermVenueCredRegPage"]]
        })
    ], PermVenueCredRegPageModule);
    return PermVenueCredRegPageModule;
}());



/***/ }),

/***/ "./src/app/perm-venue-cred-reg/perm-venue-cred-reg.page.html":
/*!*******************************************************************!*\
  !*** ./src/app/perm-venue-cred-reg/perm-venue-cred-reg.page.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar class=\"toolbar_header\">\n    <ion-title></ion-title>\n    <ion-buttons slot=\"start\">\n        <ion-button (click)=\"cancel()\"\n          style=\"color: white;\">\n          Cancel\n        </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n\n<!-- email and password -->\n<form [formGroup]=\"new_perm_venue_form\" \n      (submit)=\"createPermVenue(new_perm_venue_form.value)\">\n\n  <ion-item>\n    <ion-label color=\"black\" position=\"floating\">\n      Email\n    </ion-label>\n    <ion-icon slot=\"start\" name=\"mail\"></ion-icon>\n    <ion-input type=\"email\" formControlName=\"email\" required></ion-input>\n  </ion-item>\n\n  <ion-item>\n    <ion-label color=\"black\" position=\"floating\">\n      Password\n    </ion-label>\n    <ion-icon slot=\"start\" name=\"key\"></ion-icon>\n    <ion-input type=\"password\" formControlName=\"password\" required></ion-input>\n  </ion-item>\n\n  <ion-button class=\"submit-btn\" expand=\"block\" \n            type=\"submit\" [disabled]=\"!new_perm_venue_form.valid\">\n    Register\n  </ion-button>\n  \n</form>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/perm-venue-cred-reg/perm-venue-cred-reg.page.scss":
/*!*******************************************************************!*\
  !*** ./src/app/perm-venue-cred-reg/perm-venue-cred-reg.page.scss ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar_header {\n  --background: black;\n  color: white; }\n\nion-content {\n  --background: white;\n  width: 100%;\n  margin-left: 0px;\n  margin-right: 0px;\n  margin-top: 0px;\n  margin-bottom: 0px; }\n\nion-button {\n  --background: darkgrey;\n  color: white; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGVybS12ZW51ZS1jcmVkLXJlZy9FOlxcVXNlcnNcXFNhZGVnaGlUYWJhc1xcRGVza3RvcFxcTGluZVNraXAvc3JjXFxhcHBcXHBlcm0tdmVudWUtY3JlZC1yZWdcXHBlcm0tdmVudWUtY3JlZC1yZWcucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksbUJBQWE7RUFDYixXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLGlCQUFpQjtFQUNqQixlQUFlO0VBQ2Ysa0JBQWtCLEVBQUE7O0FBR3RCO0VBQ0ksc0JBQWE7RUFDYixZQUFZLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wZXJtLXZlbnVlLWNyZWQtcmVnL3Blcm0tdmVudWUtY3JlZC1yZWcucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRvb2xiYXJfaGVhZGVyIHtcclxuICAgIC0tYmFja2dyb3VuZDogYmxhY2s7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbn1cclxuXHJcbmlvbi1jb250ZW50IHtcclxuICAgIC0tYmFja2dyb3VuZDogd2hpdGU7IFxyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBtYXJnaW4tbGVmdDogMHB4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAwcHg7XHJcbiAgICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbn1cclxuXHJcbmlvbi1idXR0b24ge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiBkYXJrZ3JleTtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/perm-venue-cred-reg/perm-venue-cred-reg.page.ts":
/*!*****************************************************************!*\
  !*** ./src/app/perm-venue-cred-reg/perm-venue-cred-reg.page.ts ***!
  \*****************************************************************/
/*! exports provided: PermVenueCredRegPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PermVenueCredRegPage", function() { return PermVenueCredRegPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals */ "./src/globals.ts");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_5__);






var PermVenueCredRegPage = /** @class */ (function () {
    function PermVenueCredRegPage(router, route, globals, formBuilder) {
        this.router = router;
        this.route = route;
        this.globals = globals;
        this.formBuilder = formBuilder;
    }
    PermVenueCredRegPage.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.subscribe(function (param) {
            _this.prepreparedItems = param;
            console.log("DEBUG: the parameter received is: " + JSON.stringify(_this.prepreparedItems));
        });
        this.new_perm_venue_form = this.formBuilder.group({
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required),
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required)
        });
    };
    PermVenueCredRegPage.prototype.cancel = function () {
        this.router.navigate(['/signupvenue']);
    };
    PermVenueCredRegPage.prototype.createpermVenue = function (value) {
        // We now register the account into firebase 
        // and upload all the data up to the database
        var email = value.email;
        var password = value.password;
        var self = this;
        // we register the new user
        // and save all his information to firebase
        var successful = true;
        console.log("DEBUG: we are going to create a user with this information");
        firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().createUserWithEmailAndPassword(email, password).catch(function (error) {
            // Handle Errors here.
            console.log(error);
            var errorCode = error.code;
            var errorMessage = error.message;
            console.log(error.message);
            if (errorCode.length > 0) {
                alert('Failed to Sign Up.\n' + errorMessage);
                successful = false;
            }
            else {
                console.log("signup ok");
                successful = true;
            }
            // ...
        }).then(function (user) {
            if (successful) {
                var userID = firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser.uid;
                var newVenue = firebase__WEBPACK_IMPORTED_MODULE_5__["database"]().ref('permVenueInfo/').push();
                newVenue.set({
                    address: self.prepreparedItems.address,
                    endDate: self.prepreparedItems.endDate,
                    startDate: self.prepreparedItems.startDate,
                    // this is AM time - 12 to 2 AM
                    endHourAM: (new Date(self.prepreparedItems.endDate)).getHours(),
                    // this is PM time
                    startHourPM: (new Date(self.prepreparedItems.startDate)).getHours(),
                    name: self.prepreparedItems.name,
                    phoneNumber: self.prepreparedItems.phoneNumber,
                    uid: userID,
                    descripton: self.prepreparedItems.venueDescription,
                    // Now we add in the collection of hourly ticket info
                    ticketInfo: self.prepreparedItems.ticketInfo
                });
                console.log("DEBUG: ticketInfo is: " +
                    JSON.stringify(self.prepreparedItems.ticketInfo));
                // we also add the user type to the user types
                var newPatronType = firebase__WEBPACK_IMPORTED_MODULE_5__["database"]().ref('userType/').push();
                newPatronType.set({
                    uid: userID, type: _globals__WEBPACK_IMPORTED_MODULE_4__["USER_TYPES"].PERMANENT_VENUE
                });
                self.globals.SET_CURRENT_LOGGED_IN_TYPE(_globals__WEBPACK_IMPORTED_MODULE_4__["USER_TYPES"].PERMANENT_VENUE);
                // Move to the core of the app itself after logging in
                // by default we go to tab3 - the first tab 
                // for the venue side of the app
                self.router.navigate([_globals__WEBPACK_IMPORTED_MODULE_4__["PERM_VENUES_DEFAULT_TAB"]]);
            }
            else {
                alert('Failed to Sign Up due to Invalid Credentials.\nPlease Try Again.');
            }
        });
    };
    PermVenueCredRegPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-perm-venue-cred-reg',
            template: __webpack_require__(/*! ./perm-venue-cred-reg.page.html */ "./src/app/perm-venue-cred-reg/perm-venue-cred-reg.page.html"),
            styles: [__webpack_require__(/*! ./perm-venue-cred-reg.page.scss */ "./src/app/perm-venue-cred-reg/perm-venue-cred-reg.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
            _globals__WEBPACK_IMPORTED_MODULE_4__["Globals"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]])
    ], PermVenueCredRegPage);
    return PermVenueCredRegPage;
}());



/***/ })

}]);
//# sourceMappingURL=perm-venue-cred-reg-perm-venue-cred-reg-module.js.map