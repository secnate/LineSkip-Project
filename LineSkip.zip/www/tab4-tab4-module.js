(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab4-tab4-module"],{

/***/ "./src/app/tab4/tab4.module.ts":
/*!*************************************!*\
  !*** ./src/app/tab4/tab4.module.ts ***!
  \*************************************/
/*! exports provided: Tab4PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab4PageModule", function() { return Tab4PageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _tab4_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tab4.page */ "./src/app/tab4/tab4.page.ts");







var routes = [
    {
        path: '',
        component: _tab4_page__WEBPACK_IMPORTED_MODULE_6__["Tab4Page"]
    }
];
var Tab4PageModule = /** @class */ (function () {
    function Tab4PageModule() {
    }
    Tab4PageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_tab4_page__WEBPACK_IMPORTED_MODULE_6__["Tab4Page"]]
        })
    ], Tab4PageModule);
    return Tab4PageModule;
}());



/***/ }),

/***/ "./src/app/tab4/tab4.page.html":
/*!*************************************!*\
  !*** ./src/app/tab4/tab4.page.html ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<ion-header>\n  <ion-toolbar>\n    <ion-title></ion-title>\n      \n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"logout()\">\n        <ion-icon slot=\"icon-only\" \n                  class=\"exitButton\"\n                  name=\"exit\"></ion-icon>\n        </ion-button>\n      </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-item>\n    <ion-label class=\"eventInfoLabel\">\n      Hourly Information\n    </ion-label>\n  </ion-item>\n\n  <ion-item *ngFor = \"let hour of hourSlotArray\" \n            (click)=\"selectedSlot(hour)\" text-wrap>\n    <ion-label class=\"timeslotlabel\">\n      {{ getStringHour( hour ) }} \n      to {{ getStringHour( hour + 1) }}\n    </ion-label>\n  </ion-item>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/tab4/tab4.page.scss":
/*!*************************************!*\
  !*** ./src/app/tab4/tab4.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-header, ion-toolbar, ion-content {\n  --background: black;\n  color: white; }\n\n.exitButton {\n  color: white; }\n\n.eventInfoLabel {\n  width: 100%;\n  font-style: bold;\n  font-size: 20pt;\n  text-align: center;\n  font-family: \"Arial Rounded MT Bold\"; }\n\n.timeslotlabel {\n  width: 100%;\n  font-size: 18pt;\n  text-align: left;\n  font-family: \"Helvetica Header\"; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGFiNC9FOlxcVXNlcnNcXFNhZGVnaGlUYWJhc1xcRGVza3RvcFxcTGluZVNraXAvc3JjXFxhcHBcXHRhYjRcXHRhYjQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBR2Q7RUFDRSxZQUFZLEVBQUE7O0FBR2Q7RUFDQSxXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLGVBQWU7RUFDZixrQkFBa0I7RUFDbEIsb0NBQW9DLEVBQUE7O0FBR3BDO0VBQ0EsV0FBVztFQUNYLGVBQWU7RUFDZixnQkFBZ0I7RUFDaEIsK0JBQStCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC90YWI0L3RhYjQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciwgaW9uLXRvb2xiYXIsaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IGJsYWNrO1xuICBjb2xvcjogd2hpdGU7XG59XG5cbi5leGl0QnV0dG9uIHtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG4uZXZlbnRJbmZvTGFiZWwge1xud2lkdGg6IDEwMCU7XG5mb250LXN0eWxlOiBib2xkO1xuZm9udC1zaXplOiAyMHB0O1xudGV4dC1hbGlnbjogY2VudGVyO1xuZm9udC1mYW1pbHk6IFwiQXJpYWwgUm91bmRlZCBNVCBCb2xkXCI7XG59XG5cbi50aW1lc2xvdGxhYmVsIHtcbndpZHRoOiAxMDAlO1xuZm9udC1zaXplOiAxOHB0O1xudGV4dC1hbGlnbjogbGVmdDtcbmZvbnQtZmFtaWx5OiBcIkhlbHZldGljYSBIZWFkZXJcIjtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/tab4/tab4.page.ts":
/*!***********************************!*\
  !*** ./src/app/tab4/tab4.page.ts ***!
  \***********************************/
/*! exports provided: Tab4Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab4Page", function() { return Tab4Page; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals */ "./src/globals.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _paramservice_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../paramservice.service */ "./src/app/paramservice.service.ts");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_5__);






var Tab4Page = /** @class */ (function () {
    function Tab4Page(globals, router, parameterService) {
        this.globals = globals;
        this.router = router;
        this.parameterService = parameterService;
    }
    Tab4Page.prototype.ngOnInit = function () {
        console.log("In tab4, initializing the hour slot array");
        this.initializeHourSlotArray();
    };
    Tab4Page.prototype.ionViewDidEnter = function () {
        // update its value
        console.log("DEBUG: ENTERING TAB4 - the temporary venue is: " +
            JSON.stringify(_globals__WEBPACK_IMPORTED_MODULE_2__["Globals"].CURRENT_TEMP_VENUE_OBJ));
        console.log("\tAND DEBUG: The ticket info is: " +
            JSON.stringify(_globals__WEBPACK_IMPORTED_MODULE_2__["Globals"].CURRENT_TEMP_VENUE_OBJ.ticketInfo));
        console.log("Logging into a temp venue. \
                \nThe objects stored inside the stringified purchaserIDs array contain the following \
                \n\t(1) uid of the purchaser \
                \n\t(2) the hour for which they purchased tickets");
        console.log("DEBUG: the type of the Globals.CURRENT_TEMP_VENUE_OBJ is: " + typeof (_globals__WEBPACK_IMPORTED_MODULE_2__["Globals"].CURRENT_TEMP_VENUE_OBJ));
    };
    Tab4Page.prototype.initializeHourSlotArray = function () {
        // we initialize the ticket array by parsing the string representation of the 
        // array and converting all items into objects
        var _this = this;
        // split up the objects
        var stringToParse = _globals__WEBPACK_IMPORTED_MODULE_2__["Globals"].CURRENT_TEMP_VENUE_OBJ.ticketInfo;
        if (stringToParse.charAt(0) == '[') {
            // remove the '['
            stringToParse = stringToParse.substr(1);
        }
        if (stringToParse[stringToParse.length - 1] == ']') {
            stringToParse = stringToParse.slice(0, -1);
        }
        var splitUpObjects = stringToParse.split("},");
        var i = 0;
        for (i = 0; i < splitUpObjects.length; i++) {
            if (splitUpObjects[i].slice(-1) != '}') {
                // it does not have the end curly bracked 
                // to close off object in string representation which was chopped off. 
                // correct this mistake
                splitUpObjects[i] = splitUpObjects[i] + "}";
            }
        }
        // now we parse things and save it to the ticket array
        this.hourSlotArray = [];
        splitUpObjects.forEach(function (element) {
            _this.hourSlotArray.push(JSON.parse(element).startHour);
        });
    };
    Tab4Page.prototype.selectedSlot = function (startHour) {
        console.log("DEBUG: clicked slot and selectedSlot");
        this.parameterService.setHourInfo(startHour);
        this.router.navigate(["/tempvenuetimeslotinfo"]);
    };
    Tab4Page.prototype.getStringHour = function (hourNum) {
        // returns "<# hour> <AM/PM>" string
        // for a given inputted number of the starting hour
        if (hourNum < 12) {
            return String(hourNum) + " PM";
        }
        else if (hourNum == 12) {
            return String(hourNum) + " AM";
        }
        else {
            // this is all AM times after 12 AM
            return String(hourNum - 12) + " AM";
        }
    };
    Tab4Page.prototype.logout = function () {
        var self = this;
        var fireBaseUser = firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser;
        console.log(fireBaseUser.uid + " userid");
        firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().signOut().then(function () {
            console.log("logout succeed");
            self.router.navigate(["/homepage"]);
            this.inTab4 = false;
            this.globals.ResetUserType();
            // Sign-out successful.
        }).catch(function (error) {
            // An error happened.
        });
    };
    Tab4Page = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-tab4',
            template: __webpack_require__(/*! ./tab4.page.html */ "./src/app/tab4/tab4.page.html"),
            styles: [__webpack_require__(/*! ./tab4.page.scss */ "./src/app/tab4/tab4.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_globals__WEBPACK_IMPORTED_MODULE_2__["Globals"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _paramservice_service__WEBPACK_IMPORTED_MODULE_4__["ParamserviceService"]])
    ], Tab4Page);
    return Tab4Page;
}());



/***/ })

}]);
//# sourceMappingURL=tab4-tab4-module.js.map