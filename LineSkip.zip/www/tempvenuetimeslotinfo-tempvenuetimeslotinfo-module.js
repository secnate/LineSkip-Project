(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tempvenuetimeslotinfo-tempvenuetimeslotinfo-module"],{

/***/ "./src/app/tempvenuetimeslotinfo/tempvenuetimeslotinfo.module.ts":
/*!***********************************************************************!*\
  !*** ./src/app/tempvenuetimeslotinfo/tempvenuetimeslotinfo.module.ts ***!
  \***********************************************************************/
/*! exports provided: TempvenuetimeslotinfoPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TempvenuetimeslotinfoPageModule", function() { return TempvenuetimeslotinfoPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _tempvenuetimeslotinfo_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tempvenuetimeslotinfo.page */ "./src/app/tempvenuetimeslotinfo/tempvenuetimeslotinfo.page.ts");







var routes = [
    {
        path: '',
        component: _tempvenuetimeslotinfo_page__WEBPACK_IMPORTED_MODULE_6__["TempvenuetimeslotinfoPage"]
    }
];
var TempvenuetimeslotinfoPageModule = /** @class */ (function () {
    function TempvenuetimeslotinfoPageModule() {
    }
    TempvenuetimeslotinfoPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_tempvenuetimeslotinfo_page__WEBPACK_IMPORTED_MODULE_6__["TempvenuetimeslotinfoPage"]]
        })
    ], TempvenuetimeslotinfoPageModule);
    return TempvenuetimeslotinfoPageModule;
}());



/***/ }),

/***/ "./src/app/tempvenuetimeslotinfo/tempvenuetimeslotinfo.page.html":
/*!***********************************************************************!*\
  !*** ./src/app/tempvenuetimeslotinfo/tempvenuetimeslotinfo.page.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar class=\"toolbar_header\">\n    <ion-title></ion-title>\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"goBack()\"\n        class=\"backButton\">\n        <ion-icon slot=\"icon-only\" name=\"arrow-back\">\n        </ion-icon>\n          Back\n        </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-item>\n    <ion-label class=\"rangeLabel\">\n      {{ getTimeRange() }}\n    </ion-label>\n  </ion-item>\n\n  <ion-item>\n    <ion-label>\n      Information:\n    </ion-label>\n  </ion-item>\n\n  <ion-item>\n    <ion-label>\n        {{ currentHourObject.numTickets }} Tickets Unsold\n    </ion-label>\n  </ion-item>\n\n  <ion-item>\n    <ion-label>\n      {{ currentHourObject.numSold }} Tickets Sold\n    </ion-label>\n  </ion-item>\n\n  <ion-item *ngIf=\"'currentHourObject.numSold'==0\"\n            (click)=\"seeWhoBought()\">\n    <ion-label>\n      See Who Bought\n    </ion-label>\n  </ion-item>\n\n  <ion-item (click)=\"toggleNewTicketInput()\">\n    <ion-label>\n      Add Tickets For Sale\n    </ion-label>\n\n    <!-- Dropdown arrow -->\n    <ion-icon name=\"arrow-dropdown\" \n              *ngIf=\"!showingNewTicketsInput\">\n    </ion-icon>\n\n    <!-- Drop up arrow -->\n    <ion-icon name=\"arrow-dropup\" *ngIf=\"showingNewTicketsInput\">\n    </ion-icon>\n    \n  </ion-item>\n\n  <ion-item *ngIf=\"showingNewTicketsInput\">\n\n      <ion-input [(ngModel)]=\"numberTicketsToAdd\" \n                 (ionChange)=\"makeSureNonNull()\" min=\"0\"\n                 type=\"number\" text-center>\n      </ion-input>\n\n      <ion-button class=\"addButton\" (click)=\"addNewTickets()\">\n        <b>Add</b>\n      </ion-button>\n  </ion-item>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/tempvenuetimeslotinfo/tempvenuetimeslotinfo.page.scss":
/*!***********************************************************************!*\
  !*** ./src/app/tempvenuetimeslotinfo/tempvenuetimeslotinfo.page.scss ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".toolbar_header {\n  --background: black;\n  color: white; }\n\n.backButton {\n  color: white; }\n\n.rangeLabel {\n  color: black;\n  width: 100%;\n  font-style: bold;\n  font-size: 20pt;\n  text-align: center;\n  font-family: \"Arial Rounded MT Bold\"; }\n\n.addButton {\n  font-size: 15pt;\n  font-style: bold;\n  margin-top: -5px;\n  margin-bottom: -5px;\n  height: 90%;\n  --background: black;\n  color: white; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGVtcHZlbnVldGltZXNsb3RpbmZvL0U6XFxVc2Vyc1xcU2FkZWdoaVRhYmFzXFxEZXNrdG9wXFxMaW5lU2tpcC9zcmNcXGFwcFxcdGVtcHZlbnVldGltZXNsb3RpbmZvXFx0ZW1wdmVudWV0aW1lc2xvdGluZm8ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQWE7RUFDYixZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksWUFBWSxFQUFBOztBQUdoQjtFQUNJLFlBQVk7RUFDWixXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLGVBQWU7RUFDZixrQkFBa0I7RUFDbEIsb0NBQW9DLEVBQUE7O0FBR3hDO0VBQ0ksZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixnQkFBZ0I7RUFDaEIsbUJBQW1CO0VBQ25CLFdBQVc7RUFDWCxtQkFBYTtFQUNiLFlBQVksRUFBQSIsImZpbGUiOiJzcmMvYXBwL3RlbXB2ZW51ZXRpbWVzbG90aW5mby90ZW1wdmVudWV0aW1lc2xvdGluZm8ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRvb2xiYXJfaGVhZGVyIHtcbiAgICAtLWJhY2tncm91bmQ6IGJsYWNrO1xuICAgIGNvbG9yOiB3aGl0ZTtcbn1cblxuLmJhY2tCdXR0b24ge1xuICAgIGNvbG9yOiB3aGl0ZTtcbn1cblxuLnJhbmdlTGFiZWwge1xuICAgIGNvbG9yOiBibGFjaztcbiAgICB3aWR0aDogMTAwJTtcbiAgICBmb250LXN0eWxlOiBib2xkO1xuICAgIGZvbnQtc2l6ZTogMjBwdDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1mYW1pbHk6IFwiQXJpYWwgUm91bmRlZCBNVCBCb2xkXCI7XG59XG5cbi5hZGRCdXR0b24ge1xuICAgIGZvbnQtc2l6ZTogMTVwdDtcbiAgICBmb250LXN0eWxlOiBib2xkO1xuICAgIG1hcmdpbi10b3A6IC01cHg7XG4gICAgbWFyZ2luLWJvdHRvbTogLTVweDtcbiAgICBoZWlnaHQ6IDkwJTtcbiAgICAtLWJhY2tncm91bmQ6IGJsYWNrO1xuICAgIGNvbG9yOiB3aGl0ZTtcbn1cbiJdfQ== */"

/***/ }),

/***/ "./src/app/tempvenuetimeslotinfo/tempvenuetimeslotinfo.page.ts":
/*!*********************************************************************!*\
  !*** ./src/app/tempvenuetimeslotinfo/tempvenuetimeslotinfo.page.ts ***!
  \*********************************************************************/
/*! exports provided: TempvenuetimeslotinfoPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TempvenuetimeslotinfoPage", function() { return TempvenuetimeslotinfoPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals */ "./src/globals.ts");
/* harmony import */ var _paramservice_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../paramservice.service */ "./src/app/paramservice.service.ts");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_5__);






var TempvenuetimeslotinfoPage = /** @class */ (function () {
    function TempvenuetimeslotinfoPage(router, paramService, globals) {
        this.router = router;
        this.paramService = paramService;
        this.globals = globals;
        this.tempVenueRef = firebase__WEBPACK_IMPORTED_MODULE_5__["database"]().ref('tempVenueInfo/');
        // boolean controls the apprarance of the inputting of a form
        // in which the temporary can input the number of tickets to be added
        // to a given hour sloot
        this.showingNewTicketsInput = false;
        this.numberTicketsToAdd = 0;
    }
    TempvenuetimeslotinfoPage.prototype.ngOnInit = function () {
        this.startHour = this.paramService.getHourInfo();
        // We define the default values of the number of tickets we can add
        this.showingNewTicketsInput = false;
        this.numberTicketsToAdd = 0;
        // Now initialize the hourly information
        // we initialize the hourly information
        this.currentTempID = firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]().currentUser.uid;
        var self = this;
        // each time the object gets updated, we update the time slot information
        this.tempVenueRef.orderByChild("uid").equalTo(this.currentTempID).limitToFirst(1).on("value", function (data) {
            var data_keys = Object.keys(data.val());
            var extractedOBJ = data.val()[data_keys[0]];
            // update the global variable due to firebase 
            // updating the extracted data due to it being modified
            _globals__WEBPACK_IMPORTED_MODULE_3__["Globals"].CURRENT_TEMP_VENUE_OBJ = extractedOBJ;
            // continue with updating the page's data
            self.updateHourlyInformation(extractedOBJ);
        });
    };
    TempvenuetimeslotinfoPage.prototype.goBack = function () {
        // the default tab is the one containing the hourly
        // information and the one that called this page
        this.router.navigate([_globals__WEBPACK_IMPORTED_MODULE_3__["TEMP_VENUES_DEFAULT_TAB"]]);
    };
    TempvenuetimeslotinfoPage.prototype.updateHourlyInformation = function (extractedOBJ) {
        var _this = this;
        // first we remove the '[' and ']' from the string's start and end if there is one
        var stringToParse = extractedOBJ.ticketInfo;
        if (stringToParse.charAt(0) == '[') {
            // remove the '['
            stringToParse = stringToParse.substr(1);
        }
        if (stringToParse[stringToParse.length - 1] == ']') {
            stringToParse = stringToParse.slice(0, -1);
        }
        // split up the objects
        this.splitUpObjects = stringToParse.split("},");
        var i = 0;
        for (i = 0; i < this.splitUpObjects.length; i++) {
            if (this.splitUpObjects[i].slice(-1) != '}') {
                // it does not have the end curly bracked 
                // to close off object in string representation which was chopped off. 
                // correct this mistake
                this.splitUpObjects[i] = this.splitUpObjects[i] + "}";
            }
        }
        // now we parse things and save it to the ticket array
        var i = 0;
        this.splitUpObjects.forEach(function (element) {
            var extractedElement = JSON.parse(element);
            if (extractedElement.startHour == _this.startHour) {
                _this.currentHourObject = extractedElement;
                // save the index of the current hour object in 
                // the split up objects array for further use
                _this.indexCurrentHourObject = i;
            }
            // we continue on to the next item
            i = i + 1;
        });
    };
    TempvenuetimeslotinfoPage.prototype.getTimeRange = function () {
        return this.getStringHour(this.startHour) +
            " to " +
            this.getStringHour(Number(this.startHour) + 1);
    };
    TempvenuetimeslotinfoPage.prototype.getStringHour = function (hour) {
        // returns "<# hour> <AM/PM>" string
        // for a given inputted number of the starting hour
        if (hour < 12) {
            return String(hour) + " PM";
        }
        else if (hour == 12) {
            return String(hour) + " AM";
        }
        else {
            // this is all AM times after 12 AM
            return String(hour - 12) + " AM";
        }
    };
    TempvenuetimeslotinfoPage.prototype.toggleNewTicketInput = function () {
        this.showingNewTicketsInput = !this.showingNewTicketsInput;
        if (this.showingNewTicketsInput) {
            // by default we are adding in zero tickets
            this.numberTicketsToAdd = 0;
        }
    };
    TempvenuetimeslotinfoPage.prototype.seeWhoBought = function () {
        console.log("CLICKED the \'see who bought\' button");
        console.log("TODO: implement the seeWhoBought() functio");
    };
    TempvenuetimeslotinfoPage.prototype.addNewTickets = function () {
        // we add new tickets that can be sold in the near future to patrons
        console.log("DEBUG: in addNewTickets() function");
        console.log("this.numberOfTicketsToAdd = " + this.numberTicketsToAdd);
        this.showingNewTicketsInput = false;
        // now we consider the cases
        if (this.numberTicketsToAdd == null) {
            // deal with null case
            alert("Invalid Input:\nYou did not enter a number of tickets to order.");
        }
        else if (this.numberTicketsToAdd < 0) {
            // dealing with negative case
            alert("Invalid Input:\nA number of tickets to order must be positive.");
        }
        else if (this.numberTicketsToAdd == 0) {
            return; // we just quit... everything is fine!
        }
        // otherwise, the number of tickets is greater than zero than 0
        // and is suitable for the updating of the app's data
        console.log("DEBUG: the index of the item we need to modify is: " + this.indexCurrentHourObject);
        console.log("DEBUG: the current object I want to modify is: " +
            JSON.stringify(this.currentHourObject));
        console.log("DEBUG: the array of split up objects is: " +
            JSON.stringify(this.splitUpObjects));
        // first, we modify the current hour object
        this.currentHourObject.numTickets += this.numberTicketsToAdd;
        // push the updated current hour object into the splitUpObjects array
        this.splitUpObjects[this.indexCurrentHourObject] =
            JSON.stringify(this.currentHourObject);
        console.log("\n\nDEBUG: the splitUpObjects array is now: " + JSON.stringify(this.splitUpObjects));
        var fullObjectsArray = [];
        var i = 0;
        for (i = 0; i < this.splitUpObjects.length; i++) {
            // convert from string to object
            fullObjectsArray.push(JSON.parse(this.splitUpObjects[i]));
        }
        // update the values stored in the globals
        _globals__WEBPACK_IMPORTED_MODULE_3__["Globals"].CURRENT_TEMP_VENUE_OBJ.ticketInfo = JSON.stringify(fullObjectsArray);
        // and then update into firebase 
        // first we find the object to update
        // and we do this only ONCE
        this.tempVenueRef.orderByChild("uid").equalTo(this.currentTempID).limitToFirst(1).once("value", function (data) {
            var data_keys = Object.keys(data.val());
            console.log("DEBUG: data_keys is: " + JSON.stringify(data_keys));
            var extractedID = data_keys[0];
            // now we find the id
            // and use it to update the object
            var newInfo = firebase__WEBPACK_IMPORTED_MODULE_5__["database"]().ref('tempVenueInfo/' + extractedID).update(_globals__WEBPACK_IMPORTED_MODULE_3__["Globals"].CURRENT_TEMP_VENUE_OBJ);
        });
        // after this, we have an alert that we ordered the new tickets
        alert("Added " + this.numberTicketsToAdd + " Tickets");
        this.router.navigate(["/tempvenuetimeslotinfo"]); // ensure we are on the same page
    };
    TempvenuetimeslotinfoPage.prototype.makeSureNonNull = function () {
        // we make sure that the number of tickets can always be 0
        if (this.numberTicketsToAdd == null) {
            this.numberTicketsToAdd = 0;
        }
    };
    TempvenuetimeslotinfoPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-tempvenuetimeslotinfo',
            template: __webpack_require__(/*! ./tempvenuetimeslotinfo.page.html */ "./src/app/tempvenuetimeslotinfo/tempvenuetimeslotinfo.page.html"),
            styles: [__webpack_require__(/*! ./tempvenuetimeslotinfo.page.scss */ "./src/app/tempvenuetimeslotinfo/tempvenuetimeslotinfo.page.scss")]
        })
        /*
          // this will be used for future referencing
          //this.currentTempID = firebase.auth().currentUser.uid;
          //let tempVenueRef = firebase.database().ref('tempVenueInfo/');
          //var self = this;
          tempVenueRef.orderByChild("uid").equalTo(this.currentTempID).limitToFirst(1).on("value", function(data) {
                // whenever the information regarding temporary venue changes,
                // we load the temporary venue data
                // we extract the object from firebase
                var data_keys = Object.keys(data.val());
                var extractedOBJ = data.val()[ data_keys[0] ];
      
                // update the global variable
                Globals.CURRENT_TEMP_VENUE_OBJ = extractedOBJ;
      
                // now we update the ticket array
                self.initializeTicketInfoArray();
                console.log("DEBUG: updated tempVENUEDATA");
          });*/
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _paramservice_service__WEBPACK_IMPORTED_MODULE_4__["ParamserviceService"],
            _globals__WEBPACK_IMPORTED_MODULE_3__["Globals"]])
    ], TempvenuetimeslotinfoPage);
    return TempvenuetimeslotinfoPage;
}());



/***/ })

}]);
//# sourceMappingURL=tempvenuetimeslotinfo-tempvenuetimeslotinfo-module.js.map