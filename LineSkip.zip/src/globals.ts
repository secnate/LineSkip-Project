// globals.ts
// Consists of all the stuff

import { Injectable } from '@angular/core';
import { Events } from '@ionic/angular';
import { SWITCH_COMPILE_NGMODULE__POST_R3__ } from '@angular/core/src/metadata/ng_module';

// This is an injectable class that can be injected into
// each and every page of the application to ensure that
// they all share the same global variables.

export enum USER_TYPES{ PATRON="PATRON", 
                        PERMANENT_VENUE="PERM_VENUE",
                        TEMPORARY_VENUE="TEMP_VENUE", 
                        NONE="NONE" }; // note the NONE means that no one has logged in yet

// These are the different venue types
export enum VENUE_TYPES{ PERMANENT="PERMANENT", TEMPORARY="TEMPORARY"};

// These are the strings of the starting tabs that must be opened 
// after logging in for each user type. For example, we don't want someone
// logging in as a venue to be redirected by default to tab1 (which is the patron side of the app)
// when opening the tabs view controller
//
// This will allow us to add more tabs with greater ease and update the code almost instantly
// because we can just modify one variable.
// So let's say I add a tab to the patron side of the app and want it to have three patrons...
// then I can just change the TEMP_VENUES_DEFAULT_TAB from being tab4 to tab5 for example.
export const PATRON_DEFAULT_TAB = "/tabs/tab1";
export const PERM_VENUES_DEFAULT_TAB = "/tabs/tab6"; 
export const TEMP_VENUES_DEFAULT_TAB = "/tabs/tab4";



@Injectable({
  providedIn: 'root'
})
export class Globals {

  // array of month names that can be indexed with
  // indices 0 to 11 inclusive
  public static MONTHS = ["January", "February","March",
                          "April","May","June","July",
                          "August","September","November",
                          "October","December"];

  // We now define the time slots for the events
  // As of right now the assumption is that the working day
  // for the venues is from 8:00 PM to 2:00 AM
  // And we are doing it hourly. So we have 8:00 to 9:00, 
  // 9:00 to 10:00, 10:00 to 11:00 and so forth and so forth.
  //
  // We enumerate the hours with the military 
  // time value for the STARTING HOUR.
  // Note the format:
  // <Beginning Hour>_TO_<Ending Hour>_
  //        <AM or PM depending on the ending hour>

  static readonly EIGHT_TO_NINE_PM : number = 20;
  static readonly NINE_TO_TEN_PM  = 21;
  static readonly TEN_TO_ELEVEN_PM = 22;
  static readonly ELEVEN_TO_TWELVE_AM = 23; // note it actually ends in 12:00 AM
  static readonly TWELVE_TO_ONE_AM = 24;
  static readonly ONE_TO_TWO_AM = 1;

  // This is an array of all the time slots during which
  // tickets can be scheduled.
  static readonly TIME_SLOTS_ARRAY = [
    Globals.EIGHT_TO_NINE_PM, Globals.NINE_TO_TEN_PM, 
    Globals.TEN_TO_ELEVEN_PM, Globals.ELEVEN_TO_TWELVE_AM, 
    Globals.TWELVE_TO_ONE_AM, Globals.ONE_TO_TWO_AM
  ]

  // This global variable indicates whether the person 
  // who is logged in as a patron or as a venue
  private static CURRENT_LOGGED_IN_TYPE : USER_TYPES = USER_TYPES.NONE;

  // This represents the current entities currently logged in - all by default are null
  // This allows us to initialize everything i one place instead of having to go back
  // and forth among different pages with stupid parameter passing
  public static CURRENT_TEMP_VENUE_OBJ = null; 
  public static CURRENT_PERM_VENUE_OBJ = null;
  public static CURRENT_PATRON_OBJ = null;

  constructor(public events : Events) {
  }

  GET_CURRENT_LOGGED_IN_TYPE() {
    return Globals.CURRENT_LOGGED_IN_TYPE;
  }


  SET_CURRENT_LOGGED_IN_TYPE(newType: USER_TYPES) {
    Globals.CURRENT_LOGGED_IN_TYPE = newType;
    console.log("DEBUG: we are invoking changedLogInType event");
    this.events.publish('changedLogInType', Date.now());
  }

  ResetUserType() {
    // we are logging out and want to ensure that everything here is working smoothly
    Globals.CURRENT_LOGGED_IN_TYPE = USER_TYPES.NONE;
    Globals.CURRENT_TEMP_VENUE_OBJ = null; 
    Globals.CURRENT_PERM_VENUE_OBJ = null;
    Globals.CURRENT_PATRON_OBJ = null;

    this.events.publish('changedLogInType', Date.now());
  }

  CURRENT_USER_TYPE() {
    return this.GET_CURRENT_LOGGED_IN_TYPE();
  }

}
