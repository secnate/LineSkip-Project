import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewPermVenueDtpickerPage } from './new-perm-venue-dtpicker.page';

describe('NewPermVenueDtpickerPage', () => {
  let component: NewPermVenueDtpickerPage;
  let fixture: ComponentFixture<NewPermVenueDtpickerPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewPermVenueDtpickerPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewPermVenueDtpickerPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
