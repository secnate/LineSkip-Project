// 
//  THIS IS THE NATHAN SIDE OF THE APP.
//  ONLY NATHAN SHOULD MODIFY THIS FILE
//

import { Component } from '@angular/core';
import { Globals } from "../../globals";
import { Router } from '@angular/router';
import * as firebase from 'firebase';


@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {

  constructor( public globals : Globals, 
               private router : Router ) {
  }

  logout(){
    var self=this;

    let fireBaseUser = firebase.auth().currentUser;
    console.log(fireBaseUser.uid +" userid")


    firebase.auth().signOut().then(function() {
      console.log("logout succeed");
      
      self.router.navigate(["/homepage"]);
      this.globals.ResetUserType();
      
        // Sign-out successful.
    }).catch(function(error) {
      // An error happened.
    });
  }

}
