import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  // note that the path: '' signifies that this is the default page for the app
  { path: 'homepage', loadChildren: './splashscreen/splashscreen.module#SplashscreenPageModule' },
  
  // pages involved in logging in/sign up 

  // splash screen
  { path: 'splashscreen', loadChildren: './splashscreen/splashscreen.module#SplashscreenPageModule' },

  // three splash screen options
  { path: 'login', loadChildren: './login/login.module#LoginPageModule' },
  { path: 'signuppatron', loadChildren: './signuppatron/signuppatron.module#SignuppatronPageModule' },
  { path: 'signupvenue', loadChildren: './signupvenue/signupvenue.module#SignupvenuePageModule' },
  
  // pages involved in signing up new patron
  { path: 'terms-and-conditions-page', loadChildren: './terms-and-conditions-page/terms-and-conditions-page.module#TermsAndConditionsPagePageModule' },
  
  // pages involved in registering new venue

  //  Pages involved in registering temporary venue
  //  In the order of progression from top to bottom of what we do
  { path: 'registertemporaryvenue', loadChildren: './registertemporaryvenue/registertemporaryvenue.module#RegistertemporaryvenuePageModule' },
  { path: 'newtempvenuedatetimepicker', loadChildren: './newtempvenuedatetimepicker/newtempvenuedatetimepicker.module#NewtempvenuedatetimepickerPageModule' },
  { path: 'tempvenuehourtickinfosetter', loadChildren: './tempvenuehourtickinfosetter/tempvenuehourtickinfosetter.module#TempvenuehourtickinfosetterPageModule' },
  { path: 'tempvenuecredentialregister', loadChildren: './tempvenuecredentialregister/tempvenuecredentialregister.module#TempvenuecredentialregisterPageModule' },
  { path: 'venue-terms-cond', loadChildren: './venue-terms-cond/venue-terms-cond.module#VenueTermsCondPageModule' },

  //  Pages involved in registering permanent venue
  { path: 'registerpermanentvenue', loadChildren: './registerpermanentvenue/registerpermanentvenue.module#RegisterpermanentvenuePageModule' },
  { path: 'new-perm-venue-dtpicker', loadChildren: './new-perm-venue-dtpicker/new-perm-venue-dtpicker.module#NewPermVenueDtpickerPageModule' },
  { path: 'perm-venue-hr-info-setter', loadChildren: './perm-venue-hr-info-setter/perm-venue-hr-info-setter.module#PermVenueHrInfoSetterPageModule' },
  { path: 'perm-venue-cred-reg', loadChildren: './perm-venue-cred-reg/perm-venue-cred-reg.module#PermVenueCredRegPageModule' },

  // This is the for the temproary venue side of the app
    //    used to allow people to add tickets to the app

    { path: 'tempvenuetimeslotinfo', loadChildren: './tempvenuetimeslotinfo/tempvenuetimeslotinfo.module#TempvenuetimeslotinfoPageModule' },

      //    used to display the temporary venue's information for editing
  { path: 'edit-temp-venue-info', loadChildren: './edit-temp-venue-info/edit-temp-venue-info.module#EditTempVenueInfoPageModule' },
  //    used to modify the temporary venue's non-ticket information and saving data to firebase
  { path: 'modify-temp-venue-info', loadChildren: './modify-temp-venue-info/modify-temp-venue-info.module#ModifyTempVenueInfoPageModule' },

  // this is the page that opens up all the tabs
  { path: '', loadChildren: "./tabs/tabs.module#TabsPageModule" },
  { path: 'temp-venue-detail', loadChildren: './temp-venue-detail/temp-venue-detail.module#TempVenueDetailPageModule' },
  { path: 'add-temp-venue-to-cart', loadChildren: './add-temp-venue-to-cart/add-temp-venue-to-cart.module#AddTempVenueToCartPageModule' },
  { path: 'tab8', loadChildren: './tab8/tab8.module#Tab8PageModule' },
  { path: 'modify-temp-venue-info', loadChildren: './modify-temp-venue-info/modify-temp-venue-info.module#ModifyTempVenueInfoPageModule' },
  { path: 'edit-temp-venue-info', loadChildren: './edit-temp-venue-info/edit-temp-venue-info.module#EditTempVenueInfoPageModule' },
  { path: 'take-temp-photo', loadChildren: './take-temp-photo/take-temp-photo.module#TakeTempPhotoPageModule' },
  { path: 'update-photo', loadChildren: './update-photo/update-photo.module#UpdatePhotoPageModule' }
  
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
