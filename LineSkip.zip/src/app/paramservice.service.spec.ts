import { TestBed } from '@angular/core/testing';

import { ParamserviceService } from './paramservice.service';

describe('ParamserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ParamserviceService = TestBed.get(ParamserviceService);
    expect(service).toBeTruthy();
  });
});
