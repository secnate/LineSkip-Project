import { Component } from '@angular/core';
import { Globals } from "../../globals";
import { Router, ActivatedRoute } from '@angular/router';
import { ParamserviceService } from '../paramservice.service';
import * as firebase from 'firebase';


@Component({
  selector: 'app-tab4',
  templateUrl: './tab4.page.html',
  styleUrls: ['./tab4.page.scss'],
})
export class Tab4Page {

  private hourSlotArray;
  private currentTempID;

  constructor(public globals : Globals, 
              private router : Router,
              private parameterService : ParamserviceService) {
  }


  ngOnInit() {
    console.log("In tab4, initializing the hour slot array");
    this.initializeHourSlotArray();
  }

  ionViewDidEnter() {
    // update its value
    console.log("DEBUG: ENTERING TAB4 - the temporary venue is: " + 
                JSON.stringify(Globals.CURRENT_TEMP_VENUE_OBJ) );
    console.log("\tAND DEBUG: The ticket info is: " + 
                JSON.stringify(Globals.CURRENT_TEMP_VENUE_OBJ.ticketInfo));
    console.log("Logging into a temp venue. \
                \nThe objects stored inside the stringified purchaserIDs array contain the following \
                \n\t(1) uid of the purchaser \
                \n\t(2) the hour for which they purchased tickets")
    console.log("DEBUG: the type of the Globals.CURRENT_TEMP_VENUE_OBJ is: " + typeof(Globals.CURRENT_TEMP_VENUE_OBJ));
  }

  initializeHourSlotArray() {
    // we initialize the ticket array by parsing the string representation of the 
    // array and converting all items into objects

    // split up the objects
    var stringToParse = Globals.CURRENT_TEMP_VENUE_OBJ.ticketInfo;

    if ( stringToParse.charAt(0) == '[' ) {
      // remove the '['
      stringToParse = stringToParse.substr(1);
    }

    if ( stringToParse[ stringToParse.length - 1 ] == ']') {
      stringToParse = stringToParse.slice(0, -1);
    }

    var splitUpObjects = stringToParse.split("},");
    
    var i = 0;
    for (i = 0; i < splitUpObjects.length; i++) {
      if (splitUpObjects[i].slice(-1) != '}') {
        // it does not have the end curly bracked 
        // to close off object in string representation which was chopped off. 
        // correct this mistake
        splitUpObjects[i] = splitUpObjects[i] + "}";
      }
    }

    // now we parse things and save it to the ticket array
    this.hourSlotArray = [];
    splitUpObjects.forEach(element => {
      this.hourSlotArray.push(JSON.parse(element).startHour);
    });
  }

  selectedSlot(startHour) {
    console.log("DEBUG: clicked slot and selectedSlot");
    this.parameterService.setHourInfo(startHour);
    this.router.navigate(["/tempvenuetimeslotinfo"]);

  }

  getStringHour(hourNum) {
    // returns "<# hour> <AM/PM>" string
    // for a given inputted number of the starting hour
    if ( hourNum < 12 ) {
      return String(hourNum) + " PM";
    }
    else if (hourNum == 12) {
      return String(hourNum) + " AM";
    }
    else {
      // this is all AM times after 12 AM
      return String(hourNum-12) + " AM";
    }
  }

  logout(){
    var self=this;
            
    let fireBaseUser = firebase.auth().currentUser;
    console.log(fireBaseUser.uid +" userid")
            
            
    firebase.auth().signOut().then(function() {
      console.log("logout succeed");
          
      self.router.navigate(["/homepage"]);
      this.inTab4 = false;
      this.globals.ResetUserType(); 
           
      // Sign-out successful.
    }).catch(function(error) {
      // An error happened.
    });
  }

}