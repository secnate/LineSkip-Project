import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Validators, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Globals, USER_TYPES, VENUE_TYPES, PERM_VENUES_DEFAULT_TAB } from "../../globals";
import * as firebase from 'firebase';

@Component({
  selector: 'app-registerpermanentvenue',
  templateUrl: './registerpermanentvenue.page.html',
  styleUrls: ['./registerpermanentvenue.page.scss'],
})
export class RegisterpermanentvenuePage implements OnInit {

  new_perm_venue_form : FormGroup;
  hasReadTermsAndConditions: boolean = false;

  constructor(private router: Router, 
              public globals : Globals,
              public formBuilder : FormBuilder) { }

  ngOnInit() {
    this.new_perm_venue_form = this.formBuilder.group({
      name: new FormControl('', Validators.required),
      address: new FormControl('', Validators.required),
      venueDescription : new FormControl('', Validators.required),
      phoneNumber: new FormControl('', Validators.required)
      // ,email: new FormControl('', Validators.required),
      // password: new FormControl('', Validators.required)
    });
    this.hasReadTermsAndConditions = false;

  }

  ionViewWillLeave() {
    this.ngOnInit();
    
  }

  goBack() {
    this.router.navigate(["/signupvenue"]);
  }

  // signup(new_perm_venue) {
  //   // We now register the permanent account into firebase 
  //   // and upload all of the data into to the database
  //   var name= new_perm_venue.name;
  //   var address = new_perm_venue.address;
  //   var venueDescription = new_perm_venue.venueDescription;
  //   var phoneNumber = new_perm_venue.phoneNumber;
  //   var email = new_perm_venue.email;
  //   var password = new_perm_venue.password;
  //   var self = this;

  //   // register the new permanent user into firebase

  //   var successful = true;
  //   console.log("debug: create new permanent user");
  //   firebase.auth().createUserWithEmailAndPassword(email, password).catch(
  //     function(error) {
  //       console.log(error);
  //       var errorCode = error.code;
  //       var errorMessage = error.message;

  //       if (errorCode.length > 0){
  //         alert('failed to signup.\n'+ errorMessage);
  //         successful = false;
  //       }
  //       else {
  //         console.log("signed up successfully")
  //         successful = true;
  //       }
  //       }).then(function(user){
  //         if (successful){
  //           var userID=firebase.auth().currentUser.uid;
  //           let newVenue = firebase.database().ref('permVenueInfo/').push();
  //           newVenue.set({
  //             'name':name,
  //             'address': address,
  //             'venueDescription': venueDescription,
  //             'phoneNumber': phoneNumber,
  //             'uid': userID
  //           });

  //           // add user type
  //           let newVenueType = firebase.database().ref('userType/').push();
  //           newVenueType.set({
  //             'uid':userID, 
  //             'type': USER_TYPES.PERMANENT_VENUE
  //           });
  //           self.globals.SET_CURRENT_LOGGED_IN_TYPE(USER_TYPES.PERMANENT_VENUE);

  //           // navigate to the first page of the venue
  //           // side of the app after loging in (tab3)
  //           self.router.navigate([VENUES_DEFAULT_TAB]);
  //         }
  //         else {
  //           alert ("failed to sign up due to incorrect credentials.\n Please try again.");
  //         };
  //           });
  //         };

  next(new_perm_venue) {
    // We move on to the next view controller 
    // to register information
    console.log("DEBUG: SIGNING UP " + JSON.stringify(new_perm_venue));
    this.router.navigate(["/new-perm-venue-dtpicker", new_perm_venue]);
  }

          toggleHasReadTermsAndConditions() {
            this.hasReadTermsAndConditions = !this.hasReadTermsAndConditions;
          }
        
          openTermsAndConditions() {
            var parmaeterOBJ = { returnURL : "/signupvenue"};
            this.router.navigate(['/venue-terms-cond', parmaeterOBJ]);
          }
      };
    
  


