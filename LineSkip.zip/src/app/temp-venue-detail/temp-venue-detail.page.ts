import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { tempVenue } from '../tab1/tab1.page';
// import { orders, order } from '../orders/orders.page';
import * as firebase from 'firebase';


@Component({
  selector: 'app-temp-venue-detail',
  templateUrl: './temp-venue-detail.page.html',
  styleUrls: ['./temp-venue-detail.page.scss'],
})
export class TempVenueDetailPage implements OnInit {
  public item: tempVenue;
  private hourSlotArray;

  constructor(private route: Router, private r: ActivatedRoute ) {
    this.r.params.subscribe(params => { this.item = JSON.parse(params['selectedVenue']); });
    
  }


  ngOnInit() {
    console.log("In tab4, initializing the hour slot array");
    this.initializeHourSlotArray();
  }

  ionViewDidEnter() {
    // update its value
    console.log("DEBUG: ENTERING temVenueDetailPage - the temporary venue is: " +
      JSON.stringify(this.item.name));
    console.log("\tAND DEBUG: The ticket info is: " +
      JSON.stringify(this.item.ticketInfo));
    console.log("Logging into a temp venue. \
                      \nThe objects stored inside the stringified purchaserIDs array contain the following \
                      \n\t(1) uid of the purchaser \
                      \n\t(2) the hour for which they purchased tickets")
  }

  initializeHourSlotArray() {
    // we initialize the ticket array by parsing the string representation of the 
    // array and converting all items into objects

    // split up the objects
    var extractedString = this.item.ticketInfo;  // string to process

    // if there is a '[' at the start of the string or end ']'
    if ( extractedString.charAt(0) == '[') {
      //remove the leading '['
      extractedString = extractedString.substr(1);
    }

    if (extractedString[extractedString.length - 1] == ']') {
      // remove the trailing ']'
      extractedString = extractedString.slice(0, -1);
    }

    var splitUpObjects = extractedString.split("},");

    var i = 0;
    for (i = 0; i < splitUpObjects.length; i++) {
      if (splitUpObjects[i].slice(-1) != '}') {
        // it does not have the end curly bracked 
        // to close off object in string representation which was chopped off. 
        // correct this mistake
        splitUpObjects[i] = splitUpObjects[i] + "}";
      }
    }

    // now we parse things and save it to the ticket array
    this.hourSlotArray = [];
    splitUpObjects.forEach(element => {
      this.hourSlotArray.push(JSON.parse(element).startHour);
    });
  }

  selectedSlot(startHour) {
    console.log("DEBUG: clicked slot and selectedSlot");
    this.route.navigate(['/add-temp-venue-to-cart', {selectedVenue: JSON.stringify(this.item), hrSlotArray: startHour}]);

    console.log("this is my item before sending="+this.item);
  }
  getDateString(stringifiedDateObject){
    var extractedDateObject =new Date(stringifiedDateObject);
    return extractedDateObject.toLocaleDateString('en-US');
  }
  getStringHour(hourNum) {
    // returns "<# hour> <AM/PM>" string
    // for a given inputted number of the starting hour
    if (hourNum < 12) {
      return String(hourNum) + " PM";
    }
    else if (hourNum == 12) {
      return String(hourNum) + " AM";
    }
    else {
      // this is all AM times after 12 AM
      return String(hourNum - 12) + " AM";
    }
  }
  goBack() {
    this.route.navigate(['/tabs/tab1']);
  }
}



  // ====================================
  // public item: tempVenue;
  //   quantity: number;
  //   public static Cart;
  //   constructor(private route: Router, private r: ActivatedRoute) {
  //     this.r.params.subscribe(params => {this.item = JSON.parse(params['selectedItem']);});
  //     this.quantity = 1;
  //   }

  //   ngOnInit() {
  //   }
  //   addToOrder() {
  //     var k = [];
  //     TempVenueDetailPage.Cart = new cart();
  //     firebase.database().ref('Cart/'+firebase.auth().currentUser.uid).on('value', function(snapshot) {
  //       snapshot.forEach(function(cShot) {
  //         k.push(cShot.key);

  //         firebase.database().ref('Cart/'+cShot.ref.parent.toString().substring(cShot.ref.parent.toString().lastIndexOf('/'))+'/'+k[k.length-1]).on('value', function(cSnap) {
  //           var m = cSnap.val();
  //           TempVenueDetailPage.Cart = JSON.parse(m);
  //         });
  //       });
  //     });
  //     for(var i:number=0; i<this.quantity; i++) {
  //       TempVenueDetailPage.Cart.currentOrder.items.push(this.item);
  //       TempVenueDetailPage.Cart.currentOrder.totalItems++;
  //       TempVenueDetailPage.Cart.currentOrder.totalPrice += this.item.ticketInfo; // *** price
  //       TempVenueDetailPage.Cart.orderList[TempVenueDetailPage.Cart.orderList.length-1] = TempVenueDetailPage.Cart.currentOrder;
  //     }
  //     var s = {};
  //     s['userOrder'] = JSON.stringify(TempVenueDetailPage.Cart);
  //     firebase.database().ref('Cart/'+firebase.auth().currentUser.uid).update(s);
  //     if(this.quantity > 1) {
  //       alert("These items has been added to your order.");
  //     } else if(this.quantity == 1) {
  //       alert("This item has been added to your order.");
  //     }
  //   }
  //   goBack() {
  //     this.route.navigate(['/tab1']);
  //   }