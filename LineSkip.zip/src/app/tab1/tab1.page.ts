// 
//  THIS IS THE NATHAN SIDE OF THE APP.
//  ONLY NATHAN SHOULD MODIFY THIS FILE
//
import { Component, OnInit } from '@angular/core';
import { Globals, USER_TYPES, PATRON_DEFAULT_TAB, TEMP_VENUES_DEFAULT_TAB, PERM_VENUES_DEFAULT_TAB } from "../../globals";
import { Router } from '@angular/router';
import * as firebase from 'firebase';
import { Validators, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { VenueTermsCondPage } from '../venue-terms-cond/venue-terms-cond.page';
import { Events } from '@ionic/angular';
// import { Storage } from '@ionic/storage'

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})

export class Tab1Page implements OnInit {

  ///////////////////////////////////////////////////////////////////////////
  // Searchbar information
  isClearing = false;
  searchKey = "";
  menus = [];       // will be used to indicate the filtered items
  menus_all = [];
  needToReset : boolean = false;
  static menuUrls = {};
  static storageRef;

  // default value: change in text --> change in items shown
  canModifySearch = true; 
  /////////////////////////////////////////////////////////////////////////////

  CurrentPatron;

  // public searchWord: string;
  // venues:Array<any>=[{address:"",endDate:"",startDate:"",endHourAM:0,startHourPM:0, name:"", phoneNumber:"",uid:"",descripton:"",ticketInfo:"",purchaserIDs:"" }];
  public static venues: tempVenue[];

  constructor( public globals : Globals,
               private router : Router,
               public events : Events ) {
                Tab1Page.storageRef = firebase.storage().ref();
    this.events.subscribe('updatedData', (time) => {

      // invoke the ionViewWillEnter function
      this.ionViewWillEnter();
    });
  } 
  
  ngOnInit() {
  }
  getDateString(stringifiedDateObject){
    var extractedDateObject =new Date(stringifiedDateObject);
    return extractedDateObject.toLocaleDateString('en-US');
  }
  getVenues() {
    return this.menus;
  }

  ionViewWillEnter() {
    // initialize the data by default
    console.log("DEBUG entering ionViewWIllEnter. Tab1Page.venues = []");
    Tab1Page.venues=[];

    firebase.database().ref('tempVenueInfo/').on('value', function(snapshot){
          snapshot.forEach(function(cShot){
          var k= cShot.key;
          firebase.database().ref(cShot.ref.parent.toString().substring(
              cShot.ref.parent.toString().lastIndexOf('/'))).child(k).on('value',function(items){
              let x=items.val();
              Tab1Page.venues.push(new tempVenue(x.address, x.descripton, x.endDate,x.startDate,x.endHourAM,x.startHourPM,x.name,x.phoneNumber,x.uid,x.ticketInfo,x.purchaserIDs, x.imgUrl) );
                console.log("DEBUG: the extracted data is: " + JSON.stringify(x.phoneNumber) );
          });
        });

        // imagesrc array = [] - get downloadurls linked to photographs of the given object key
        //for each venue to display... iterate over all, extract object key (which is linked to photo name), and add to array

        // in the getVenues() function, return not an object, but a tuple or object [<THE ACTUAL OBJECT>, index in array]
        // [{object: , index },]



        // Tab1Page.venues.push( { object: new tempvenue(...), index: i <given position in array>})

        // in html file
        // let item of getVenues() 
        //
        //  ion-labels itme.object.address, kjlkjalks
        // <ion-img [src] = getSrcUrl(item.index) --> the passed in index will allow you to extract string from array

    });

    // we loaded the array completely up to this point.
    this.menus = Tab1Page.venues;
    this.menus_all = Tab1Page.venues;

    // this.searchWord = "";

    console.log("DEBUG: the Tab1Page.venues array is: " + JSON.stringify(Tab1Page.venues) );
  }
  
  ionViewDidEnter() {
    console.log("DEBUG: ENTERING TAB1 - the patron is: " + JSON.stringify(Globals.CURRENT_PATRON_OBJ) );
    console.log("DEBUG: ENTERING TAB1 - the patron's purchased tickets are: " + JSON.stringify(Globals.CURRENT_PATRON_OBJ.firstName) );
    console.log("the patron object's purchasedTickets array will eventually have the format for each contained object: \
                \n\t(1) uid of venue @ which I purchased at \
                \n\t(2) number of tickets purchased \
                \n\t(3) price per ticket  \
                \n\t(4) starting hour per ticket");
  this.CurrentPatron=JSON.stringify(Globals.CURRENT_PATRON_OBJ);
  console.log("this is current patron name:  "+ this.CurrentPatron);
  }

  tempVenueDetail(x: tempVenue) {
    this.router.navigate(['/temp-venue-detail', {selectedVenue: JSON.stringify(x)}]);
  }



  
  getImageSrc(venue) {
    // the item key is mapped to a .JPG photo
    console.log("We are here");




  }

  

  // searchVenues() {
  //   this.reset();
  //   if(!this.searchWord) {
  //     return;
  //   }
  //   Tab1Page.venues = Tab1Page.venues.filter((item) => {
  //    // var booleanNameSearch = <BOOLEAN EXPRESSION > -1 >
  //    // var booleanDescriptionSearch = <Boolean expression > -1>
  //    // return booleanNameSearch || booleanDescriptionSearch
  //     return item.name.toLowerCase().indexOf(this.searchWord.toLowerCase())>-1;
  //   });
  // }

  // reset() {
  //   Tab1Page.venues = [];
  //   firebase.database().ref('tempVenueInfo/').on('value', function(snapshot) {
  //     snapshot.forEach(function(cShot) {
  //       var k = cShot.key;
  //       firebase.database().ref(cShot.ref.parent.toString().substring(cShot.ref.parent.toString().lastIndexOf('/'))).child(k).on('value', function(items) {
  //         let x = items.val();
  //         Tab1Page.venues.push(new tempVenue(x.address, x.descripton, x.endDate,x.startDate,
  //                                            x.endHourAM,x.startHourPM,x.name,x.phoneNumber,x.uid,x.ticketInfo,x.purchaserIDs));
  //       });
  //     });
  //   });
  // }

  protected search = () => {
    console.log("DEBUG: in search()");
    this.resetChanges();

    if (!this.isClearing) {
      // we are not clearing completely,
      // then we can just filter stuff out
      this.menus = this.menus.filter( (item) => {
        return item.name.toLowerCase().indexOf(
                  this.searchKey.toLowerCase()) > -1;
      });
    } else {
      // we are clearing and now done
      this.isClearing = false;  // reset this
    }
  }

  protected resetChanges = () => {
    this.menus = this.menus_all;
  }

  protected clear = () => {
    this.isClearing = true;        // means we are clearing this
    this.menus = this.menus_all;
  }


  logout(){
    var self=this;

    let fireBaseUser = firebase.auth().currentUser;
    console.log(fireBaseUser.uid +" userid")


    firebase.auth().signOut().then(function() {
      console.log("logout succeed");
      
      self.router.navigate(["/homepage"]);
      this.globals.ResetUserType();
  
        // Sign-out successful.
    }).catch(function(error) {
      // An error happened.
    });
  }

}


export class tempVenue {
  public address:string;
  public descripton:string;
  public endDate:string;
  public startDate:string;
  public endHourAM:number;
  public startHourPM:number;
  public name:string;
  public phoneNumber:string;
  public uid:string;
  public ticketInfo:string;
  public purchaserIDs:string;
  public imgUrl:string;
   constructor ( iaddress:string,
                 idescription:string,
                 iendDate:string,
                 istartDate:string,
                 iendHourAM:number,
                 istartHourPM:number,
                 iname:string,
                 iphoneNumber:string,
                 iuid:string,
                 iticketInfo:string,
                 ipurchaserIDs:string,
                 iimgUrl:string){
                    this.address=iaddress;
                    this.descripton=idescription;
                    this.endDate=iendDate;
                    this.startDate=istartDate;
                    this.endHourAM=iendHourAM;
                    this.startHourPM=istartHourPM;
                    this.name=iname;
                    this.phoneNumber=iphoneNumber;
                    this.uid=iuid;
                    this.ticketInfo=iticketInfo;
                    this.purchaserIDs=ipurchaserIDs;
                    this.imgUrl=iimgUrl;
                 }
 }
