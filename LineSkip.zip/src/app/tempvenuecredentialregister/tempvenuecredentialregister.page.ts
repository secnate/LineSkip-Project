import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Globals, USER_TYPES, TEMP_VENUES_DEFAULT_TAB } from "../../globals";
import * as firebase from "firebase";

@Component({
  selector: 'app-tempvenuecredentialregister',
  templateUrl: './tempvenuecredentialregister.page.html',
  styleUrls: ['./tempvenuecredentialregister.page.scss'],
})
export class TempvenuecredentialregisterPage implements OnInit {

  private prepreparedItems;
  private uid;
  new_temp_venue_form : FormGroup;

  constructor(private router : Router,
              private route : ActivatedRoute,
              public globals : Globals,
              public formBuilder : FormBuilder) { }

  ngOnInit() {
    this.route.params.subscribe (
      param => {
        this.prepreparedItems = param;
        console.log("DEBUG: the parameter received is: " + JSON.stringify(this.prepreparedItems));
      }
    );

    this.new_temp_venue_form = this.formBuilder.group({
      email : new FormControl('',Validators.required),
      password: new FormControl('', Validators.required)
    });
  }

  cancel() {
    this.router.navigate(['/signupvenue']);
  }

  createTempVenue(value) {
    // We now register the account into firebase 
    // and upload all the data up to the database
    var email = value.email;
    var password = value.password;
    var self = this;

    // we register the new user
    // and save all his information to firebase


    var successful = true;

    console.log("DEBUG: we are going to create a user with this information");
  	firebase.auth().createUserWithEmailAndPassword(email, password).catch(
  		function(error) {

	      // Handle Errors here.
	      console.log(error);
	      var errorCode = error.code;
	      var errorMessage = error.message;
		    console.log(error.message);

	      if(errorCode.length > 0){
		    	alert('Failed to Sign Up.\n' + errorMessage);
		    	successful = false;
		    } 
	      else{
		    	console.log("signup ok")
		    	successful = true;
	     }
       // ...
       
	    }).then(function(user){


				if (successful) {

          console.log("DEBUG: registering new tempVenueCredentials.");
          console.log("DEBUG: want to save " + self.prepreparedItems.ticketInfo);
          console.log("DEBUG - string representation is \'" + 
                      JSON.stringify(self.prepreparedItems.ticketInfo + "\'"));

          var userID = firebase.auth().currentUser.uid;

          var newVenueInfo = {
            address: self.prepreparedItems.address,
            endDate: self.prepreparedItems.endDate,
            startDate: self.prepreparedItems.startDate,

            // this is AM time - 12 to 2 AM
            endHourAM: (new Date(self.prepreparedItems.endDate)).getHours(),

            // this is PM time
            startHourPM: (new Date(self.prepreparedItems.startDate)).getHours(),

            name: self.prepreparedItems.name,
            phoneNumber : self.prepreparedItems.phoneNumber,

            uid: userID,
            descripton : self.prepreparedItems.venueDescription,

            // Now we add in the collection of hourly ticket info
            // in stringified format. The formatting of the objects
            // stored inside it is defined on the previous page
            ticketInfo: self.prepreparedItems.ticketInfo,

            // Now we add in a collection of puchaserID
            // which is an stringified array
            // containing their hourly purchasers' information
            // The objects stored inside this stringified array will have
            // the following information:
            // (1) uid of the purchaser
            // (2) the hour for which they purchased tickets
            purchaserIDs: JSON.stringify([]),   // empty object
            imgUrl:""   // empty object

          };
          console.log("Creating new temp venue. \
                       \nThe objects stored inside the stringified purchaserIDs array contain the following \
                       \n\t(1) uid of the purchaser \
                       \n\t(2) the hour for which they purchased tickets");
          
          let newVenueFirebase = firebase.database().ref('tempVenueInfo/').push();
          
          newVenueFirebase.set( JSON.parse(JSON.stringify(newVenueInfo)) );

          console.log("DEBUG: ticketInfo is: " + 
                  JSON.stringify(self.prepreparedItems.ticketInfo));

          // we also add the user type to the user types
          let newPatronType = firebase.database().ref('userType/').push();
          newPatronType.set({
            uid: userID, type: USER_TYPES.TEMPORARY_VENUE
          })

          self.globals.SET_CURRENT_LOGGED_IN_TYPE(USER_TYPES.TEMPORARY_VENUE);
          Globals.CURRENT_TEMP_VENUE_OBJ = newVenueInfo;        // so we set the currently logged in information

          // Move to the core of the app itself after logging in
          // by default we go to tab3 - the first tab 
          // for the venue side of the app
          self.router.navigate(['/take-temp-photo', 
          {id : userID} ]);
        }
        else {
          alert('Failed to Sign Up due to Invalid Credentials.\nPlease Try Again.');
        }
  });

  }

}
