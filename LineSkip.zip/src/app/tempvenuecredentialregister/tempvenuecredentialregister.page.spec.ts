import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TempvenuecredentialregisterPage } from './tempvenuecredentialregister.page';

describe('TempvenuecredentialregisterPage', () => {
  let component: TempvenuecredentialregisterPage;
  let fixture: ComponentFixture<TempvenuecredentialregisterPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TempvenuecredentialregisterPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TempvenuecredentialregisterPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
