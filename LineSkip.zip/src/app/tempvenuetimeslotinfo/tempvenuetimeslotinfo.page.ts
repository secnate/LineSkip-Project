import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Globals, TEMP_VENUES_DEFAULT_TAB } from "../../globals";
import { ParamserviceService } from "../paramservice.service";
import * as firebase from 'firebase';
 
@Component({
  selector: 'app-tempvenuetimeslotinfo',
  templateUrl: './tempvenuetimeslotinfo.page.html',
  styleUrls: ['./tempvenuetimeslotinfo.page.scss'],
})

  /*
    // this will be used for future referencing
    //this.currentTempID = firebase.auth().currentUser.uid;
    //let tempVenueRef = firebase.database().ref('tempVenueInfo/');
    //var self = this;
    tempVenueRef.orderByChild("uid").equalTo(this.currentTempID).limitToFirst(1).on("value", function(data) {
          // whenever the information regarding temporary venue changes, 
          // we load the temporary venue data
          // we extract the object from firebase
          var data_keys = Object.keys(data.val());
          var extractedOBJ = data.val()[ data_keys[0] ];

          // update the global variable
          Globals.CURRENT_TEMP_VENUE_OBJ = extractedOBJ;

          // now we update the ticket array
          self.initializeTicketInfoArray();
          console.log("DEBUG: updated tempVENUEDATA");
    });*/


export class TempvenuetimeslotinfoPage implements OnInit {

  private tempVenueRef = firebase.database().ref('tempVenueInfo/');

  private currentTempID;

  splitUpObjects;   // used to store the string representations of all hourly objects

  // object containing startHour, numTickets, and ticketPrice
  // we assume that numTickets represents the number of tickets available
  private startHour; 

  // this is the object containing the information about the current hour
  private currentHourObject;
  private indexCurrentHourObject : number;

  // boolean controls the apprarance of the inputting of a form
  // in which the temporary can input the number of tickets to be added
  // to a given hour sloot
  private showingNewTicketsInput: boolean = false;
  private numberTicketsToAdd : number = 0;

  constructor(private router : Router,
              private paramService : ParamserviceService,
              public globals : Globals) { 
  }

  ngOnInit() {
    this.startHour = this.paramService.getHourInfo();

    // We define the default values of the number of tickets we can add
    this.showingNewTicketsInput = false;
    this.numberTicketsToAdd = 0;

    // Now initialize the hourly information

    // we initialize the hourly information
    this.currentTempID = firebase.auth().currentUser.uid;
    var self = this;

    // each time the object gets updated, we update the time slot information
    this.tempVenueRef.orderByChild("uid").equalTo(this.currentTempID).limitToFirst(1).on("value", function(data) {
    var data_keys = Object.keys(data.val());
    var extractedOBJ = data.val()[ data_keys[0] ]; 
  
    // update the global variable due to firebase 
    // updating the extracted data due to it being modified
    Globals.CURRENT_TEMP_VENUE_OBJ = extractedOBJ;

    // continue with updating the page's data
    self.updateHourlyInformation(extractedOBJ);
    });
  }

  goBack() {
    // the default tab is the one containing the hourly
    // information and the one that called this page
    this.router.navigate([TEMP_VENUES_DEFAULT_TAB]);
  }

  updateHourlyInformation(extractedOBJ) {
    // first we remove the '[' and ']' from the string's start and end if there is one
    var stringToParse = extractedOBJ.ticketInfo;

    if ( stringToParse.charAt(0) == '[' ) {
      // remove the '['
      stringToParse = stringToParse.substr(1);
    }

    if ( stringToParse[ stringToParse.length - 1 ] == ']') {
      stringToParse = stringToParse.slice(0, -1);
    }

    // split up the objects
    this.splitUpObjects = stringToParse.split("},");
    
    var i = 0;
    for (i = 0; i < this.splitUpObjects.length; i++) {
      if (this.splitUpObjects[i].slice(-1) != '}') {
        // it does not have the end curly bracked 
        // to close off object in string representation which was chopped off. 
        // correct this mistake
        this.splitUpObjects[i] = this.splitUpObjects[i] + "}";
      }
    }

    // now we parse things and save it to the ticket array
    var i = 0;
    this.splitUpObjects.forEach(element => {
      var extractedElement = JSON.parse(element);

      if (extractedElement.startHour == this.startHour) {
        this.currentHourObject = extractedElement;

        // save the index of the current hour object in 
        // the split up objects array for further use
        this.indexCurrentHourObject = i;
      }

      // we continue on to the next item
      i = i + 1;
    });
  }

  getTimeRange() {
    return this.getStringHour(this.startHour) + 
           " to " + 
           this.getStringHour( Number(this.startHour) + 1);
  }

  getStringHour(hour) {
    // returns "<# hour> <AM/PM>" string
    // for a given inputted number of the starting hour
    if ( hour < 12 ) {
      return String(hour) + " PM";
    }
    else if (hour == 12) {
      return String(hour) + " AM";
    }
    else {
      // this is all AM times after 12 AM
      return String(hour-12) + " AM";
    }
  }

  toggleNewTicketInput() {
    this.showingNewTicketsInput = !this.showingNewTicketsInput;

    if (this.showingNewTicketsInput) {
      // by default we are adding in zero tickets
      this.numberTicketsToAdd = 0;
    }
  }

  seeWhoBought() {
    console.log("CLICKED the \'see who bought\' button");
    console.log("TODO: implement the seeWhoBought() functio");
  }

  addNewTickets() {
    // we add new tickets that can be sold in the near future to patrons
    console.log("DEBUG: in addNewTickets() function");
    console.log("this.numberOfTicketsToAdd = " + this.numberTicketsToAdd);
    this.showingNewTicketsInput = false;

    // now we consider the cases
    if (this.numberTicketsToAdd == null) {
      // deal with null case
      alert("Invalid Input:\nYou did not enter a number of tickets to order.");
    }
    else if (this.numberTicketsToAdd < 0 ) {
      // dealing with negative case
      alert("Invalid Input:\nA number of tickets to order must be positive.");
    } else if ( this.numberTicketsToAdd == 0 ) {
      return; // we just quit... everything is fine!
    }
    
    // otherwise, the number of tickets is greater than zero than 0
    // and is suitable for the updating of the app's data
    console.log("DEBUG: the index of the item we need to modify is: " + this.indexCurrentHourObject);
    console.log("DEBUG: the current object I want to modify is: " + 
                JSON.stringify(this.currentHourObject));
    console.log("DEBUG: the array of split up objects is: " + 
                JSON.stringify(this.splitUpObjects));

    // first, we modify the current hour object
    this.currentHourObject.numTickets += this.numberTicketsToAdd;

    // push the updated current hour object into the splitUpObjects array
    this.splitUpObjects[this.indexCurrentHourObject] = 
                              JSON.stringify(this.currentHourObject);

    console.log("\n\nDEBUG: the splitUpObjects array is now: " + JSON.stringify(this.splitUpObjects));

    var fullObjectsArray = [];
    var i = 0;
    for (i = 0; i < this.splitUpObjects.length; i++) {
      // convert from string to object
      fullObjectsArray.push( JSON.parse(this.splitUpObjects[i]) )
    }

    // update the values stored in the globals
    Globals.CURRENT_TEMP_VENUE_OBJ.ticketInfo = JSON.stringify(fullObjectsArray);
    
    // and then update into firebase 
    // first we find the object to update
    // and we do this only ONCE
    this.tempVenueRef.orderByChild("uid").equalTo(this.currentTempID).limitToFirst(1).once("value", function(data) {
      var data_keys = Object.keys(data.val());

      console.log("DEBUG: data_keys is: " + JSON.stringify(data_keys));
      var extractedID = data_keys[0]; 

      // now we find the id
      // and use it to update the object
      let newInfo = firebase.database().ref(
                      'tempVenueInfo/'+extractedID).update(Globals.CURRENT_TEMP_VENUE_OBJ);
    });

    // after this, we have an alert that we ordered the new tickets
    alert("Added " + this.numberTicketsToAdd + " Tickets");
    this.router.navigate(["/tempvenuetimeslotinfo"]);       // ensure we are on the same page
  }

  makeSureNonNull() {
    // we make sure that the number of tickets can always be 0
    if (this.numberTicketsToAdd == null) {
      this.numberTicketsToAdd = 0;
    }
  }
}
