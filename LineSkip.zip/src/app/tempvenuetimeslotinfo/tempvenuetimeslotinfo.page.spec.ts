import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TempvenuetimeslotinfoPage } from './tempvenuetimeslotinfo.page';

describe('TempvenuetimeslotinfoPage', () => {
  let component: TempvenuetimeslotinfoPage;
  let fixture: ComponentFixture<TempvenuetimeslotinfoPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TempvenuetimeslotinfoPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TempvenuetimeslotinfoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
