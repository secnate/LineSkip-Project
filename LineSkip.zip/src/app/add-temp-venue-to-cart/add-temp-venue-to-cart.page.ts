import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Globals, TEMP_VENUES_DEFAULT_TAB } from "../../globals";
import { ParamserviceService } from "../paramservice.service";
import * as firebase from 'firebase';
import { tempVenue } from '../tab1/tab1.page';
import { cart, order, StringifiedCart } from '../tab3/tab3.page';
import { stringify } from '@angular/core/src/render3/util';
import { Events } from '@ionic/angular';


@Component({
  selector: 'app-add-temp-venue-to-cart',
  templateUrl: './add-temp-venue-to-cart.page.html',
  styleUrls: ['./add-temp-venue-to-cart.page.scss'],
})
export class AddTempVenueToCartPage implements OnInit {
  public tempVenueItem: tempVenueItems;
  public static Cart;
  private startHour;
  quantity: number;
  public item: tempVenue;
  public address:string;
  public description:string;
  public endDate:string;
  public startDate:string;
  public name:string;
  public phoneNumber:string;
  public uid:string;
  public price:number;
  public time:number;
  public orderTicketDate:string;

  // this is the object containing the information about the current hour
  private currentHourObject;

  private static tempVenueRef = firebase.database().ref('tempVenueInfo/');

  constructor(private route: Router,
              private r: ActivatedRoute,
              public globals: Globals,
              public events : Events) {
    this.r.params.subscribe(params => { this.item = JSON.parse(params['selectedVenue']); });
    this.r.params.subscribe(params => {this.startHour = params['hrSlotArray'];});

    this.quantity = 1;
    
    console.log("this is my item======="+this.item);
    
    // Doing checks about the recieving of the values
    console.log("DEBUG entered add-temp-venue-to-cart page!");
    console.log("DEBUG: recieved selectedVenue: " + JSON.stringify(this.item));
    console.log("DEBUG: recieved startHour is: " + this.startHour);
  }

  addToCart() {
    if (this.currentHourObject.numTickets<this.quantity){
      alert("Invalid Input;\n Cannot Order More Than is Available.");
    } else if (this.quantity<1) {
      alert("Invalid Input;\n The Quantity Cannot be a Negative Value.");
    } else {
    var k = [];
    AddTempVenueToCartPage.Cart = new cart();

    console.log("DEBUG: the AddTempVenueToCartPage.Cart is: " + 
              JSON.stringify(AddTempVenueToCartPage.Cart));

    
    firebase.database().ref('Cart/' + firebase.auth().currentUser.uid).once(
                                                 'value', function (snapshot) {
      snapshot.forEach(function (cShot) {
        k.push(cShot.key);

        firebase.database().ref('Cart/' + cShot.ref.parent.toString().substring(
                cShot.ref.parent.toString().lastIndexOf('/')) + '/' + 
                k[k.length - 1]).on('value', function (cSnap) {
          var m = cSnap.val();

          // extract the object from the 
          console.log("DEBUG: extracting cart from firebase!");
          var extractedOBJ = JSON.parse(m);
         
          console.log("DEBUG the extractedOBJ is: " + JSON.stringify(extractedOBJ));
          // we now take the arrays from being strings to being arrays
          var extractedOrderList = JSON.parse(extractedOBJ.orderList);
          console.log("DEBUG: the extractedOrderList is: " + extractedOrderList);

          var extractedCurrentOrder = JSON.parse(extractedOBJ.currentOrder);
          console.log("DEBUG: the extractedCurrentOrder is: " + extractedCurrentOrder);

          extractedOBJ.orderList = extractedOrderList;
          extractedOBJ.currentOrder = extractedCurrentOrder;

          AddTempVenueToCartPage.Cart = extractedOBJ;
        });
      });
    });

    this.tempVenueItem = new tempVenueItems(this.uid, this.price, this.time, this.quantity);
    this.tempVenueItem.uid=this.item.uid;
    this.tempVenueItem.quantity=this.quantity;
    // processing ticket information in order to update any changes
    console.log("this is the ticket info before updating:"+
                  JSON.stringify(this.item.ticketInfo));

    var extractedString = this.item.ticketInfo;

    // if there is a '[' or ']'
    if (extractedString.charAt(0) == '[' ) {
      extractedString = extractedString.substr(1);  // remove leading [
    }

    if ( extractedString[ extractedString.length - 1] == ']') {
      extractedString = extractedString.slice(0, -1);
    }

    var splitUpObjects = extractedString.split("},");

    var i = 0;
    for (i = 0; i < splitUpObjects.length; i++) {
      if (splitUpObjects[i].slice(-1) != '}') {
        // it does not have the end curly bracked 
        // to close off object in string representation which was chopped off. 
        // correct this mistake
        splitUpObjects[i] = splitUpObjects[i] + "}";
      }
    }

    // now we parse things and save it to the ticket array
    var allObjectsToStringifyAtOnce = [];
    splitUpObjects.forEach(element => {
      var extractedElement = JSON.parse(element);

      if (extractedElement.startHour == this.startHour) {
        this.tempVenueItem.price = extractedElement.ticketPrice;
        this.tempVenueItem.time=this.startHour;
        extractedElement.numTickets=extractedElement.numTickets-this.quantity;
        extractedElement.numSold=extractedElement.numSold+this.quantity;
        // *========*update temp venue here
      }

      allObjectsToStringifyAtOnce.push(extractedElement);
    });


      AddTempVenueToCartPage.Cart.currentOrder.items.push(this.tempVenueItem);
      AddTempVenueToCartPage.Cart.currentOrder.totalItems++;
      AddTempVenueToCartPage.Cart.currentOrder.totalPrice += this.tempVenueItem.price * this.quantity;
      AddTempVenueToCartPage.Cart.orderList[AddTempVenueToCartPage.Cart.orderList.length - 1] = AddTempVenueToCartPage.Cart.currentOrder;
    
    
    console.log("DEBUG: in add-temp-venue-to-cart-page.ts!");
    console.log("\tDEBUG: the AddTempVenueToCartPage.Cart is: " + 
                  JSON.stringify(AddTempVenueToCartPage.Cart));

    var s = {};
    s['userOrder'] = JSON.stringify( new 
                        StringifiedCart(AddTempVenueToCartPage.Cart) );
    
    firebase.database().ref('Cart/' + firebase.auth().currentUser.uid).update(s);
    if (this.quantity > 1) {
      alert("These items has been added to your order.");
    } else if (this.quantity == 1) {
      alert("This item has been added to your order.");
    }

      // now we update the temporary venue about the tickets ordered
      var stringifiedArrayToUpdate = JSON.stringify( allObjectsToStringifyAtOnce );
      var tempVenueUid = this.item.uid;

      AddTempVenueToCartPage.tempVenueRef.orderByChild("uid").equalTo(
                tempVenueUid).limitToFirst(1).once("value", function (data) {

        // we extract the current temporary venue's information just once
        var data_keys = Object.keys(data.val());
        var extractedTempOBJ = data.val()[ data_keys[0] ];

        console.log("DEBUG: the extracted TEMP VENUE OBJECT TO UPDATE IS: " + 
                    JSON.stringify(extractedTempOBJ));

        // now we update the object's values 
        //
        // we update specifically the TICKET_INFO and PURCHASER ID's
        extractedTempOBJ.ticketInfo = stringifiedArrayToUpdate;

        // we update the purchaser id's
        if (extractedTempOBJ.purchaserIDs == "[]") {
          // an empty array, no one purchased yet
          extractedTempOBJ.purchaserIDs = JSON.stringify( 
                                              [firebase.auth().currentUser.uid] );
        }
        else {
          // the array is not empty
          // Case 1: Patron already purchased tickets from there, so uid is in there
          // Case 2: Patron did not purchased tickets from there so we add it in
          var extractedUIDARRAY = JSON.parse( extractedTempOBJ.purchaserIDs );
          var i = 0;  // iterator
          var alreadyBought : boolean = false;
          for ( i = 0; i < extractedUIDARRAY.length; i++ ) {
            if ( extractedUIDARRAY[i] == firebase.auth().currentUser.uid ) {
              alreadyBought = true;
              break;
            }
          } 

          // if we did not buy it, we add the current user's id to the array,
          // then we stringify it and save it to the exractedOBJ for updating firebase
          // otherwise... what's the point?
          if (!alreadyBought) {
            extractedUIDARRAY.push( firebase.auth().currentUser.uid );
            extractedTempOBJ.purchaserIDs = JSON.stringify( extractedUIDARRAY );
          }
        }

        // so now we have the extractedTempOBJ with updated ticket info and purchaser
        // id information. we can push the data and update it in firebase
        let newInfo = firebase.database().ref('tempVenueInfo/'+data_keys[0]
                                            ).update(extractedTempOBJ);

         });

        // before we nagivate to needed page
        this.events.publish('updatedData', Date.now());
        this.route.navigate(['/tabs/tab1']);
  }
}
  goBack() {
    this.route.navigate(['/temp-venue-detail', {selectedVenue: JSON.stringify(this.item)}]);
  }
  ngOnInit() {
    
    console.log("DEBUG: THE PARAMETER IS: " + this.startHour);
    console.log("DEBUG: THE PARAMETER IS: " + this.item);

    var extractedString = this.item.ticketInfo;

    // if there is a '[' or ']'
    if (extractedString.charAt(0) == '[' ) {
      extractedString = extractedString.substr(1);  // remove leading [
    }

    if ( extractedString[ extractedString.length - 1] == ']') {
      extractedString = extractedString.slice(0, -1);
    }

    var splitUpObjects = extractedString.split("},");
    
    var i = 0;
    for (i = 0; i < splitUpObjects.length; i++) {
      if (splitUpObjects[i].slice(-1) != '}') {
        // it does not have the end curly bracked 
        // to close off object in string representation which was chopped off. 
        // correct this mistake
        splitUpObjects[i] = splitUpObjects[i] + "}";
      }
    }
    splitUpObjects.forEach(element => {
      var extractedElement = JSON.parse(element);

      if (extractedElement.startHour == this.startHour) {
        this.currentHourObject = extractedElement;
      }

    });

    console.log("UPDATED HOURLY INFORMATION");
    console.log("\thourly object information is: " + JSON.stringify(this.currentHourObject));

    // Now initialize the hourly information

    // we initialize the hourly information
    // this.currentTempID = firebase.auth().currentUser.uid;
    // let tempVenueRef = firebase.database().ref('tempVenueInfo/');
    // var self = this;

    // each time the object gets updated, we update the time slot information
    // tempVenueRef.orderByChild("uid").equalTo(this.currentTempID).limitToFirst(1).on("value", function (data) {
    //   var data_keys = Object.keys(data.val());
    //   var extractedOBJ = data.val()[data_keys[0]];

      // update the global variable due to some modification of related data
      // Globals.CURRENT_TEMP_VENUE_OBJ = extractedOBJ;

      // continue with updating the page's data
      // self.updateHourlyInformation(extractedOBJ);
    // });
  }

  getTimeRange() {
    return this.getStringHour(this.startHour) +
      " to " +
      this.getStringHour(Number(this.startHour) + 1);
  }

  getStringHour(hour) {
    // returns "<# hour> <AM/PM>" string
    // for a given inputted number of the starting hour
    if (hour < 12) {
      return String(hour) + " PM";
    }
    else if (hour == 12) {
      return String(hour) + " AM";
    }
    else {
      // this is all AM times after 12 AM
      return String(hour - 12) + " AM";
    }
  }

  /* WILL BE WORKED ON MUCH MUCH LATER
  countNumberTicketsPurchased() {
    // we count the number of people who purchased the tickets for this hour
    // 
    // this depends on the collection puchaserID
    // which is an stringified array
    // containing their hourly purchasers' information
    // The objects stored inside this stringified array will have
    // the following information:
    // (1) uid of the purchaser
    // (2) the hour for which they purchased tickets
    console.log("DEBUG: Globals.CURRENT_TEMP_VENUE_OBJ is: " 
                + Globals.CURRENT_TEMP_VENUE_OBJ);
    console.log("DEBUG: the current temp venue's purchaserID information is: " + )
  }*/

}

export class tempVenueItems {
  // public address:string;
  // public description:string;
  // public endDate:string;
  // public startDate:string;
  // public name:string;
  // public phoneNumber:string;
  public uid:string;
  public price:number;
  public time:number;
  public quantity:number;
   constructor ( 
                //  iaddress:string,
                //  idescription:string,
                //  iendDate:string,
                //  istartDate:string,
                //  iname:string,
                //  iphoneNumber:string,
                 iuid:string,
                 iprice:number,
                 itime:number,
                 iquantity:number
                 ){
                    // this.address=iaddress;
                    // this.description=idescription;
                    // this.endDate=iendDate;
                    // this.startDate=istartDate;
                    // this.name=iname;
                    // this.phoneNumber=iphoneNumber;
                    this.uid=iuid;
                    this.price=iprice;
                    this.time=itime;
                    this.quantity=iquantity;
                 }
 }


