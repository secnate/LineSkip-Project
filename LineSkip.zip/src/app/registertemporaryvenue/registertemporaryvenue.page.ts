import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Validators, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Globals, USER_TYPES, VENUE_TYPES } from "../../globals";
import * as firebase from 'firebase';

@Component({
  selector: 'app-registertemporaryvenue',
  templateUrl: './registertemporaryvenue.page.html',
  styleUrls: ['./registertemporaryvenue.page.scss'],
})
export class RegistertemporaryvenuePage implements OnInit {

  new_temp_venue_form : FormGroup;
  hasReadTermsAndConditions: boolean = false;

  constructor(private router: Router, 
              public globals : Globals,
              public formBuilder : FormBuilder) { }

  ngOnInit() {
    this.new_temp_venue_form = this.formBuilder.group({
      name: new FormControl('', Validators.required),
      address: new FormControl('', Validators.required),
      venueDescription : new FormControl('', Validators.required),
      phoneNumber: new FormControl('', Validators.required)
    });
    this.hasReadTermsAndConditions = false;

  }

  ionViewWillLeave() {
    this.ngOnInit();
  }

  goBack() {
    this.router.navigate(["/signupvenue"]);
  }

  next(new_temp_venue) {
    // We move on to the next view controller 
    // to register information
    console.log("DEBUG: SIGNING UP " + JSON.stringify(new_temp_venue));
    this.router.navigate(["/newtempvenuedatetimepicker", new_temp_venue]);
  }
  toggleHasReadTermsAndConditions() {
    this.hasReadTermsAndConditions = !this.hasReadTermsAndConditions;
  }

  openTermsAndConditions() {
    var parmaeterOBJ = { returnURL : "/signupvenue"};
    this.router.navigate(['/venue-terms-cond', parmaeterOBJ]);
  }
}
