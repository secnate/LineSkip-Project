import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { TakeTempPhotoPage } from './take-temp-photo.page';

const routes: Routes = [
  {
    path: '',
    component: TakeTempPhotoPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [TakeTempPhotoPage]
})
export class TakeTempPhotoPageModule {}
