import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Camera, CameraOptions } from "@ionic-native/camera/ngx";
import { File } from "@ionic-native/file/ngx";
import { Globals, USER_TYPES, TEMP_VENUES_DEFAULT_TAB } from "../../globals";
import * as firebase from "firebase";
import { Events } from "@ionic/angular";
import { getUrl } from '@ionic/angular/dist/directives/navigation/stack-utils';


@Component({
  selector: 'app-take-temp-photo',
  templateUrl: './take-temp-photo.page.html',
  styleUrls: ['./take-temp-photo.page.scss'],
})
export class TakeTempPhotoPage implements OnInit {
  private tempVenueRef = firebase.database().ref('tempVenueInfo/');

  storageRef = firebase.storage().ref();
  currentImageSource = "../../assets/defaultImage.png";
  static menuUrl;
  static idOfCreatedObject = "";

  hasTakenPhotographImage = false;

  constructor(private router: Router,
    private camera: Camera,
    private file: File,
    private activatedRoute: ActivatedRoute,
    public events: Events) {

    this.activatedRoute.params.subscribe(params => {

      TakeTempPhotoPage.idOfCreatedObject = params['id'];
      console.log("DEBUG: this.idOfCreatedObject is: " +
        TakeTempPhotoPage.idOfCreatedObject);

      // remove the start quote and end quote
      // TakeTempPhotoPage.idOfCreatedObject = TakeTempPhotoPage.idOfCreatedObject.substring(1, 
      //   TakeTempPhotoPage.idOfCreatedObject.length-1);

    });

  }

  ngOnInit() {
  }

  ionViewWillEnter() {
    this.hasTakenPhotographImage = false;
    this.currentImageSource = "../../assets/defaultImage.png";
  }

  selectImage() {
    console.log("In PickImage() function");
    this.pickImage();
  }

  goBack() {
    this.router.navigate(['tabs.tab4']);
  }
  finish() {
    console.log("In finish() function.");
    //////////////////////////////////////////////////////////////////////////////////////

    this.tempVenueRef.orderByChild("uid").equalTo(TakeTempPhotoPage.idOfCreatedObject
    ).limitToFirst(1).once("value", function (data) {

      // we extract the current temporary venue's information just once                  
      var data_keys = Object.keys(data.val());
      var extractedOBJ = data.val()[data_keys[0]];

      console.log("DEBUG: the extracted object is: " + JSON.stringify(extractedOBJ));

      Globals.CURRENT_TEMP_VENUE_OBJ = extractedOBJ;

      extractedOBJ.imgUrl = TakeTempPhotoPage.menuUrl;


      var extractedID = data_keys[0];
      console.log("DEBUG: the extractedID is: " + extractedID);

      let newInfo = firebase.database().ref(
        'tempVenueInfo/' + extractedID).update(extractedOBJ);
    });

    // this.events.publish('updatedBasicTempInfo', Date.now());

    ///////////////////////////////////////////////////////////////////////////
    this.router.navigate([TEMP_VENUES_DEFAULT_TAB]);
  }


  async pickImage() {

    const options: CameraOptions = {
      quality: 40,
      targetWidth: 1024,
      targetHeight: 1024,
      destinationType: this.camera.DestinationType.FILE_URI,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE
    };

    try {
      // we have already picked an image... we first delete it
      // and then add a new photographed image to it
      if (this.hasTakenPhotographImage) {
        // delete it first
        this.deleteImageFromFirebase(TakeTempPhotoPage.idOfCreatedObject);
      }

      let cameraInfo = await this.camera.getPicture(options);
      let blobInfo = await this.makeFileIntoBlob(cameraInfo);
      let uploadInfo: any = await this.uploadStoreImageToFirebase(blobInfo);

      console.log(uploadInfo);
      // this.url = uploadInfo.ref.getDownloadURL();
      this.hasTakenPhotographImage = true;
      this.events.publish("updatedPhoto");

    } catch (e) {
      console.log(e.message);
      if (e.message != "undefined") {
        alert("File Upload Error " + e.messasge);
      }
    }
  }

  makeFileIntoBlob(_imagePath) {
    return new Promise((resolve, reject) => {

      let fileName = TakeTempPhotoPage.idOfCreatedObject + ".JPG";
      this.file
        .resolveLocalFilesystemUrl(_imagePath)
        .then(fileEntry => {
          let { name, nativeURL } = fileEntry;

          // get the path..
          let path = nativeURL.substring(0, nativeURL.lastIndexOf("/"));
          console.log("path", path);
          console.log("fileName", name);

          fileName = name;

          // we are provided the name, so now read the file into
          // a buffer
          return this.file.readAsArrayBuffer(path, name);
        })
        .then(buffer => {
          // get the buffer and make a blob to be saved
          let imgBlob = new Blob([buffer], {
            type: "image/jpeg"
          });
          console.log(imgBlob.type, imgBlob.size);
          resolve({
            fileName,
            imgBlob
          });
        })
        .catch(e => reject(e));
    });
  }

  uploadStoreImageToFirebase(_imageBlobInfo) {
    console.log("uploadToFirebase");
    return new Promise((resolve, reject) => {
      let imageid = (Math.floor(Math.random() * 2000)).toString();
      let filename = _imageBlobInfo.fileName;

      let fileRef = firebase.storage().ref(
      ).child("menuImages").child(TakeTempPhotoPage.idOfCreatedObject + ".JPG");

      //firebase.storage().ref(EditstoreinfoPage.RESTAURANT_FILE_NAME);

      let uploadTask = fileRef.put(_imageBlobInfo.imgBlob);
      let mydownloadurl = "";

      var self = this;

      uploadTask.on(
        "state_changed",
        (_snapshot: any) => {
          console.log(
            "snapshot progess " +
            (_snapshot.bytesTransferred / _snapshot.totalBytes) * 100
          );
        },
        _error => {
          console.log(_error);
          reject(_error);
        },
        () => {
          // completion...  get the image URL for saving to database
          uploadTask.snapshot.ref.getDownloadURL().then(function (downloadURL) {
            console.log('File available at', downloadURL);
            self.currentImageSource = downloadURL;
            TakeTempPhotoPage.menuUrl=self.currentImageSource;
            resolve(mydownloadurl);


          });
          // resolve( uploadTask.snapshot);
          // resolve( mydownloadurl);

        }
      );

    });

  }


  deleteImageFromFirebase(id) {
    // Create a reference to the file to delete
    var self = this;
    let fileRef = firebase.storage().ref(
    ).child("menuImages").child(id + ".JPG");

    // Delete the file
    fileRef.delete().then(function () {
      // File deleted successfully
    }).catch(function (error) {
      // Uh-oh, an error occurred!
      alert("Delete Error Occurred: " + error.message);
    });

  }

}
