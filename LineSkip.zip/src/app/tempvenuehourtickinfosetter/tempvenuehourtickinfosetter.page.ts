import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Globals, USER_TYPES, VENUE_TYPES } from "../../globals";

@Component({
  selector: 'app-tempvenuehourtickinfosetter',
  templateUrl: './tempvenuehourtickinfosetter.page.html',
  styleUrls: ['./tempvenuehourtickinfosetter.page.scss'],
})
export class TempvenuehourtickinfosetterPage implements OnInit {

  received_temp_venue_info = null;

  // information about the start and end time
  private startHour = null;
  private endHour = null;
  private totalNumHours = null;

  // array of information about tickets
  private ticketInfo : any[] = null;

  constructor(private router : Router,
              public globals : Globals,
              private route : ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe( param=> {
      this.received_temp_venue_info = param;

      console.log( JSON.stringify(this.received_temp_venue_info) );
      
      // Now we have received the user information
      // we now extract the start hour and end hour
      // and start preparing the ticket information
      var dateWithStartTime = this.received_temp_venue_info.startTime;
      var dateWithEndTime = this.received_temp_venue_info.endTime;

      // we extract the hours from the two date objects
      this.startHour = (new Date(dateWithStartTime)).getHours(); // this is PM
      this.endHour = (new Date(dateWithEndTime)).getHours();     // this is AM

      var numberOfPMHours = 12 - this.startHour;

      var numberOfAMHours = this.endHour;
      if (this.endHour == 12 ) {
        numberOfAMHours = 0;
      }

      this.totalNumHours = numberOfPMHours + numberOfAMHours;

      // Now we create an array of objects that will contain
      // three items:
      // (1) Start Hour - the hour that starts the one-hour period
      // (2) Number Tickets
      // (3) End Time
      // This is just a basic empty value array right now
      this.ticketInfo = new Array(this.totalNumHours);
      for (var i = 0; i < this.totalNumHours; i++) {
        this.ticketInfo[i] = {
          // if start hour goes over 12, then this is AM zone
          startHour : this.startHour + i,
          numTickets : 0,
          ticketPrice : 0,
          numSold : 0
        };
      }
    });
  }

  ionViewWillAppear() {
    console.log("DEBUG in it");
    this.ngOnInit();
  }

  cancel() {
    this.router.navigate(['/signupvenue']);
  }

  getHourSlotString(startHour) {
    // startHour is a number from 8 to numbers greater than 12
    // 8 to 12 (non-inclusive) are pm times
    // 12 and onwards are AM times

    var toReturn : string = "";

    if (startHour < 12 ) {
      // starting hour is PM
      toReturn += startHour.toString() + " PM to ";
    } 
    else {
      // starting hour is AM
      if (startHour == 12) {
        toReturn += startHour.toString() + " AM to ";
      }
      else {
        toReturn += (startHour-12).toString() + " AM to ";
      }
    }

    var endHour = startHour + 1;

    if (endHour < 12 ) {
      // ending hour is PM
      toReturn += endHour.toString() + " PM: ";
    } 
    else {
      // ending hour is AM
      if (endHour == 12) {
        toReturn += endHour.toString() + " AM: ";
      }
      else {
        toReturn += (endHour-12).toString() + " AM: ";
      }
    }

    return toReturn;
  }

  anyEmpty() {
    // indicates if any of the inputs are empty
    var toReturn = false;
    this.ticketInfo.forEach(element => {
    
      if (element.ticketPrice == null || element.numTickets == null) {
        toReturn = true;
      }
    });

    return toReturn;
  }

  moveNext() {
    // prepackage information to send to next view controller

    // create an array of stringified ticket information to pass on
    var stringifiedHourTicketInfo = [];
    var i = 0;
    for (i = 0; i < this.ticketInfo.length; i++) {
      stringifiedHourTicketInfo.push( JSON.stringify(this.ticketInfo[i]) );
    }
    console.log("DEBUG: stringifiedHourTicketInfo array is: " + JSON.stringify(stringifiedHourTicketInfo));


    var toPassOn = {
      //original information received from previous slide
      name: this.received_temp_venue_info.name,
      address: this.received_temp_venue_info.address,
      venueDescription: this.received_temp_venue_info.venueDescription,
      phoneNumber: this.received_temp_venue_info.phoneNumber,

      // now we add in the new information
      //    the start and end dates of the event
      startDate: this.received_temp_venue_info.startDate,
      endDate: this.received_temp_venue_info.endDate, 

      //    the start times and end times of the event
      //    note the CRITICAL ASSUMPTION that the start 
      //    time is PM and the end time is AM.
      startTime: this.received_temp_venue_info.startTime,
      endTime: this.received_temp_venue_info.endTime,

      // Now we toss in the array of information
      // It is an array with the following information
      // for each one-hour time slot:
      //    startHour, numTickets, ticketPrice 
      ticketInfo : stringifiedHourTicketInfo
    };


    this.router.navigate(["tempvenuecredentialregister", toPassOn]);
  }
}
