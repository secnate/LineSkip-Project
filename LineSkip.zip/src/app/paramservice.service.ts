import { Injectable } from '@angular/core';

// This will be used to pass certain 
// parameters from page to page
@Injectable({
  providedIn: 'root'
})
export class ParamserviceService {

  hourInfo: any;

  constructor() { 
    this.clearHourInfo();
  }

  public setHourInfo(param) {
    this.hourInfo = param;
  }

  public clearHourInfo() {
    this.hourInfo = null;
  }

  public getHourInfo() {
    return this.hourInfo;
  }
}
