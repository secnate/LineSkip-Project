import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { tempVenue } from '../tab1/tab1.page';
import * as firebase from 'firebase';
import { Globals } from "../../globals";
import { Events } from '@ionic/angular';
import { tempVenueItems } from '../add-temp-venue-to-cart/add-temp-venue-to-cart.page';
import { PayPal, PayPalPayment, PayPalConfiguration } from '@ionic-native/paypal/ngx';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {

  private tempVenueRef = firebase.database().ref('tempVenueInfo/');
  
  public allOrders: cart;

  /*
  This object is used to display stuff on the screen here
  DEBUG: the currentOrder is: {"items":[{"uid":"TSCS6HqcU3gblGl41uNZR8VMc6k1","price":7,"time":"9"},
  {"uid":"TSCS6HqcU3gblGl41uNZR8VMc6k1","price":9,"time":"8"},
  {"uid":"TSCS6HqcU3gblGl41uNZR8VMc6k1","price":5,"time":"10"}],
  "totalItems":3,"totalPrice":21,"date":"\"2019-04-15T00:35:18.768Z\""}
  */
  public tab3CurrentOrder;

  /*
   The extracted object order list is used to explay stuff on the screen here
   [{"items":[{"uid":"TSCS6HqcU3gblGl41uNZR8VMc6k1","price":7,"time":"9"},
   {"uid":"TSCS6HqcU3gblGl41uNZR8VMc6k1","price":9,"time":"8"},
   {"uid":"TSCS6HqcU3gblGl41uNZR8VMc6k1","price":5,"time":"10"}],
   "totalItems":3,"totalPrice":21,"date":"\"2019-04-15T00:35:18.768Z\""}]
   */
  public tab3OrderList;
  public extractedCartTickets = [];
  public namesExtractedTicketsDict = {};

  // Function
  public totalTickets : number = 0;
  public totalPrice : number = 0;

  constructor(private route: Router, public events : Events,
              private payPal : PayPal) {

    this.events.subscribe('updatedData', (time) => {
      // the information was updated in firebase, update page accordingly
      this.ionViewDidEnter();
    });
  }

  ionViewDidEnter() {
    this.totalTickets = 0;

    var self = this;
    this.allOrders = new cart();
    firebase.database().ref('Cart/'+firebase.auth().currentUser.uid).on('value', function(snapshot) {
      snapshot.forEach(function(cShot) {
        var stringifiedCartObject = cShot.val();

        var cartObjectWithStringifiedOrderListCurrentOrder = JSON.parse(stringifiedCartObject);
        //var extractedOrderList = JSON.parse(cartObjectWithStringifiedOrderListCurrentOrder);
        //var extractedCurrentOrder
        //self.allOrders = JSON.parse(x);
        //console.log(self.allOrders);

        console.log("DEBUG: in tab3, the stringifiedCartObject is: " + stringifiedCartObject);
        console.log("DEBUG: the extracted orderList is: " + cartObjectWithStringifiedOrderListCurrentOrder.orderList);
        console.log("DEBUG: the currentOrder is: " + cartObjectWithStringifiedOrderListCurrentOrder.currentOrder);

        self.tab3CurrentOrder = JSON.parse(cartObjectWithStringifiedOrderListCurrentOrder.orderList);
        self.tab3OrderList = JSON.parse(cartObjectWithStringifiedOrderListCurrentOrder.orderList);
        console.log("DEBUG: the tab3OrderList is: " + JSON.stringify(self.tab3OrderList));

        console.log("DEBUG: the tab3Orderlist[0].items is: " + 
                    JSON.stringify(self.tab3OrderList[0].items[0]) );
        self.extractedCartTickets = [];

        // now we iterate over each item and load all extracted items into the typescript array
        var i = 0;
        var j = 0;
        for (i = 0; i < self.tab3OrderList.length; i++) {

          for ( j = 0; j < self.tab3OrderList[i].items.length; j++) {
            self.extractedCartTickets.push(self.tab3OrderList[i].items[j]);

            self.totalTickets = self.totalTickets + 
                                self.tab3OrderList[i].items[j].quantity;
          }

          self.totalPrice = self.tab3OrderList[i].totalPrice;
        }

      });

      // we continue here
      // We now extract the names for each temporary venue per ticket
      let tempVenueInfoRef = firebase.database().ref('tempVenueInfo/'); 
      self.namesExtractedTicketsDict = {};
      self.extractedCartTickets.forEach(element => {
      // we iterate over each of the tickets, take its uid and then map
          tempVenueInfoRef.orderByChild("uid").equalTo(
                element.uid).limitToFirst(1).once("value", function(data) {

          var data_keys = Object.keys(data.val());
        
          // this will only happen once
          var extractedTempVenue = data.val()[ data_keys[0] ];
          
          self.namesExtractedTicketsDict[element.uid] = extractedTempVenue.name;
        });
      });

    });

  }

  goToOrder(x: order) {
    if(x.totalItems > 0) {
      this.route.navigate(['/tab8', {selectedOrder: JSON.stringify(x)}]);
    } else {
      alert("This order is has no items. Go to the home page and navigate to the items you would like to add to your order.");
    }
  }

  getTempVenueName(tempVenueID) {

    var nameToReturn = "";
    this.tempVenueRef.orderByChild("uid").equalTo(
      tempVenueID).limitToFirst(1).once("value", function (data) {

      // we extract the current temporary venue's information just once
      var data_keys = Object.keys(data.val());
      var extractedTempOBJ = data.val()[ data_keys[0] ];
      nameToReturn = extractedTempOBJ.name;
      });

    return nameToReturn;
  }

  getStartTimeString(numStartTime) {
    if (numStartTime < 12 ) {
      return numStartTime + " PM";
    }
    else if (numStartTime == 12) {
      return numStartTime + " AM";
    }
    else {
      return (numStartTime-12) + " AM";
    }
  }

  clearCart(showClearMessage) {
    // first we need to restore the tickets back 
    // to being available to being sold
    console.log("DEBUG: clearing cart");
    
    console.log("DEBUG: the extractedCartTickets is: " +
                JSON.stringify(this.extractedCartTickets) );
    var i = 0;
    for (i = 0; i < this.extractedCartTickets.length; i++ ) {
      // we go back into firebase and restore the tickets
      this.restoreTickets( this.extractedCartTickets[i]);
    }


    // we just need to delete the cart from the firebase cart collection
    let toDelete = firebase.database().ref('Cart/' + 
                      firebase.auth().currentUser.uid).remove();
    
    this.extractedCartTickets = []; // no tickets here
    this.totalPrice = 0;
    this.events.publish('updatedData', Date.now());

    if (showClearMessage) {
      alert("Cleared Cart");
    }
  }

  restoreTickets(ticketOBJ) {
    // crux of the issue
    // we restore the information of available tickets
    // we had previously placed to cart and don't want anymore

    var self = this;
    this.tempVenueRef.orderByChild("uid").equalTo(
      ticketOBJ.uid).limitToFirst(1).once("value", function (data) {
  
      // we extract the current temporary venue's information just once
      var data_keys = Object.keys(data.val());
      var extractedTempOBJ = data.val()[ data_keys[0] ];

      // OK now we do processing on the extractedTempObj's ticket info
      var extractedTicketInfo = extractedTempOBJ.ticketInfo;
      
      // strip up the '[' and ']'
      if (extractedTicketInfo.charAt(0) == '[' ) {
        extractedTicketInfo = extractedTicketInfo.substr(1);  // remove leading [
      }
  
      if ( extractedTicketInfo[ extractedTicketInfo.length - 1] == ']') {
        extractedTicketInfo = extractedTicketInfo.slice(0, -1);
      }

      // now we split up the objects in the string 
      var splitUpObjects = extractedTicketInfo.split("},");

      // restore the last "}" for each object
      var i = 0;
      for (i = 0; i < splitUpObjects.length; i++) {
        if (splitUpObjects[i].slice(-1) != '}') {
          // it does not have the end curly bracked 
          // to close off object in string representation which was chopped off. 
          // correct this mistake
          splitUpObjects[i] = splitUpObjects[i] + "}";
        }
      }

      // now we parse things and save it to the ticket array
      var allObjectsToStringifyAtOnce = [];
      splitUpObjects.forEach(element => {

        var parsedElement = JSON.parse(element);

        // now we update the information
        if (parsedElement.startHour == ticketOBJ.time ) {
          // we are in the given time slot
          // we increment the number of tickets here
          parsedElement.numTickets = parsedElement.numTickets + ticketOBJ.quantity;
        }

        allObjectsToStringifyAtOnce.push( parsedElement );
      });

      // OK now we need to stringify the array and push it back up
      extractedTempOBJ.ticketInfo = JSON.stringify( allObjectsToStringifyAtOnce );

      console.log("DEBUG: restoring the following object: " + JSON.stringify(extractedTempOBJ));

      // now we update the information 
      let newInfo = firebase.database().ref('tempVenueInfo/'+data_keys[0]
                                           ).update(extractedTempOBJ);
    });
  }

  // send a payment from the user to the app for the tickets
  checkOutCart() {
    
    var self=this;
    this.payPal.init({
      PayPalEnvironmentProduction: 'YOUR_PRODUCTION_CLIENT_ID',
      PayPalEnvironmentSandbox: 'AS1OTZPk1DoQbj1pln9LNGVE-dkJuc4nXlvYCQZPOTn8I1Yk8cA93JStSRb4ooTk9qHiUb93crg4H4pe'
    }).then(() => {
      // Environments: PayPalEnvironmentNoNetwork, PayPalEnvironmentSandbox, PayPalEnvironmentProduction
      this.payPal.prepareToRender('PayPalEnvironmentSandbox', new PayPalConfiguration({
        // Only needed if you get an "Internal Service Error" after PayPal login!
        //payPalShippingAddressOption: 2 // PayPalShippingAddressOptionPayPal
      })).then(() => {
        let payment = new PayPalPayment(JSON.stringify(self.totalPrice), 
                                        'USD',
                                        JSON.stringify(self.totalTickets) + ' Tickets', 
                                        'sale');
        this.payPal.renderSinglePaymentUI(payment).then(() => {
          // Successfully paid
          alert("You Have Purchased " + self.totalTickets + " Tickets");
          self.clearCart(false); // just for now
    
          // Example sandbox response
          //
          // {
          //   "client": {
          //     "environment": "sandbox",
          //     "product_name": "PayPal iOS SDK",
          //     "paypal_sdk_version": "2.16.0",
          //     "platform": "iOS"
          //   },
          //   "response_type": "payment",
          //   "response": {
          //     "id": "PAY-1AB23456CD789012EF34GHIJ",
          //     "state": "approved",
          //     "create_time": "2016-10-03T13:33:33Z",
          //     "intent": "sale"
          //   }
          // }
        }, (error) => {
          // Error or render dialog closed without being successful
          console.log("DEBUG: ERROR IN PURCHASING");
          console.log("DEBUG: the error is: " + JSON.stringify(error));
        });
      }, (error) => {
        // Error in configuration
        console.log("DEBUG: ERROR IN CONFIGURATION");
        console.log("DEBUG: the error is: " + JSON.stringify(error));
      });
    }, (error) => {
      // Error in initialization, maybe PayPal isn't supported or something else
      console.log("DEBUG: ERROR IN INITIALIZATION");
      console.log("DEBUG: the error is: " + JSON.stringify(error));
    });
  }


  logout(){
    var self=this;

    let fireBaseUser = firebase.auth().currentUser;
    console.log(fireBaseUser.uid +" userid")


    firebase.auth().signOut().then(function() {
      console.log("logout succeed");
      
      self.route.navigate(["/homepage"]);
      this.globals.ResetUserType();
  
        // Sign-out successful.
    }).catch(function(error) {
      // An error happened.
    });
  }
  
}

export class StringifiedCart {
  public orderList : string;
  public currentOrder: string;

  constructor( toCopy : cart) {
    // we take the "cart" object and we use it to create the better
    // and stringified version of the cart for storage in the firebase backend
    this.orderList = JSON.stringify(toCopy.orderList);
    this.currentOrder = JSON.stringify(toCopy.currentOrder);
  }
}

export class cart {
  public orderList: order[];
  public currentOrder: order;
  constructor() {
    this.orderList = [];
    this.createOrder( JSON.stringify( new Date() ) );
  }
  createOrder(orderDate: string) {
    var tOrder: order = new order(orderDate);
    this.orderList.push(tOrder);
    this.currentOrder = this.orderList[this.orderList.length-1];
  }
  addAnItem(x: tempVenueItems) {
    this.currentOrder.addAnItem(x);
    this.orderList[this.orderList.length-1] = this.currentOrder;
  }
}
export class order {
  public items: tempVenueItems[];
  public totalItems: number;
  public date: string;
  public totalPrice: number;
  constructor(orderDate: string) {
    this.items = [];
    this.totalItems = 0;
    this.totalPrice = 0;
    this.date = orderDate;
  }
  addAnItem(x: tempVenueItems) {
    this.items.push(x);
    this.totalItems++;
    this.totalPrice += x.price*x.quantity; //***** */
  }
}
