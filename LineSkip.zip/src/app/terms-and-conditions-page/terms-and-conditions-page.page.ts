import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-terms-and-conditions-page',
  templateUrl: './terms-and-conditions-page.page.html',
  styleUrls: ['./terms-and-conditions-page.page.scss'],
})
export class TermsAndConditionsPagePage implements OnInit {

  nameOfInvokingViewController;

  constructor(private router : Router,
              private route : ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(
      param => { 
        // We get the URL for which we can return to 
        // the invoking view controller
        this.nameOfInvokingViewController = param.returnURL;
        console.log("DEBUG: received parameter: " + 
                    JSON.stringify(this.nameOfInvokingViewController));
      }
    )
  }

  goBack() {
    if (this.nameOfInvokingViewController != "") {
      this.router.navigate([this.nameOfInvokingViewController])
    } 
    else {
      alert("We don't have a valid view controller to go back to.");
    }
  }

}
