import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { order, cart } from '../tab3/tab3.page';
import { tempVenueItems } from '../add-temp-venue-to-cart/add-temp-venue-to-cart.page';
import * as firebase from 'firebase';
@Component({
  selector: 'app-tab8',
  templateUrl: './tab8.page.html',
  styleUrls: ['./tab8.page.scss'],
})
export class Tab8Page implements OnInit {

//   currOrder: order;
//   static Orders: cart;
//   currOrderShortened: tempVenueItems[];
//   numOfItems: number[];
//   constructor(private route: Router, private r: ActivatedRoute) {
//     this.r.params.subscribe(params => {this.currOrder = JSON.parse(params['selectedOrder']);});
//     this.currOrderShortened = [];
//     this.numOfItems = [];
//     this.currOrderShortened.push(this.currOrder.items[0]);
//     this.numOfItems.push(1);
//     for(var i:number=1; i<this.currOrder.items.length; i++) {
//       var ind: number = -1;
//       for(var j:number=0; j<this.currOrderShortened.length; j++) {
//         if(this.currOrder.items[i].name == this.currOrderShortened[j].name) {
//           ind = j;
//         }
//       }
//       if(ind != -1) {
//         this.numOfItems[ind]++;
//       } else {
//         this.currOrderShortened.push(this.currOrder.items[i]);
//         this.numOfItems.push(1);
//       }
//     }
//   }

   ngOnInit() {
   }
//   newOrder() {
//     firebase.database().ref('Cart/'+firebase.auth().currentUser.uid).on('value', function(snapshot) {
//       snapshot.forEach(function(cShot) {
//         var x = cShot.val();
//         Tab8Page.Orders = JSON.parse(x);
//       });
//     });
//     if(Tab8Page.Orders.currentOrder.totalPrice != 0) {
//       Tab8Page.Orders.orderList.push(new order(0));
//       Tab8Page.Orders.currentOrder = Tab8Page.Orders.orderList[Tab8Page.Orders.orderList.length-1];
//       firebase.database().ref('Cart/'+firebase.auth().currentUser.uid).set({'userOrder' : JSON.stringify(Tab8Page.Orders)});
//     } else {
//       alert("You have checked out the Order")
//     }
//   }
//   goBack() {
//     this.route.navigate(['/tabs/tab3']);
//   }
}
