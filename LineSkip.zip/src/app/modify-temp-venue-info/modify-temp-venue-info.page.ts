import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Validators, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Events } from '@ionic/angular';
import * as firebase from 'firebase';
import { Globals } from "../../globals";

@Component({
  selector: 'app-modify-temp-venue-info',
  templateUrl: './modify-temp-venue-info.page.html',
  styleUrls: ['./modify-temp-venue-info.page.scss'],
})
export class ModifyTempVenueInfoPage implements OnInit {

  private tempVenueRef = firebase.database().ref('tempVenueInfo/');
  update_temp_venue_form : FormGroup;

  constructor(private router : Router,
              public formBuilder : FormBuilder,
              public events : Events) { }

  ngOnInit() {

    // read out the data from firebase
    var currentTempID = firebase.auth().currentUser.uid;

    var self = this;
    var extractedOBJ;
    this.tempVenueRef.orderByChild("uid").equalTo(currentTempID
                      ).limitToFirst(1).once("value", function(data) {
      // we extract the current temporary venue's information just once                  
      var data_keys = Object.keys(data.val());
      extractedOBJ = data.val()[ data_keys[0] ]; 
    
      // update the global variable due to firebase 
      // updating the extracted data due to it being modified
      // and we are using it to display the data
      Globals.CURRENT_TEMP_VENUE_OBJ = extractedOBJ;
    });

    // initialize the form
    self.update_temp_venue_form = this.formBuilder.group({
      name: new FormControl(extractedOBJ.name, Validators.required),
      address: new FormControl(extractedOBJ.address, Validators.required),
      venueDescription : new FormControl(extractedOBJ.descripton, Validators.required),
      phoneNumber: new FormControl(extractedOBJ.phoneNumber, Validators.required)
    });
  }

  goBack() {
    this.router.navigate(['/edit-temp-venue-info']);
  }

  update(updated_temp_venue_values) {
    console.log("DEBUG: clicked update!");
    console.log("DEBUG: The updated_temp_venue_values is: " +
                JSON.stringify(updated_temp_venue_values));

    var currentTempID = firebase.auth().currentUser.uid;
    this.tempVenueRef.orderByChild("uid").equalTo(currentTempID
                  ).limitToFirst(1).once("value", function(data) {
    
      // we extract the current temporary venue's information just once                  
      var data_keys = Object.keys(data.val());
      var extractedOBJ = data.val()[ data_keys[0] ]; 

      console.log("DEBUG: the extracted object is: " + JSON.stringify(extractedOBJ));

      // update the global variable due to firebase 
      // updating the extracted data due to it being modified
      // and we are using it to display the data
      Globals.CURRENT_TEMP_VENUE_OBJ = extractedOBJ;

      // we now update the extracted object with 
      // the updated values from the form
      extractedOBJ.name = updated_temp_venue_values.name;
      extractedOBJ.address = updated_temp_venue_values.address;
      extractedOBJ.descripton = updated_temp_venue_values.venueDescription;
      extractedOBJ.phoneNumber = updated_temp_venue_values.phoneNumber;

      // now we save the chagnges
      var extractedID = data_keys[0]; 
      console.log("DEBUG: the extractedID is: " + extractedID);

      // now we find the id
      // and use it to update the object
      let newInfo = firebase.database().ref(
                      'tempVenueInfo/'+extractedID).update(extractedOBJ);
    });

    this.events.publish('updatedBasicTempInfo', Date.now());
    this.router.navigate(["/edit-temp-venue-info"]);
  }

}
