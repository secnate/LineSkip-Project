import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-venue-terms-cond',
  templateUrl: './venue-terms-cond.page.html',
  styleUrls: ['./venue-terms-cond.page.scss'],
})
export class VenueTermsCondPage implements OnInit {
  nameOfInvokingViewController;
  constructor(private router : Router,
    private route : ActivatedRoute) { }

ngOnInit() {
this.route.params.subscribe(
param => { 
// We get the URL for which we can return to 
// the invoking view controller
this.nameOfInvokingViewController = param.returnURL;
console.log("DEBUG: received parameter: " + 
          JSON.stringify(this.nameOfInvokingViewController));
}
)
}

goBack() {
if (this.nameOfInvokingViewController != "") {
this.router.navigate([this.nameOfInvokingViewController])
} 
else {
alert("We don't have a valid view controller to go back to.");
}
}

}
