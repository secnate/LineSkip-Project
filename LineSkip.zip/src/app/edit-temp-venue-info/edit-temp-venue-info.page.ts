// This page displays the temporary venue object's 
// generic information that does not pertain to tickets,
// like address, description, name, phone number, 
// May or may not allow them to update the start and end date as well
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Globals } from "../../globals";
import { Events } from '@ionic/angular';
import * as firebase from 'firebase';

interface GeneralInfo {
  name : string,
  description: string,
  address: string,
  phoneNumber : string,
  startDate : string, 
  endDate : string
}

@Component({
  selector: 'app-edit-temp-venue-info',
  templateUrl: './edit-temp-venue-info.page.html',
  styleUrls: ['./edit-temp-venue-info.page.scss'],
})
export class EditTempVenueInfoPage implements OnInit {

  private tempVenueRef = firebase.database().ref('tempVenueInfo/');
  
  tempVenueToDisplay : GeneralInfo = {
    name: "", description: "", address: "",
    phoneNumber: "", startDate: "", endDate: ""
  };  // initializing with a default object

  constructor(private router : Router, 
              public globals : Globals,
              public events : Events) { 
    this.loadData();

    // if anything gets updated, we listen 
    // here to run it again
    this.events.subscribe('updatedBasicTempInfo', (time) => {
      this.loadData();
    });
  }

  loadData() {
    var currentTempID = firebase.auth().currentUser.uid;

    var self = this;
    this.tempVenueRef.orderByChild("uid").equalTo(currentTempID
                      ).limitToFirst(1).once("value", function(data) {
      // we extract the current temporary venue's information just once                  
      var data_keys = Object.keys(data.val());
      var extractedOBJ = data.val()[ data_keys[0] ]; 
    
      // update the global variable due to firebase 
      // updating the extracted data due to it being modified
      // and we are using it to display the data
      Globals.CURRENT_TEMP_VENUE_OBJ = extractedOBJ;
      
      self.tempVenueToDisplay = {
        name: extractedOBJ.name,
        description: extractedOBJ.descripton,
        address: extractedOBJ.address,
        phoneNumber: extractedOBJ.phoneNumber, 
        startDate: extractedOBJ.startDate, 
        endDate: extractedOBJ.endDate
      }; 
    });
  }

  ionViewWillEnter() {
  }

  ngOnInit() {
  }

  goBack() {
    this.router.navigate(["tabs/tab5"]);
  }

  openEditPage() {
    this.router.navigate(["/modify-temp-venue-info"]);
  }

  getName() {
    if (this.tempVenueToDisplay.name != "") {
      return this.tempVenueToDisplay.name
    }
    else {
      return "Name Not Available";
    }
  }

  getDescription() {
    if (this.tempVenueToDisplay.description != "") {
      return this.tempVenueToDisplay.description
    }
    else {
      return "Description Not Available";
    }
  }

  getAddress() {
    if (this.tempVenueToDisplay.address != "") {
      return this.tempVenueToDisplay.address
    }
    else {
      return "Address Not Available";
    }
  }

  getPhoneNumber() {
    if (this.tempVenueToDisplay.phoneNumber != "") {
      return this.tempVenueToDisplay.phoneNumber
    }
    else {
      return "Phone Not Available";
    }
  }

  getStartDate() {
    if (this.tempVenueToDisplay.startDate != "") {

      var extractedDateOBJ = new Date(this.tempVenueToDisplay.startDate);
      return extractedDateOBJ.toLocaleDateString('en-US');
    }
    else {
      return "Start Date Not Available";
    }
  }

  getEndDate() {
    if (this.tempVenueToDisplay.endDate != "") {
      var extractedDateOBJ = new Date(this.tempVenueToDisplay.endDate);
      return extractedDateOBJ.toLocaleDateString('en-US');
    }
    else {
      return "End Date Not Available";
    }
  }
}
