import { Component } from '@angular/core';

import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

import { Router } from '@angular/router';

import * as firebase from 'firebase';

// Initialize Firebase
var config = {
    apiKey: "AIzaSyAfmtOigV3566vr1ws0sYPv0yFAd3f4uRo",
    authDomain: "lineupfinalappproject.firebaseapp.com",
    databaseURL: "https://lineupfinalappproject.firebaseio.com",
    projectId: "lineupfinalappproject",
    storageBucket: "lineupfinalappproject.appspot.com",
    messagingSenderId: "452865233815"
};

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html'
})
export class AppComponent {

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private router : Router
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
      this.router.navigateByUrl("homepage");
    });
    firebase.initializeApp(config);
  }
}
