import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Validators, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Globals, USER_TYPES, PATRON_DEFAULT_TAB, TEMP_VENUES_DEFAULT_TAB, PERM_VENUES_DEFAULT_TAB } from "../../globals";
import * as firebase from 'firebase';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  login_form : FormGroup;

  logourl = "../assets/lineuplogo.png";

  constructor(private router: Router, 
              public globals: Globals,
              public formBuilder : FormBuilder ) { }

  ngOnInit() {
    this.login_form = this.formBuilder.group({
      email: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required)
    });
  }

  ionViewWillLeave() {
    // we clear up the form by reinitializing it
    this.ngOnInit();
  }

  goBack() {
    this.router.navigate(["splashscreen"]);
  }

  login(user) {

    var self=this;
	  var email=user.email;
	  var password=user.password;

	  var successful : Boolean = true;

	  firebase.auth().signInWithEmailAndPassword(email, password).catch(function(error) {
    
      console.log("DEBUG: FAILED TO LOG IN");
		
		  // Handle Errors here.
		  var errorCode = error.code;
		  var errorMessage = error.message;
		  console.log(errorCode);

		  if (errorCode === 'auth/wrong-password') {
        alert('Wrong password.');
      } 
      else if (errorCode === 'auth/user-not-found'){
        alert("Failed to Log In.\nUser does not exist");
      }
			console.log(error);
			successful=false;
		}).then( function(result) {

      console.log("DEBUG: in result. successful is: " + successful);
		  var user = result;

			if (successful) {
				// we successfully logged in

				// we extract the current user's type
        let userid = firebase.auth().currentUser.uid;
        console.log("DEBUG: extracted userid is: " + userid);
        
				console.log("DEBUG: the logged in userid is: " + userid);
        let userTypesRef = firebase.database().ref('userType/');
        
        // first we figure out what type of user it is...
        // we extract the first one because there only is one user with a given uid
        userTypesRef.orderByChild("uid").equalTo(userid).limitToFirst(1).on("value", function(data) {

          var data_keys = Object.keys(data.val());
          
          // this will only happen once
          var extractedOBJ = data.val()[ data_keys[0] ];
          var extractedType = extractedOBJ.type;
          console.log("\tThe extracted user data is: " + JSON.stringify( extractedOBJ ) );
          console.log("\tTHE TYPE OF THE LOGGING IN USER IS " + extractedType);

          // now we figure out what user type it is
          if (extractedType == "") {
            successful = false;
          } 
          else {
            // set the login types
            if (extractedType == USER_TYPES.PATRON) {
              self.globals.SET_CURRENT_LOGGED_IN_TYPE(USER_TYPES.PATRON);
            } 
            else if (extractedType == USER_TYPES.PERMANENT_VENUE) {
             self.globals.SET_CURRENT_LOGGED_IN_TYPE(USER_TYPES.PERMANENT_VENUE);
            } 
            else if (extractedType == USER_TYPES.TEMPORARY_VENUE) {
             self.globals.SET_CURRENT_LOGGED_IN_TYPE(USER_TYPES.TEMPORARY_VENUE);
            } 
            else {
              self.globals.ResetUserType();
            }
            console.log("DEBUG: extractedType is: " + extractedType);
            console.log("AND SUCCESSFUL IS: " + successful);
          }
          
          if (successful) {
            console.log("DEBUG: we are in here and entering it.");
            // First we extract the object that contains the data of the logged in user
            // And then we do routing here for the default tab that will appear
            // based on the value of the current user

            let userid = firebase.auth().currentUser.uid; // userid of the logged in user/venue/patron... entity
            
            if (self.globals.GET_CURRENT_LOGGED_IN_TYPE() == USER_TYPES.PATRON ) {
              console.log("DEBUG: in login and we are extracting the patron data.");
              // we extract the patron data from the database and save it a global variable
              let patronDataRef = firebase.database().ref('patronInfo/');
        
              patronDataRef.orderByChild("uid").equalTo(userid).limitToFirst(1).on("value", function(data) {
                // this will only happen once
                //
                // There exists only one patron for a specified uid and we extract its data
                console.log("DEBUG: IN HERE!");
                var extractedData = null;
                var data_keys = Object.keys(data.val());
                extractedData = data.val()[ data_keys[0] ];
                console.log("DEBUG: the extracted PATRON data is: " + JSON.stringify(extractedData) );


                // now we figure out if we were able to extract object successfully
                console.log("DEBUG: the extractedData is: " + JSON.stringify(extractedData));
                if (extractedData != null) {
                  console.log("DEBUG: we are now logging in as a patron.");
                  Globals.CURRENT_PATRON_OBJ = extractedData;
                  self.router.navigate([PATRON_DEFAULT_TAB]);
                } 
                else {
                 // this should never happen
                 Globals.CURRENT_PATRON_OBJ = null;
                 alert("ERROR and INVALID CASE: Tried to log in as patron and could not recover the data at all!! THIS SHOULD NOT HAPPEN!");
                }
              });
            }
            else if (self.globals.GET_CURRENT_LOGGED_IN_TYPE() == USER_TYPES.PERMANENT_VENUE) {
              //TODO: EXTRACT THE PERMANENT VENUE AND SET IT T THE GLOBAL VARIABLE
              alert('NEED TO FIX THE PERMANENT VENUE SIGNING IN STUFF AFTER FIGURING IT OUT');
              console.log('\n\tTODO: EXTRACT THE PERMANENT VENUE AND SET IT T THE GLOBAL VARIABLE\n')
              
              console.log("the permanent venue object's stringified ticketInfo array will eventually have the format for each contained object: \
                \n\t(1) numTickets per hour \
                \n\t(2) startHour for each hourly slot - which will range from 8 to 13 (1 AM)\
                \n\t(3) price per ticket");

              Globals.CURRENT_PERM_VENUE_OBJ = null;
              self.router.navigate([PERM_VENUES_DEFAULT_TAB]);
            } 
            else if (self.globals.GET_CURRENT_LOGGED_IN_TYPE() == USER_TYPES.TEMPORARY_VENUE) {
              //EXTRACT THE TEMPORARY VENUE AND THEN SET IT TO THE GLOBAL VARIABLE
              // we extract the temporary venue data from the database and save it a global variable
              let tempVenueRef = firebase.database().ref('tempVenueInfo/');
        
              tempVenueRef.orderByChild("uid").equalTo(userid).limitToFirst(1).on("value", function(data) {
                // this will only happen once
                var extractedData = null;
                var data_keys = Object.keys(data.val());
                extractedData = data.val()[ data_keys[0] ];
                console.log("DEBUG: the extracted temporary venue data is: " + JSON.stringify(extractedData) );

                // now we figure out if we were able to extract something
                if (extractedData != null) {
                  Globals.CURRENT_TEMP_VENUE_OBJ = extractedData;
                  self.router.navigate([TEMP_VENUES_DEFAULT_TAB]);
                } 
                else {
                  // this should never happen
                  Globals.CURRENT_TEMP_VENUE_OBJ = null;
                  alert("ERROR and INVALID CASE: Tried to log in as temporary venue and could not recover the data at all!! \
                        THIS SHOULD NOT HAPPEN!");
                }     
              });
            } 
            else {
              // it wasn't successful
              console.log("IT WASN\"T SUCCESSFUL FOR SOME REASON!");
              alert("ERROR: was not successful in figuring out what user type this is.")
            } 
          }
          else {
            // it wasn't successful
            console.log("IT WASN\"T SUCCESSFUL FOR SOME REASON!");
            alert("ERROR: was not successful in figuring out what user type this is.")
          }

        });
      }
    });
  }
}







//-------------
  
/*      ORIGINAL CODE TO INSERT INTO   userTypesRef.orderByChild("uid").equalTo(userid).limitToFirst(1).on("value", function(data) function
          var data_keys = Object.keys(data.val());

          console.log("DEBUG: data_keys is: " + JSON.stringify(data_keys) );
          console.log("DEBUG: in loop - " + JSON.stringify( data.val()[ data_keys[0] ] ) );

          // this will only happen once
          var extractedOBJ = data.val()[ data_keys[0] ];
          console.log("DEBUG: the extractedObject is: " + extractedOBJ);
          console.log("DEBUG: IN userTypesRef.orderByChild.");
          console.log("DEBUG: THE DATA WE ARE PRINTING IS: " + JSON.stringify(extractedOBJ) );
          console.log("DEBUG: the printing type is: " + extractedOBJ.type );
          var extractedType = extractedOBJ.type;
          console.log("DEBUG: the extracted type is: " + extractedType);

          console.log("\tDEBUG: BEFORE GOING TO FIGUREOUT WHAT THE USER TYPE IS, ");
          console.log("\tWE HAVE THE FOLLOIWING EXTRACTED TYPE: " + extractedType);

          // now we figure out what user type it is
          if (extractedType == "") {
            console.log("DEBUG: in loginpage and setting successful false.");
            successful = false;
          } 
          else {
            console.log("DEBUG: IN HERE");

            // set the login types
            if (extractedType == USER_TYPES.PATRON) {
              console.log("DEBUG: in loginpage and setting the extracted type as being patron");
              self.globals.SET_CURRENT_LOGGED_IN_TYPE(USER_TYPES.PATRON);
            } 
            else if (extractedType == USER_TYPES.PERMANENT_VENUE) {
             self.globals.SET_CURRENT_LOGGED_IN_TYPE(USER_TYPES.PERMANENT_VENUE);
            } 
            else if (extractedType == USER_TYPES.TEMPORARY_VENUE) {
             self.globals.SET_CURRENT_LOGGED_IN_TYPE(USER_TYPES.TEMPORARY_VENUE);
            } 
            else {
              self.globals.ResetUserType();
            }

            console.log("DEBUG: extractedType is: " + extractedType);
            console.log("AND SUCCESSFUL IS: " + successful);
          }
          
          if (successful) {
            console.log("DEBUG: we are in here and entering it.");
            // First we extract the object that contains the data of the logged in user
            // And then we do routing here for the default tab that will appear
            // based on the value of the current user

            let userid = firebase.auth().currentUser.uid; // userid of the logged in user/venue/patron... entity

            if (self.globals.GET_CURRENT_LOGGED_IN_TYPE() == USER_TYPES.PATRON ) {
              console.log("DEBUG: in login and we are extracting the patron data.");
              // we extract the patron data from the database and save it a global variable
              let patronDataRef = firebase.database().ref('patronInfo/');
        
              var extractedData = null;
              patronDataRef.orderByChild("uid").equalTo(userid).on("value", function(data) {
                // this will only happen once
                data.forEach( function (data) {
                  extractedData = data.val();
                  console.log("DEBUG: the extracted PATRON data is: " + JSON.stringify(extractedData));
                });
              });

              // now we figure out if we were able to extract object successfully
              if (extractedData != null) {
                console.log("DEBUG: we are now logging in as a patron.");
                Globals.CURRENT_PATRON_OBJ = extractedData;
                self.router.navigate([PATRON_DEFAULT_TAB]);
              } 
              else {
                // this should never happen
                Globals.CURRENT_PATRON_OBJ = null;
                alert("ERROR and INVALID CASE: Tried to log in as patron and could not recover the data at all!! THIS SHOULD NOT HAPPEN!");
              }
            }
            else if (self.globals.GET_CURRENT_LOGGED_IN_TYPE() == USER_TYPES.PERMANENT_VENUE) {
              //TODO: EXTRACT THE PERMANENT VENUE AND SET IT T THE GLOBAL VARIABLE
              alert('NEED TO FIX THE PERMANENT VENUE SIGNING IN STUFF AFTER FIGURING IT OUT');
              console.log('\n\tTODO: EXTRACT THE PERMANENT VENUE AND SET IT T THE GLOBAL VARIABLE\n')
              Globals.CURRENT_PERM_VENUE_OBJ = null;
              self.router.navigate([PERM_VENUES_DEFAULT_TAB]);
            } 
            else if (self.globals.GET_CURRENT_LOGGED_IN_TYPE() == USER_TYPES.TEMPORARY_VENUE) {
              //EXTRACT THE TEMPORARY VENUE AND THEN SET IT TO THE GLOBAL VARIABLE
              // we extract the temporary venue data from the database and save it a global variable
              let tempVenueRef = firebase.database().ref('tempVenueInfo/');
        
              var extractedData = null;
              tempVenueRef.orderByChild("uid").equalTo(userid).on("value", function(data) {
              // this will only happen once
               data.forEach( function (data) {
                extractedData = data.val();
                console.log("DEBUG: the extracted TEMPORARY VENUE data is: " + JSON.stringify(extractedData));
                });
              });
        
              // now we figure out if we were able to extract something
              if (extractedData != null) {
                Globals.CURRENT_TEMP_VENUE_OBJ = extractedData;
                self.router.navigate([TEMP_VENUES_DEFAULT_TAB]);
              } 
            else {
              // this should never happen
              Globals.CURRENT_TEMP_VENUE_OBJ = null;
              alert("ERROR and INVALID CASE: Tried to log in as temporary and could not recover the data at all!! \
                     THIS SHOULD NOT HAPPEN!");
            }
          } 
          else {
            // it wasn't successful
            console.log("IT WASN\"T SUCCESSFUL!");
            alert("ERROR: was not successful in figuring out what user type this is.")
          }




*/
        

