import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-splashscreen',
  templateUrl: './splashscreen.page.html',
  styleUrls: ['./splashscreen.page.scss'],
})
export class SplashscreenPage implements OnInit {

  logourl = "../assets/lineuplogo.png";

  constructor(private router : Router) { }

  ngOnInit() {
  }

  signUpPatron() {
    console.log("WE SIGN UP AS PATRON");
    this.router.navigate(["/signuppatron"]);
  }

  signUpVenue() {
    console.log("WE SIGN UP AS VENUE");
    this.router.navigate(["signupvenue"]);
  }

  logInUser() {
    console.log("WE LOG IN USER");
    this.router.navigate(["login"]);
  }

}
