import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SignuppatronPage } from './signuppatron.page';

describe('SignuppatronPage', () => {
  let component: SignuppatronPage;
  let fixture: ComponentFixture<SignuppatronPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SignuppatronPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SignuppatronPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
