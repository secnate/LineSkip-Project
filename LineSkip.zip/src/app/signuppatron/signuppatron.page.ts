import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Globals, USER_TYPES, PATRON_DEFAULT_TAB } from "../../globals";
import { Router } from '@angular/router';
import * as firebase from 'firebase';

@Component({
  selector: 'app-signuppatron',
  templateUrl: './signuppatron.page.html',
  styleUrls: ['./signuppatron.page.scss'],
})
export class SignuppatronPage implements OnInit {

  new_patron_form : FormGroup;

  canPresentID : boolean = false;
  hasReadTermsAndConditions: boolean = false;

  constructor(private router : Router,
              public globals : Globals,
              private formBuilder : FormBuilder ) { }

  ngOnInit() {
    this.new_patron_form = this.formBuilder.group({
      firstName: new FormControl('', Validators.required),
      lastName: new FormControl('', Validators.required),
      email: new FormControl('', Validators.required),
      phoneNumber: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required),
      confirmPassword: new FormControl('', Validators.required)
    });

    this.canPresentID = false;
    this.hasReadTermsAndConditions = false;
  }

  ionViewWillAppear() {
    console.log("DEBUG: signupPatronPage will appear.");
    this.canPresentID = false;
    this.hasReadTermsAndConditions = false;
  }

  ionViewWillLeave() {
    // we clear up the form by re-initializing it
    this.ngOnInit();
  }

  goBack() {
    this.router.navigate(["splashscreen"]);
  }

  signup(new_patron) {
    // we register the new user
    // and save all his information to firebase
    console.log("DEBUG: in signup.");
    console.log("\tnew_patron is: " + JSON.stringify(new_patron));

    var self = this;

    var firstName = new_patron.firstName;
    var lastName = new_patron.lastName;
    var email = new_patron.email;
    var phoneNumber = new_patron.phoneNumber;
    var password = new_patron.password;
    var confirmPassword = new_patron.confirmPassword;
    var successful = true;

    // create separate boolean value 
    // like var comfirmedPasswordSuccesfully = ....
    // set it to false if the 
    // password does not match confirmation password

    console.log("DEBUG: we are going to create a user with this information");
    
    if(password != confirmPassword) {
      alert("The passwords don't match.")
    } else {
  	firebase.auth().createUserWithEmailAndPassword(email, password).catch(
  		function(error) {

	      // Handle Errors here.
	      console.log(error);
	      var errorCode = error.code;
	      var errorMessage = error.message;
		    console.log(error.message);

	      if(errorCode.length > 0){
		    	alert('Failed to Sign Up.\n' + errorMessage);
		    	successful = false;
		    } 
	      else{
		    	console.log("signup ok")
		    	successful = true;
	     }
       // ...
       
	    }).then(function(user){
        // if did not confirm password successfully && successful
        // throw an alert
        //if (did not confirm password successfully) --> alert
        // else if (successful)
				if (successful) {
          var userID = firebase.auth().currentUser.uid;

          var newPatron = {
            firstName: firstName, lastName: lastName, 
            phoneNum: phoneNumber, uid: userID,
            // array of purchased ticket information in string form
            // It will eventually have the format for each contained object:
            // (1) uid of venue @ which I purchased at
            // (2) number of tickets purchased
            // (3) price per ticket
            // (4) starting hour per ticket
            purchasedTickets: JSON.stringify([]), 

            // Temporary venue cart tickets
            // It will have the format for each contained object in  {}:
            // 1) venueUID: temp venue uid - for the venue that I want to order from
            // 2) priceToBuy: Price at which I want to purchase the ticket
            // 3) numToOrder: Number of tickets to order
            // 4) startHour: Start hour for the one-hour time slot in which we buy tickets
            //    represented as integers from 8 = 8 PM to 13 = 1 AM
            // 5) venueType: String representation of the type of venue I am purchasing from 
            //    either temporary or permanent
            cart: JSON.stringify([])  
          };

          let newPatronFirebase = firebase.database().ref('patronInfo/').push();
          newPatronFirebase.set( JSON.parse(JSON.stringify(newPatron)) );

          // we also add the user type to the user types
          let newPatronType = firebase.database().ref('userType/').push();
          newPatronType.set({
            uid: userID, type: USER_TYPES.PATRON
          })

          self.globals.SET_CURRENT_LOGGED_IN_TYPE(USER_TYPES.PATRON);
          Globals.CURRENT_PATRON_OBJ = newPatron;

          // Move to the core of the app itself after logging in
          self.router.navigate([PATRON_DEFAULT_TAB]);
        }
        else {
          alert('Failed to Sign Up due to Invalid Information.\nPlease Try Again.');
        }
	});
    }
  }

  toggleNewHasIDValue() {
    this.canPresentID = !this.canPresentID;
  }

  toggleHasReadTermsAndConditions() {
    this.hasReadTermsAndConditions = !this.hasReadTermsAndConditions;
  }

  openTermsAndConditions() {
    var parmaeterOBJ = { returnURL : "/signuppatron"};
    this.router.navigate(['/terms-and-conditions-page', parmaeterOBJ]);
  }
}
