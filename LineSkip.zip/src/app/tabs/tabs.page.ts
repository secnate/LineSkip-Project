import { Component } from '@angular/core';
import { Events } from '@ionic/angular';
import { Globals, USER_TYPES } from "../../globals";
import { Router } from '@angular/router';

@Component({
  selector: 'app-tabs',
  templateUrl: 'tabs.page.html',
  styleUrls: ['tabs.page.scss']
})
export class TabsPage {

  // this is the boolean value that will trigger
  // the showing of the tabs as to whether someone
  // is logged in as a patron or as someone else.
  // If it is false, then we are logged in as venue.
  // If true, then we are logged in as patron
  userType; 

  constructor (public events : Events, 
               public router : Router,
               public globals: Globals ){
    this.events.subscribe('changedLogInType', (time) => {
      console.log("DEBUG: changedLogType: " + this.globals.GET_CURRENT_LOGGED_IN_TYPE());
      this.userType = this.globals.CURRENT_USER_TYPE();
    });

    this.userType = this.globals.CURRENT_USER_TYPE();

  }

  ionViewWillAppear() {
    this.userType = this.globals.CURRENT_USER_TYPE();

    this.events.subscribe('changedLogInType', (time) => {
      console.log("DEBUG: changedLogType: " + this.globals.GET_CURRENT_LOGGED_IN_TYPE());
      this.userType = this.globals.CURRENT_USER_TYPE();
    });
  }

  getUserType() {
    return this.globals.CURRENT_USER_TYPE();
  }
}
