import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePickerModule } from 'ionic4-date-picker';
import * as moment from 'moment';

@Component({
  selector: 'app-newtempvenuedatetimepicker',
  templateUrl: './newtempvenuedatetimepicker.page.html',
  styleUrls: ['./newtempvenuedatetimepicker.page.scss'],
})
export class NewtempvenuedatetimepickerPage implements OnInit {

  basicNewTempVenueInfo;

  // this page allows us to select a temporary venue's
  // start date, end date, start time, and end time
  private selectedStartDate = false;
  private selectedEndDate = false;

  private selectedInitialTime = false;
  private selectedEndTime = false;

  // we have the minimum date for the starting of the date
  // picker
  minStartDate: string = new Date().toISOString();

  // The results of the date pickers
  startDate : Date = null;
  endDate : Date = null;

  startTime = null;
  endTime = null;

  // variables that control the collapsing of the calendars
  // for easier visual viewing by saving space
  collapseStartDateCalendar: boolean = false;
  collapseEndDateCalendar: boolean = false;

  constructor(private router : Router,
              private route : ActivatedRoute ) { }

  ngOnInit() {
    this.route.params.subscribe (
      param => {
        this.basicNewTempVenueInfo = param;
      }
    )
  }

  ionViewDidLeave() {
    // we leave the view so we reset all the variables
    // so that when we re-enter the view will be good as new!
    this.selectedStartDate = false;
    this.selectedEndDate = false;
    this.selectedInitialTime = false;
    this.selectedEndTime = false;

    this.startDate = null;
    this.endDate = null;

    this.startTime = null;
    this.endTime = null;

    this.collapseStartDateCalendar = false;
    this.collapseEndDateCalendar = false;
  }

  getTodayDate() {
    return new Date();
  }

  getTomorrow() {
    // we get tomorrow's date
    return new Date(this.getTodayDate().getTime() + 
                    (24 * 60 * 60 * 1000));
  }

  getEndOfYear() {
    // get the beginning of the year
    var beginningOfNextYear = new Date( new Date().getFullYear()+1, 0, 1);
    
    // subtract a day from it and return that
    return new Date(beginningOfNextYear.getTime() - 
                    (24 * 60 * 60 * 1000));
  }

  cancel() {
    this.router.navigate(["/signupvenue"]);
  }

  changedStartTime(newTime) {
    this.selectedInitialTime = true;
    console.log("DEBUG: the new start time is: " + this.startTime);
  }

  changedEndTime(newTime) {
    this.selectedEndTime = true;
    console.log("DEBUG: the new end time is: " + this.endTime);
  }

  getChoseOrSelectedStartTime() {
    if (this.selectedInitialTime) {
      return "Selected ";
    }
    else {
      return "Choose ";
    }
  }

  getChoseOrSelectedEndTime() {
    if (this.selectedEndTime) {
      return "Selected ";
    }
    else {
      return "Choose ";
    }
  }

  hasSelectedStartTime() {
    // IF the start time is selected
    return this.selectedInitialTime;
  }

  hasSelectedEndTime() {
    return this.selectedEndTime;
  }

  initialDateSelected(newDate) {
    console.log("DEBUG: SELECTED INITIAL DATE: " + newDate);
    this.selectedStartDate = true;
    this.startDate = newDate;

    // Now we check the case if 
    // the second date has already been selected
    if (this.endDate != null && this.selectedEndDate == true) {
      // We need to reset the whole thing in order to 
      // select a proper end date
      // And have the end date calendar open
      this.endDate = null;
      this.selectedEndDate = false;

      // collapse the first calendar
      this.toggleViewingStartDateCalendar();
    }
  } 

  endDateSelected(newEndDate) {
    console.log("DEBUG: SELECTED END DATE: " + newEndDate);
    this.selectedEndDate = true;
    this.endDate = newEndDate;
  }

  getDateAfterSelectedStartDate() {
    if (this.startDate == null) {
      return null;
    }
    
    // otherwise, take the startDate and add 24 hours to it
    return new Date(this.startDate.getTime() + 
                    (24 * 60 * 60 * 1000))
  }

  toggleViewingStartDateCalendar() {
    if (this.startDate != null && 
        this.selectedStartDate == true) {
      //we selected a start date
      // and toggle the start date calendar's viewing
      this.collapseStartDateCalendar = !this.collapseStartDateCalendar;
    }
  }

  toggleViewingEndDateCalendar() {
    if (this.endDate != null && this.selectedEndDate == true) {
      // we selected the end date and toggle the
      // end date calendar's viewing
      this.collapseEndDateCalendar = !this.collapseEndDateCalendar;
    }
  }

  getStartDateOutput() {
    // we get the string representation of the date
    // if one is selected
    if (this.startDate == null) {
      return "";
    } 
    else {
      return moment(this.startDate).format("MM/DD/YYYY");
    }
  }

  getEndDateOutput() {
    // we get the string representation of the date
    // if one is selected
    if (this.endDate == null) {
      return "";
    } 
    else {
      return moment(this.endDate).format("MM/DD/YYYY");
    }
  }

  getChoseOrSelectedStartDate() {
    // if we selected a start date,
    // then we return the string "Selected"
    // for display in the html file
    // if we did not select, then we return the
    // string "Choose" - to prompt users to select a start date
    if (this.startDate == null) {
      return "Choose ";
    }
    else {
      return "Selected ";
    }
  }

  getChoseOrSelectedEndDate() {
    // if we selected a end date,
    // then we return the string "Selected"
    // for display in the html file
    // if we did not select, then we return the
    // string "Choose" - to prompt users to select a start date
    if (this.endDate == null) {
      return "Choose ";
    }
    else {
      return "Selected ";
    }
  }

  canShowStartDateCalendar() {
    // we display the calendar only if
    // the initial date wasn't selected
    // or if the initial date was selected
    // and we deliberately want to see it
   
    var toReturn = ( !this.selectedStartDate ||
                       (this.selectedStartDate &&
                        this.collapseStartDateCalendar
                        ) 
                  );

    return toReturn;
  }

  canShowEndDateCalendar() {
    // we display the calendar only if
    // the initial date wasn't selected
    // or if the initial date was selected
    // and we deliberately want to see it
   
    var toReturn = ( (!this.selectedEndDate && 
                      this.selectedStartDate)
                     ||
                       (this.selectedEndDate &&
                        this.collapseEndDateCalendar
                        ) 
                  );

    return toReturn;
  }

  showStartPullUpArrow() {
    return this.canShowStartDateCalendar() && this.selectedStartDate != false;
  }

  showEndPullUpArrow() {
    return this.canShowEndDateCalendar() && this.selectedEndDate != false;
  }

  // moveToTicketsInfo packages the information collected
  // so far about the new temporary venue and passes it on
  // to the next view controller.
  // We add extra information to basicNewTempVenueInfo
  moveToTicketsInfo() {
    console.log("CLICKED MOVE TO TICKETS INFO");
    var toPassOn = {
      //original information received from previous slide
      name: this.basicNewTempVenueInfo.name,
      address: this.basicNewTempVenueInfo.address,
      venueDescription: this.basicNewTempVenueInfo.venueDescription,
      phoneNumber: this.basicNewTempVenueInfo.phoneNumber,

      // now we add in the new information
      //    the start and end dates of the event
      startDate: this.startDate,
      endDate: this.endDate, 

      //    the start times and end times of the event
      //    note the CRITICAL ASSUMPTION that the start 
      //    time is PM and the end time is AM.
      startTime: this.startTime,
      endTime: this.endTime
    };

    this.router.navigate(["tempvenuehourtickinfosetter", toPassOn]);
  }
}
