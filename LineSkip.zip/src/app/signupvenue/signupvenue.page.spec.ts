import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SignupvenuePage } from './signupvenue.page';

describe('SignupvenuePage', () => {
  let component: SignupvenuePage;
  let fixture: ComponentFixture<SignupvenuePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SignupvenuePage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SignupvenuePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
