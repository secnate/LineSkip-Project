import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signupvenue',
  templateUrl: './signupvenue.page.html',
  styleUrls: ['./signupvenue.page.scss'],
})
export class SignupvenuePage implements OnInit {

  logourl = "../assets/lineuplogo.png";

  constructor(private router: Router) { }

  ngOnInit() {
  }

  goBack() {
    this.router.navigate(["splashscreen"]);
  }

  registerTemporaryVenue() {
    console.log("Registering as temporary venue");
    this.router.navigate(["/registertemporaryvenue"]);
  }

  registerPermanentVenue() {
    console.log("Registering as permanent venue");
    this.router.navigate(["/registerpermanentvenue"]);
  }

}
