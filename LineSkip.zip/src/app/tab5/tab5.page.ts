import { Component } from '@angular/core';
import { Globals } from "../../globals";
import { Router, ActivatedRoute } from '@angular/router';
import * as firebase from 'firebase';


@Component({
  selector: 'app-tab5',
  templateUrl: './tab5.page.html',
  styleUrls: ['./tab5.page.scss'],
})
export class Tab5Page {

  private passedParameter;

  constructor(public globals : Globals, 
              private router : Router) { }

  ionViewDidEnter() {
  }

  openEditTempVenueInfoPage() {
    console.log("DEBUG: openEditTempVenueInfoPage()");
    this.router.navigate(["/edit-temp-venue-info"]);
  }

  updatePhoto(){
    var self=this;
            
    let fireBaseUser = firebase.auth().currentUser;
    self.router.navigate(['/update-photo', 
    {id : fireBaseUser.uid} ]);
  }

  logout(){
    var self=this;
            
    let fireBaseUser = firebase.auth().currentUser;
    console.log(fireBaseUser.uid +" userid")
            
            
    firebase.auth().signOut().then(function() {
      console.log("logout succeed");
          
      self.router.navigate(["/homepage"]);
      this.globals.ResetUserType(); 
           
      // Sign-out successful.
    }).catch(function(error) {
      // An error happened.
    });
  }

}
