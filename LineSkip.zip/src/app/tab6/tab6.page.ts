// 
//  THIS IS THE SADEGH SIDE OF THE APP.
//  ONLY SADEGH SHOULD MODIFY THIS FILE
//

import { Component } from '@angular/core';
import { Globals } from "../../globals";
import { Router } from '@angular/router';
import * as firebase from 'firebase';


@Component({
  selector: 'app-tab6',
  templateUrl: './tab6.page.html',
  styleUrls: ['./tab6.page.scss'],
})
export class Tab6Page {

  constructor(public globals : Globals, 
              private router : Router) { }

  ionViewDidEnter() {
    console.log("DEBUG: ENTERING TAB6 - the permanent venue is: " + JSON.stringify(Globals.CURRENT_PERM_VENUE_OBJ) );
    console.log("the permanent venue object's stringified ticketInfo array will eventually have the format for each contained object: \
                \n\t(1) numTickets per hour \
                \n\t(2) startHour for each hourly slot - which will range from 8 to 13 (1 AM)\
                \n\t(3) price per ticket");
  }

  logout(){
    var self=this;
            
    let fireBaseUser = firebase.auth().currentUser;
    console.log(fireBaseUser.uid +" userid")
            
            
    firebase.auth().signOut().then(function() {
      console.log("logout succeed");
          
      self.router.navigate(["/homepage"]);
      this.globals.ResetUserType(); 
           
      // Sign-out successful.
    }).catch(function(error) {
      // An error happened.
    });
  }

}
